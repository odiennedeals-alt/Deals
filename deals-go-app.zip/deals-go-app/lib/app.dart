import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';
import 'core/theme/app_theme.dart';
import 'providers/auth_provider.dart';
import 'providers/content_provider.dart';
import 'providers/driver_provider.dart';
import 'providers/notifications_provider.dart';
import 'providers/ride_provider.dart';
import 'screens/authentication/blocked_screen.dart';
import 'screens/home/home_shell.dart';
import 'screens/onboarding/welcome_screen.dart';
import 'screens/waiting_validation/waiting_screen.dart';
import 'widgets/logo.dart';

class DealsGoApp extends StatelessWidget {
  const DealsGoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthProvider()..init()),
        ChangeNotifierProvider(create: (_) => ContentProvider()..load()),
        ChangeNotifierProvider(create: (_) => NotificationsProvider()),
        ChangeNotifierProvider(create: (_) => RideProvider()),
        ChangeNotifierProvider(create: (_) => DriverProvider()),
      ],
      child: Consumer<ContentProvider>(
        builder: (context, content, _) => MaterialApp(
          title: 'DEALS GO',
          debugShowCheckedModeBanner: false,
          theme: AppTheme.build(content.primary),
          locale: const Locale('fr'),
          supportedLocales: const [Locale('fr')],
          localizationsDelegates: const [
            GlobalMaterialLocalizations.delegate,
            GlobalWidgetsLocalizations.delegate,
            GlobalCupertinoLocalizations.delegate,
          ],
          home: const Gate(),
        ),
      ),
    );
  }
}

/// Aiguillage selon l'état du compte : connexion, attente de validation, compte bloqué, application.
class Gate extends StatelessWidget {
  const Gate({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    if (auth.loading) {
      return const Scaffold(body: Center(child: DealsLogo(size: 64)));
    }
    if (!auth.signedIn || auth.profile == null) return const WelcomeScreen();
    if (auth.isPending) return const WaitingScreen();
    if (auth.isBlocked) return const BlockedScreen();
    if (auth.isActive) return HomeShell(key: ValueKey(auth.profile!['id']));
    return const WelcomeScreen();
  }
}
