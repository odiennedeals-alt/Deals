/// Configuration publique. La clé "anon" est conçue pour être dans l'application
/// (la sécurité repose sur les règles RLS de la base). Jamais de clé service_role ici.
class Env {
  static const supabaseUrl = String.fromEnvironment(
    'SUPABASE_URL',
    defaultValue: 'https://nmqncfasfvpflkpjtclq.supabase.co',
  );
  static const supabaseAnonKey = String.fromEnvironment(
    'SUPABASE_ANON_KEY',
    defaultValue:
        'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im5tcW5jZmFzZnZwZmxrcGp0Y2xxIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTUzODgxOTksImV4cCI6MjExMDk2NDE5OX0.Dv6gYo9Zb1GuzjW8OyQ9Z2mumlxtXP0MoF-mZNEFiLU',
  );

  /// Page web publique du partage de trajet (site deals-go).
  static const shareBaseUrl = String.fromEnvironment(
    'SHARE_BASE_URL',
    defaultValue: 'https://deals-go.vercel.app/share/',
  );
}
