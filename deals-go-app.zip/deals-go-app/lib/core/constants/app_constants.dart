import 'package:latlong2/latlong.dart';

class AppConstants {
  static const appName = 'DEALS GO';
  static const odienneCenter = LatLng(9.5, -7.5667);
  static const defaultZoom = 14.0;
  static const nearbyRadiusKm = 10;
  static const supportWhatsappFallback = '+2250173662023';
  static const userAgent = 'DealsGo/1.0 (dealsgo113@gmail.com)';

  static const activeRideStatuses = ['requested', 'accepted', 'arrived', 'in_progress'];

  static const vehicleLabels = {'car': 'Taxi auto', 'moto': 'Taxi moto'};

  static const docTypes = {
    'cni': 'CNI',
    'cmu': 'Carte CMU',
    'driving_license': 'Permis de conduire',
    'birth_certificate': 'Extrait de naissance',
    'selfie': 'Photo personnelle',
    'vehicle_photo': 'Photo du véhicule',
    'plate_photo': 'Photo de la plaque',
  };

  static const maintenanceKinds = {
    'oil_change': 'Vidange',
    'tires': 'Pneus',
    'brakes': 'Freins',
    'insurance': 'Assurance',
    'technical_inspection': 'Visite technique',
    'other': 'Autre',
  };

  static const rideStatusLabels = {
    'requested': 'En attente du conducteur',
    'accepted': 'Conducteur en route',
    'arrived': 'Conducteur arrivé',
    'in_progress': 'Course en cours',
    'completed': 'Terminée',
    'cancelled': 'Annulée',
    'declined': 'Refusée',
    'expired': 'Sans réponse',
  };
}
