import 'dart:async';
import 'dart:io';
import 'package:supabase_flutter/supabase_flutter.dart';

const _messages = <String, String>{
  'not_authenticated': 'Votre session a expiré. Reconnectez-vous.',
  'account_not_active': "Votre compte n'est pas encore actif.",
  'driver_unavailable': "Ce conducteur n'est plus disponible. Choisissez-en un autre.",
  'driver_busy': 'Ce conducteur est déjà en course. Choisissez-en un autre.',
  'active_ride_exists': 'Vous avez déjà une course en cours.',
  'outside_service_area': "Le point de départ est en dehors de la zone de service d'Odienné.",
  'invalid_promo': "Ce code promotionnel n'est pas valide.",
  'invalid_coordinates': 'Position invalide.',
  'invalid_address': 'Adresse invalide.',
  'distance_too_long': 'Distance trop longue.',
  'subscription_required': "Un abonnement actif est nécessaire pour travailler. Souscrivez à une offre.",
  'vehicle_not_in_service': 'Votre véhicule doit être « En service » pour passer en ligne.',
  'driver_suspended': 'Votre compte conducteur est suspendu. Contactez l\'assistance.',
  'driver_blocked': 'Votre compte conducteur est bloqué. Contactez l\'assistance.',
  'account_not_active ': "Votre compte n'est pas actif.",
  'not_a_driver': "Vous n'êtes pas encore conducteur.",
  'already_driver': 'Vous êtes déjà conducteur.',
  'name_required': 'Saisissez votre nom.',
  'vehicle_info_required': 'Renseignez la marque, le modèle, la couleur et la plaque.',
  'plate_already_registered': 'Cette plaque est déjà enregistrée.',
  'staff_cannot_drive': "Un compte d'administration ne peut pas être conducteur.",
  'ride_not_found': 'Course introuvable.',
  'ride_not_pending': "Cette demande n'est plus en attente.",
  'ride_in_progress': 'La course a commencé : elle ne peut plus être annulée ici.',
  'cannot_cancel': 'Cette course ne peut plus être annulée.',
  'ride_closed': 'Cette course est déjà terminée.',
  'invalid_transition': "Cette étape n'est pas possible pour le moment.",
  'already_rated': 'Vous avez déjà noté cette course.',
  'ride_not_shareable': "Cette course ne peut pas être partagée pour l'instant.",
  'plan_unavailable': "Cette offre n'est plus disponible.",
  'payment_already_pending': 'Un paiement est déjà en cours de vérification.',
  'payment_not_editable': "Ce paiement ne peut plus être modifié.",
  'invalid_file_path': 'Fichier invalide.',
  'too_soon': 'Veuillez patienter une minute avant de redemander un code.',
  'not_pending': "Votre compte n'est pas en attente.",
  'trip_unavailable': "Ce trajet n'est plus disponible.",
  'not_enough_seats': 'Pas assez de places disponibles.',
  'already_booked': 'Vous avez déjà une réservation pour ce trajet.',
  'cannot_book_own_trip': 'Vous ne pouvez pas réserver votre propre trajet.',
  'invalid_cities': 'Villes invalides.',
  'invalid_departure': 'La date de départ doit être dans le futur.',
  'invalid_seats': 'Nombre de places invalide.',
  'invalid_price': 'Prix invalide.',
  'forbidden': "Vous n'avez pas le droit d'effectuer cette action.",
  'fares_not_configured': 'Les tarifs ne sont pas encore configurés.',
};

String errorMessage(Object e) {
  if (e is PostgrestException) {
    final m = e.message.trim();
    return _messages[m] ?? (m.contains('row-level security') ? "Action non autorisée." : m);
  }
  if (e is AuthException) {
    final m = e.message;
    if (m.contains('Invalid login credentials')) return 'Numéro ou mot de passe incorrect.';
    if (m.contains('already registered')) return 'Ce numéro est déjà inscrit. Connectez-vous.';
    if (m.contains('Database error saving new user')) return "Inscription impossible avec ce numéro.";
    if (m.toLowerCase().contains('password')) return 'Le mot de passe doit contenir au moins 6 caractères.';
    return m;
  }
  if (e is SocketException || e is TimeoutException) {
    return 'Connexion impossible. Vérifiez votre Internet.';
  }
  if (e is StorageException) return 'Envoi du fichier impossible : ${e.message}';
  final s = e.toString();
  if (s.contains('SocketException') || s.contains('ClientException')) {
    return 'Connexion impossible. Vérifiez votre Internet.';
  }
  return _messages[s.replaceFirst('Exception: ', '')] ?? s.replaceFirst('Exception: ', '');
}
