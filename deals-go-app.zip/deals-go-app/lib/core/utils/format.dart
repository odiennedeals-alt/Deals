String money(num? n) {
  final v = (n ?? 0).round();
  final s = v.abs().toString();
  final buf = StringBuffer();
  for (var i = 0; i < s.length; i++) {
    if (i > 0 && (s.length - i) % 3 == 0) buf.write('\u202F');
    buf.write(s[i]);
  }
  return '${v < 0 ? '-' : ''}$buf FCFA';
}

String two(int n) => n.toString().padLeft(2, '0');

String dayText(DateTime? d) => d == null ? '—' : '${two(d.day)}/${two(d.month)}/${d.year}';

String dateTimeText(DateTime? d) =>
    d == null ? '—' : '${two(d.day)}/${two(d.month)}/${d.year} ${two(d.hour)}:${two(d.minute)}';

String timeText(DateTime? d) => d == null ? '—' : '${two(d.hour)}:${two(d.minute)}';

/// Accepte 0700000000, 07 00 00 00 00, +225 07 00 00 00 00 ou 225 0700000000.
/// Retourne +225XXXXXXXXXX (10 chiffres après 225) ou null si invalide.
String? normalizePhone(String input) {
  var d = input.replaceAll(RegExp(r'[^0-9]'), '');
  if (d.startsWith('00225')) d = d.substring(5);
  if (d.startsWith('225') && d.length == 13) d = d.substring(3);
  if (d.length != 10) return null;
  return '+225$d';
}

/// Email technique utilisé par Supabase Auth pour un numéro (jamais affiché).
String techEmail(String e164) => '${e164.replaceAll('+', '')}@phone.dealsgo.app';

String prettyPhone(String? e164) {
  if (e164 == null || e164.isEmpty) return '—';
  final d = e164.replaceAll(RegExp(r'[^0-9]'), '');
  if (d.length == 13) {
    return '+225 ${d.substring(3, 5)} ${d.substring(5, 7)} ${d.substring(7, 9)} ${d.substring(9, 11)} ${d.substring(11, 13)}';
  }
  return e164;
}

String kmText(double km) => km < 1 ? '${(km * 1000).round()} m' : '${km.toStringAsFixed(1)} km';
