import '../core/utils/json.dart';

class DriverCard {
  final String id;
  final String name;
  final String phone;
  final String? avatarPath;
  final double rating;
  final int rides;
  final bool certified;
  final bool premium;
  final String vehicleType;
  final String brand;
  final String model;
  final String color;
  final String plate;
  final String? vehiclePhotoPath;
  final double distanceKm;
  final int etaMin;
  final int? price;
  final double lat;
  final double lng;

  DriverCard({
    required this.id,
    required this.name,
    required this.phone,
    required this.avatarPath,
    required this.rating,
    required this.rides,
    required this.certified,
    required this.premium,
    required this.vehicleType,
    required this.brand,
    required this.model,
    required this.color,
    required this.plate,
    required this.vehiclePhotoPath,
    required this.distanceKm,
    required this.etaMin,
    required this.price,
    required this.lat,
    required this.lng,
  });

  factory DriverCard.fromMap(Map<String, dynamic> m) => DriverCard(
        id: toS(m['driver_id']),
        name: toS(m['full_name'], 'Conducteur'),
        phone: toS(m['phone']),
        avatarPath: m['avatar_path'] as String?,
        rating: toD(m['rating_avg']),
        rides: toI(m['rides_count']),
        certified: m['is_certified'] == true,
        premium: m['is_premium'] == true,
        vehicleType: toS(m['vehicle_type']),
        brand: toS(m['brand']),
        model: toS(m['model']),
        color: toS(m['color']),
        plate: toS(m['plate_number']),
        vehiclePhotoPath: m['vehicle_photo_path'] as String?,
        distanceKm: toD(m['distance_km']),
        etaMin: toI(m['eta_min'], 1),
        price: m['est_price_fcfa'] == null ? null : toI(m['est_price_fcfa']),
        lat: toD(m['lat']),
        lng: toD(m['lng']),
      );

  String get vehicleLabel => '$brand $model · $color';
}
