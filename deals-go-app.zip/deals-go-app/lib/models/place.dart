import 'package:latlong2/latlong.dart';

class Place {
  final String label;
  final LatLng point;
  const Place(this.label, this.point);
}

class RouteInfo {
  final double distanceKm;
  final int durationMin;
  final List<LatLng> points;
  final bool estimated;
  const RouteInfo(this.distanceKm, this.durationMin, this.points, {this.estimated = false});
}
