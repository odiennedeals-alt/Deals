import '../core/utils/json.dart';

class Ride {
  final String id;
  final String clientId;
  final String driverId;
  final String status;
  final String vehicleType;
  final String pickupLabel;
  final double pickupLat;
  final double pickupLng;
  final String destLabel;
  final double destLat;
  final double destLng;
  final double distanceKm;
  final int durationMin;
  final int price;
  final int discount;
  final int? finalPrice;
  final String paymentMethod;
  final String? clientName;
  final String? clientPhone;
  final String? clientAvatarPath;
  final String? driverName;
  final String? driverPhone;
  final String? driverAvatarPath;
  final Map<String, dynamic> vehicle;
  final DateTime? createdAt;
  final DateTime? expiresAt;
  final String? cancelReason;
  final String? declineReason;
  final String? cancelledBy;

  Ride({
    required this.id,
    required this.clientId,
    required this.driverId,
    required this.status,
    required this.vehicleType,
    required this.pickupLabel,
    required this.pickupLat,
    required this.pickupLng,
    required this.destLabel,
    required this.destLat,
    required this.destLng,
    required this.distanceKm,
    required this.durationMin,
    required this.price,
    required this.discount,
    required this.finalPrice,
    required this.paymentMethod,
    required this.clientName,
    required this.clientPhone,
    required this.clientAvatarPath,
    required this.driverName,
    required this.driverPhone,
    required this.driverAvatarPath,
    required this.vehicle,
    required this.createdAt,
    required this.expiresAt,
    required this.cancelReason,
    required this.declineReason,
    required this.cancelledBy,
  });

  factory Ride.fromMap(Map<String, dynamic> m) => Ride(
        id: toS(m['id']),
        clientId: toS(m['client_id']),
        driverId: toS(m['driver_id']),
        status: toS(m['status']),
        vehicleType: toS(m['vehicle_type']),
        pickupLabel: toS(m['pickup_label']),
        pickupLat: toD(m['pickup_lat']),
        pickupLng: toD(m['pickup_lng']),
        destLabel: toS(m['dest_label']),
        destLat: toD(m['dest_lat']),
        destLng: toD(m['dest_lng']),
        distanceKm: toD(m['distance_km']),
        durationMin: toI(m['duration_min']),
        price: toI(m['price_fcfa']),
        discount: toI(m['discount_fcfa']),
        finalPrice: m['final_price_fcfa'] == null ? null : toI(m['final_price_fcfa']),
        paymentMethod: toS(m['payment_method'], 'cash'),
        clientName: m['client_name'] as String?,
        clientPhone: m['client_phone'] as String?,
        clientAvatarPath: m['client_avatar_path'] as String?,
        driverName: m['driver_name'] as String?,
        driverPhone: m['driver_phone'] as String?,
        driverAvatarPath: m['driver_avatar_path'] as String?,
        vehicle: toMap(m['vehicle_snapshot']) ?? <String, dynamic>{},
        createdAt: toDate(m['created_at']),
        expiresAt: toDate(m['expires_at']),
        cancelReason: m['cancel_reason'] as String?,
        declineReason: m['decline_reason'] as String?,
        cancelledBy: m['cancelled_by'] as String?,
      );

  bool get isActive => const ['requested', 'accepted', 'arrived', 'in_progress'].contains(status);
  bool get isFinished => !isActive;
  int get total => finalPrice ?? (price - discount < 0 ? 0 : price - discount);

  String get vehicleText {
    final b = toS(vehicle['brand']);
    final mo = toS(vehicle['model']);
    final c = toS(vehicle['color']);
    final pl = toS(vehicle['plate_number']);
    return [if (b.isNotEmpty || mo.isNotEmpty) '$b $mo'.trim(), if (c.isNotEmpty) c, if (pl.isNotEmpty) pl].join(' · ');
  }
}
