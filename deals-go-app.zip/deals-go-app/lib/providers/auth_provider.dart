import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../core/utils/errors.dart';
import '../core/utils/format.dart';
import '../core/utils/json.dart';
import '../services/api.dart';
import '../services/local_store.dart';
import '../services/supa.dart';

class AuthProvider extends ChangeNotifier {
  Map<String, dynamic>? profile;
  Map<String, dynamic>? driver;
  List<String> roles = [];
  bool loading = true;
  String mode = 'client';
  StreamSubscription<AuthState>? _sub;
  Timer? _poll;
  bool _busy = false;

  bool get signedIn => sb.auth.currentSession != null;
  String get status => toS(profile?['account_status']);
  bool get isPending => signedIn && profile != null && status == 'pending';
  bool get isActive => signedIn && status == 'active';
  bool get isBlocked => signedIn && (status == 'blocked' || status == 'deleted');
  bool get isDriver => driver != null;
  String get phone => toS(profile?['phone']);
  String get name => toS(profile?['full_name']);
  String? get avatarPath => profile?['avatar_path'] as String?;
  bool get isStaff => roles.any((r) => r == 'admin' || r == 'super_admin' || r == 'moderator');

  Future<void> init() async {
    mode = await LocalStore.mode();
    _sub = sb.auth.onAuthStateChange.listen((_) => refresh());
    await refresh();
  }

  Future<void> refresh() async {
    if (_busy) return;
    _busy = true;
    try {
      if (!signedIn) {
        profile = null;
        driver = null;
        roles = [];
        _stopPoll();
      } else {
        profile = await Api.myProfile();
        if (isActive) {
          roles = await Api.myRoles();
          driver = await Api.myDriver();
          if (driver == null) mode = 'client';
          _stopPoll();
        } else {
          driver = null;
          roles = [];
          if (isPending) _startPoll();
        }
      }
    } catch (_) {
      // Hors ligne : on garde l'état précédent.
    }
    loading = false;
    _busy = false;
    notifyListeners();
  }

  void _startPoll() {
    _poll ??= Timer.periodic(const Duration(seconds: 6), (_) => refresh());
  }

  void _stopPoll() {
    _poll?.cancel();
    _poll = null;
  }

  Future<void> setMode(String m) async {
    mode = m;
    await LocalStore.setMode(m);
    notifyListeners();
  }

  Future<void> signIn(String phoneInput, String password) async {
    final p = normalizePhone(phoneInput);
    if (p == null) throw Exception('Numéro invalide. Saisissez 10 chiffres (ex. 07 00 00 00 00).');
    await sb.auth.signInWithPassword(email: techEmail(p), password: password);
    await refresh();
  }

  Future<void> signUp(String phoneInput, String password, String fullName) async {
    final p = normalizePhone(phoneInput);
    if (p == null) throw Exception('Numéro invalide. Saisissez 10 chiffres (ex. 07 00 00 00 00).');
    final res = await sb.auth.signUp(email: techEmail(p), password: password, data: {'full_name': fullName.trim()});
    if (res.session == null) {
      throw Exception("Compte créé mais la session n'a pas démarré. Contactez l'assistance DEALS GO.");
    }
    await refresh();
  }

  Future<Map<String, dynamic>> verifyCode(String code) async {
    final r = await Api.verifyCode(code);
    if (r['ok'] == true) await refresh();
    return r;
  }

  Future<String?> requestNewCode() async {
    try {
      await Api.requestVerification();
      return null;
    } catch (e) {
      return errorMessage(e);
    }
  }

  Future<void> signOut() async {
    await LocalStore.clearRideContact();
    await sb.auth.signOut();
    profile = null;
    driver = null;
    roles = [];
    notifyListeners();
  }

  @override
  void dispose() {
    _sub?.cancel();
    _poll?.cancel();
    super.dispose();
  }
}
