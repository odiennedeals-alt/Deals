import 'package:flutter/material.dart';
import '../core/constants/app_constants.dart';
import '../core/utils/json.dart';
import '../services/api.dart';
import '../services/supa.dart';

/// Contenu configurable depuis l'administration : contact, tarifs, textes, logo, bannières, SOS.
class ContentProvider extends ChangeNotifier {
  Map<String, dynamic> settings = {};
  Map<String, dynamic> content = {};
  List<Map<String, dynamic>> sos = [];
  bool loaded = false;

  Future<void> load() async {
    try {
      settings = await Api.publicSettings();
      content = await Api.appContent();
      sos = await Api.sosNumbers();
    } catch (_) {
      // Garde les valeurs précédentes si hors ligne.
    }
    loaded = true;
    notifyListeners();
  }

  Map<String, dynamic> get contact => toMap(settings['contact']) ?? {};
  String get whatsapp => toS(contact['whatsapp'], AppConstants.supportWhatsappFallback);
  String get waveNumber => toS(contact['wave_number'], '01 73 66 20 23');
  String? get waveLink {
    final l = contact['wave_payment_link'];
    return (l is String && l.trim().isNotEmpty) ? l.trim() : null;
  }

  Map<String, dynamic> get fares => toMap(settings['fares']) ?? {};

  String? get logoUrl {
    final v = toMap(content['logo']?['value']);
    return publicUrl(v?['path'] as String?);
  }

  String text(String key, String fallback) {
    final v = toMap(content[key]?['value']);
    return toS(v?['text'], fallback);
  }

  List<Map<String, dynamic>> get banners {
    final l = content.entries
        .where((e) => toS(e.value['content_type']) == 'banner')
        .map((e) => Map<String, dynamic>.from(e.value as Map))
        .toList();
    l.sort((a, b) => toI(a['sort_order']).compareTo(toI(b['sort_order'])));
    return l;
  }

  Color get primary {
    final hex = toS(toMap(settings['branding'])?['primary']);
    if (RegExp(r'^#[0-9a-fA-F]{6}$').hasMatch(hex)) {
      return Color(int.parse('FF${hex.substring(1)}', radix: 16));
    }
    return const Color(0xFFFF3B30);
  }
}
