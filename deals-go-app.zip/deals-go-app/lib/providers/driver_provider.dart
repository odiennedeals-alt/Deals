import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:geolocator/geolocator.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../core/utils/errors.dart';
import '../models/ride.dart';
import '../services/api.dart';
import '../services/location_service.dart';
import '../services/supa.dart';

class DriverProvider extends ChangeNotifier {
  bool online = false;
  bool busy = false;
  String? message;
  List<Ride> requests = [];
  Ride? active;
  Map<String, dynamic> earnings = {};

  RealtimeChannel? _ch;
  Timer? _poll;
  Timer? _heartbeat;
  StreamSubscription<Position>? _pos;
  Position? _last;
  DateTime _lastSent = DateTime.fromMillisecondsSinceEpoch(0);

  Future<void> start(bool isOnline) async {
    await stop();
    online = isOnline;
    await refresh();
    if (myId != null) {
      _ch = Api.watch('rides', refresh, column: 'driver_id', value: myId);
    }
    _poll = Timer.periodic(const Duration(seconds: 12), (_) => refresh());
    if (online) await _startLocation();
  }

  Future<void> stop() async {
    _poll?.cancel();
    _heartbeat?.cancel();
    await _pos?.cancel();
    _pos = null;
    await Api.unwatch(_ch);
    _ch = null;
  }

  Future<void> refresh() async {
    try {
      requests = await Api.driverRequests();
      active = await Api.activeRideAsDriver();
      earnings = await Api.earnings();
      final d = await Api.myDriver();
      if (d != null) online = d['is_online'] == true;
      notifyListeners();
    } catch (_) {}
  }

  Future<bool> setOnline(bool value) async {
    busy = true;
    message = null;
    notifyListeners();
    try {
      if (value && !await LocationService.ensurePermission()) {
        message = "Activez la localisation pour recevoir des courses.";
        return false;
      }
      await Api.setOnline(value);
      online = value;
      if (value) {
        await _startLocation();
      } else {
        await _stopLocation();
      }
      return true;
    } catch (e) {
      message = errorMessage(e);
      return false;
    } finally {
      busy = false;
      notifyListeners();
    }
  }

  Future<void> _startLocation() async {
    await _stopLocation();
    final here = await LocationService.current();
    if (here != null) await _send(here.latitude, here.longitude, null);
    _pos = LocationService.stream(distanceFilter: 15).listen((p) {
      _last = p;
      if (DateTime.now().difference(_lastSent).inSeconds >= 8) {
        _send(p.latitude, p.longitude, p.heading);
      }
    });
    // Signal de présence même si le conducteur ne bouge pas (les clients ne voient que les positions récentes).
    _heartbeat = Timer.periodic(const Duration(seconds: 30), (_) {
      final p = _last;
      if (p != null) _send(p.latitude, p.longitude, p.heading);
    });
  }

  Future<void> _stopLocation() async {
    _heartbeat?.cancel();
    _heartbeat = null;
    await _pos?.cancel();
    _pos = null;
  }

  Future<void> _send(double lat, double lng, double? heading) async {
    _lastSent = DateTime.now();
    try {
      await Api.updateLocation(lat, lng, heading: heading, rideId: active?.id);
    } catch (_) {}
  }

  Future<String?> respond(Ride r, bool accept, {String? reason}) async {
    try {
      await Api.respondRide(r.id, accept, reason: reason);
      await refresh();
      return null;
    } catch (e) {
      await refresh();
      return errorMessage(e);
    }
  }

  Future<String?> advance(Ride r, String status) async {
    try {
      await Api.updateRideStatus(r.id, status);
      await refresh();
      return null;
    } catch (e) {
      return errorMessage(e);
    }
  }

  @override
  void dispose() {
    _poll?.cancel();
    _heartbeat?.cancel();
    _pos?.cancel();
    Api.unwatch(_ch);
    super.dispose();
  }
}
