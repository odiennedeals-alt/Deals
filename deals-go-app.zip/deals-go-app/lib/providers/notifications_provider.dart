import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../services/api.dart';
import '../services/supa.dart';

class NotificationsProvider extends ChangeNotifier {
  List<Map<String, dynamic>> items = [];
  RealtimeChannel? _ch;
  final StreamController<Map<String, dynamic>> _incoming = StreamController.broadcast();
  Stream<Map<String, dynamic>> get incoming => _incoming.stream;

  int get unread => items.where((e) => e['is_read'] != true).length;

  Future<void> start() async {
    await stop();
    await load();
    if (myId != null) {
      _ch = Api.watch('notifications', _onChange, column: 'user_id', value: myId);
    }
  }

  Future<void> stop() async {
    await Api.unwatch(_ch);
    _ch = null;
  }

  Future<void> load() async {
    try {
      items = await Api.notifications();
    } catch (_) {}
    notifyListeners();
  }

  Future<void> _onChange() async {
    final knownIds = items.map((e) => e['id']).toSet();
    await load();
    for (final n in items) {
      if (!knownIds.contains(n['id']) && n['is_read'] != true) {
        _incoming.add(n);
        break;
      }
    }
  }

  Future<void> markAllRead() async {
    try {
      await Api.markAllNotificationsRead();
    } catch (_) {}
    await load();
  }

  Future<void> markRead(String id) async {
    try {
      await Api.markNotificationRead(id);
    } catch (_) {}
    await load();
  }

  @override
  void dispose() {
    _incoming.close();
    Api.unwatch(_ch);
    super.dispose();
  }
}
