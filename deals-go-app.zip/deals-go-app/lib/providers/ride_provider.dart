import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../models/ride.dart';
import '../services/api.dart';
import '../services/supa.dart';

/// Course active du client (synchronisée en temps réel, avec relève toutes les 15 s si le réseau coupe).
class RideProvider extends ChangeNotifier {
  Ride? active;
  RealtimeChannel? _ch;
  Timer? _timer;

  Future<void> start() async {
    await stop();
    await refresh();
    if (myId != null) {
      _ch = Api.watch('rides', refresh, column: 'client_id', value: myId);
    }
    _timer = Timer.periodic(const Duration(seconds: 15), (_) => refresh());
  }

  Future<void> stop() async {
    _timer?.cancel();
    _timer = null;
    await Api.unwatch(_ch);
    _ch = null;
    active = null;
  }

  Future<void> refresh() async {
    try {
      active = await Api.activeRideAsClient();
      notifyListeners();
    } catch (_) {
      // Hors ligne : on conserve l'état connu, resynchronisation automatique au prochain essai.
    }
  }

  void setActive(Ride? r) {
    active = r;
    notifyListeners();
  }

  @override
  void dispose() {
    _timer?.cancel();
    Api.unwatch(_ch);
    super.dispose();
  }
}
