import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/errors.dart';
import '../../core/utils/json.dart';
import '../../providers/content_provider.dart';
import '../../services/api.dart';
import '../../services/launcher.dart';
import '../../widgets/common.dart';

/// Assistant DEALS GO : questions et réponses préenregistrées, modifiables depuis l'administration.
class AssistantScreen extends StatefulWidget {
  const AssistantScreen({super.key});
  @override
  State<AssistantScreen> createState() => _AssistantScreenState();
}

class _AssistantScreenState extends State<AssistantScreen> {
  List<Map<String, dynamic>> categories = [];
  List<Map<String, dynamic>> questions = [];
  String? selected;
  bool loading = true;
  String? error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final c = await Api.supportCategories();
      final q = await Api.supportQuestions();
      if (mounted) setState(() { categories = c; questions = q; loading = false; error = null; });
    } catch (e) {
      if (mounted) setState(() { loading = false; error = errorMessage(e); });
    }
  }

  String _answer(Map<String, dynamic> q) {
    final a = q['support_answers'];
    if (a is List && a.isNotEmpty) return toS((a.first as Map)['answer']);
    if (a is Map) return toS(a['answer']);
    return '';
  }

  @override
  Widget build(BuildContext context) {
    final content = context.watch<ContentProvider>();
    final shown = questions.where((q) => selected == null || q['category_id'] == selected).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('Assistant DEALS GO')),
      body: loading
          ? const LoadingView()
          : error != null
              ? ErrorView(message: error!, onRetry: _load)
              : ListView(padding: const EdgeInsets.all(16), children: [
                  const Text('Touchez une question pour voir la réponse.', style: TextStyle(color: AppColors.greyText)),
                  const SizedBox(height: 10),
                  SizedBox(
                    height: 40,
                    child: ListView(scrollDirection: Axis.horizontal, children: [
                      Padding(padding: const EdgeInsets.only(right: 8), child: ChoiceChip(label: const Text('Toutes'), selected: selected == null, onSelected: (_) => setState(() => selected = null))),
                      for (final c in categories)
                        Padding(
                          padding: const EdgeInsets.only(right: 8),
                          child: ChoiceChip(label: Text(toS(c['name'])), selected: selected == c['id'], onSelected: (_) => setState(() => selected = toS(c['id']))),
                        ),
                    ]),
                  ),
                  const SizedBox(height: 10),
                  for (final q in shown)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8),
                      child: AppCard(
                        padding: EdgeInsets.zero,
                        child: Theme(
                          data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
                          child: ExpansionTile(
                            tilePadding: const EdgeInsets.symmetric(horizontal: 14),
                            childrenPadding: const EdgeInsets.fromLTRB(14, 0, 14, 14),
                            title: Text(toS(q['question']), style: const TextStyle(fontWeight: FontWeight.w700)),
                            expandedCrossAxisAlignment: CrossAxisAlignment.start,
                            children: [Text(_answer(q))],
                          ),
                        ),
                      ),
                    ),
                  if (shown.isEmpty) const EmptyState(icon: Icons.help_outline, title: 'Aucune question dans cette catégorie'),
                  const SizedBox(height: 12),
                  AppCard(
                    color: const Color(0xFFF0FDF4),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(content.text('assistant.footer', 'Vous avez besoin de plus d\'informations ? Contactez directement notre assistance sur WhatsApp.'), style: const TextStyle(fontWeight: FontWeight.w600)),
                      const SizedBox(height: 10),
                      ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF16A34A)),
                        onPressed: () => openWhatsApp(content.whatsapp, content.text('assistant.whatsapp_message', "Bonjour DEALS GO, j'ai besoin d'aide.")),
                        icon: const Icon(Icons.chat_rounded),
                        label: const Text('Contacter sur WhatsApp'),
                      ),
                    ]),
                  ),
                ]),
    );
  }
}
