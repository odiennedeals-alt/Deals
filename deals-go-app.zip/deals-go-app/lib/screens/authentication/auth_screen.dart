import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/errors.dart';
import '../../providers/auth_provider.dart';
import '../../widgets/logo.dart';

class AuthScreen extends StatefulWidget {
  const AuthScreen({super.key});
  @override
  State<AuthScreen> createState() => _AuthScreenState();
}

class _AuthScreenState extends State<AuthScreen> {
  bool register = false;
  bool busy = false;
  bool hide = true;
  String? error;
  final phone = TextEditingController();
  final name = TextEditingController();
  final password = TextEditingController();
  final confirm = TextEditingController();

  @override
  void dispose() {
    phone.dispose();
    name.dispose();
    password.dispose();
    confirm.dispose();
    super.dispose();
  }

  Future<void> submit() async {
    setState(() => error = null);
    if (register) {
      if (name.text.trim().length < 2) return setState(() => error = 'Saisissez votre nom.');
      if (password.text.length < 6) return setState(() => error = 'Le mot de passe doit contenir au moins 6 caractères.');
      if (password.text != confirm.text) return setState(() => error = 'Les mots de passe ne correspondent pas.');
    } else if (password.text.isEmpty) {
      return setState(() => error = 'Saisissez votre mot de passe.');
    }
    setState(() => busy = true);
    final auth = context.read<AuthProvider>();
    try {
      if (register) {
        await auth.signUp(phone.text, password.text, name.text);
      } else {
        await auth.signIn(phone.text, password.text);
      }
      if (mounted) Navigator.of(context).popUntil((r) => r.isFirst);
    } catch (e) {
      if (mounted) setState(() => error = errorMessage(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(24, 0, 24, 24),
          children: [
            const Center(child: DealsLogo(size: 44)),
            const SizedBox(height: 26),
            Text(
              register ? 'CRÉER MON COMPTE' : 'SAISISSEZ VOTRE NUMÉRO',
              style: const TextStyle(fontSize: 26, fontWeight: FontWeight.w900, height: 1.1),
            ),
            const SizedBox(height: 8),
            Text(
              register
                  ? "Votre inscription sera vérifiée par l'administration, qui vous enverra un code à 6 chiffres sur WhatsApp."
                  : 'Connectez-vous avec votre numéro et votre mot de passe.',
              style: const TextStyle(color: AppColors.greyText),
            ),
            const SizedBox(height: 22),
            TextField(
              controller: phone,
              keyboardType: TextInputType.phone,
              decoration: const InputDecoration(labelText: 'Numéro de téléphone', prefixText: '+225  ', hintText: '07 00 00 00 00'),
            ),
            if (register) ...[
              const SizedBox(height: 12),
              TextField(controller: name, textCapitalization: TextCapitalization.words, decoration: const InputDecoration(labelText: 'Nom et prénom')),
            ],
            const SizedBox(height: 12),
            TextField(
              controller: password,
              obscureText: hide,
              decoration: InputDecoration(
                labelText: 'Mot de passe',
                suffixIcon: IconButton(icon: Icon(hide ? Icons.visibility_off : Icons.visibility), onPressed: () => setState(() => hide = !hide)),
              ),
            ),
            if (register) ...[
              const SizedBox(height: 12),
              TextField(controller: confirm, obscureText: hide, decoration: const InputDecoration(labelText: 'Confirmer le mot de passe')),
            ],
            if (error != null) ...[
              const SizedBox(height: 14),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: const Color(0xFFFEE2E2), borderRadius: BorderRadius.circular(12)),
                child: Text(error!, style: const TextStyle(color: Color(0xFFB91C1C))),
              ),
            ],
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: busy ? null : submit,
              child: busy
                  ? const SizedBox(height: 22, width: 22, child: CircularProgressIndicator(strokeWidth: 3, color: Colors.white))
                  : Text(register ? "M'inscrire" : 'Se connecter'),
            ),
            const SizedBox(height: 10),
            TextButton(
              onPressed: busy ? null : () => setState(() { register = !register; error = null; }),
              child: Text(register ? "J'ai déjà un compte" : 'Je n\'ai pas de compte : m\'inscrire'),
            ),
          ],
        ),
      ),
    );
  }
}
