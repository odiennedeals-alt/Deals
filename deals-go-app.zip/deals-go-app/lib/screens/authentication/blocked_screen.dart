import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/utils/json.dart';
import '../../providers/auth_provider.dart';
import '../../providers/content_provider.dart';
import '../../services/launcher.dart';

class BlockedScreen extends StatelessWidget {
  const BlockedScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final content = context.watch<ContentProvider>();
    final reason = toS(auth.profile?['status_reason']);
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            const Icon(Icons.block_rounded, size: 64, color: Color(0xFFB91C1C)),
            const SizedBox(height: 16),
            const Text('Compte indisponible', textAlign: TextAlign.center, style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
            const SizedBox(height: 10),
            Text(
              reason.isEmpty ? "Votre compte est actuellement bloqué par l'administration." : 'Votre compte est bloqué. Motif : $reason',
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () => openWhatsApp(content.whatsapp, "Bonjour DEALS GO, mon compte ${auth.phone} est bloqué. Pouvez-vous m'aider ?"),
              child: const Text("Contacter l'assistance sur WhatsApp"),
            ),
            const SizedBox(height: 10),
            OutlinedButton(onPressed: () => auth.signOut(), child: const Text('Se déconnecter')),
          ]),
        ),
      ),
    );
  }
}
