import 'dart:async';
import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/json.dart';
import '../../models/place.dart';
import '../../services/api.dart';
import '../../services/geo_service.dart';
import '../../services/location_service.dart';
import '../../widgets/common.dart';
import '../driver_selection/driver_selection_screen.dart';
import '../map/map_pick_screen.dart';

class DestinationScreen extends StatefulWidget {
  final String vehicleType;
  final Place? initialPickup;
  const DestinationScreen({super.key, required this.vehicleType, this.initialPickup});
  @override
  State<DestinationScreen> createState() => _DestinationScreenState();
}

class _DestinationScreenState extends State<DestinationScreen> {
  Place? pickup;
  Place? dest;
  List<Map<String, dynamic>> favorites = [];

  @override
  void initState() {
    super.initState();
    pickup = widget.initialPickup;
    Api.favorites().then((f) {
      if (mounted) setState(() => favorites = f);
    }).catchError((_) {});
    if (pickup != null && pickup!.label == 'Ma position actuelle') {
      GeoService.reverse(pickup!.point).then((label) {
        if (mounted && pickup != null) setState(() => pickup = Place(label, pickup!.point));
      });
    }
  }

  Future<void> _pick(bool isPickup) async {
    final p = await Navigator.of(context).push<Place>(MaterialPageRoute(
      builder: (_) => PlacePickerScreen(
        title: isPickup ? 'Point de départ' : 'Destination',
        showCurrent: isPickup,
        center: (isPickup ? pickup?.point : dest?.point) ?? pickup?.point ?? AppConstants.odienneCenter,
      ),
    ));
    if (p != null && mounted) setState(() => isPickup ? pickup = p : dest = p);
  }

  void _go() {
    Navigator.of(context).push(MaterialPageRoute(
      builder: (_) => DriverSelectionScreen(vehicleType: widget.vehicleType, pickup: pickup!, dest: dest!),
    ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(AppConstants.vehicleLabels[widget.vehicleType] ?? 'Course')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        AppCard(
          padding: EdgeInsets.zero,
          child: Column(children: [
            ListTile(
              leading: const Icon(Icons.my_location, color: Color(0xFF2563EB)),
              title: Text(pickup?.label ?? 'Choisir le point de départ', maxLines: 2, overflow: TextOverflow.ellipsis),
              subtitle: const Text('Départ'),
              onTap: () => _pick(true),
            ),
            const Divider(height: 1),
            ListTile(
              leading: const Icon(Icons.flag_rounded, color: AppColors.red),
              title: Text(dest?.label ?? 'Où allons-nous ?', maxLines: 2, overflow: TextOverflow.ellipsis),
              subtitle: const Text('Destination'),
              onTap: () => _pick(false),
            ),
          ]),
        ),
        if (favorites.isNotEmpty) ...[
          const SectionTitle('Adresses favorites'),
          Wrap(spacing: 8, runSpacing: 8, children: [
            for (final f in favorites)
              ActionChip(
                avatar: const Icon(Icons.star_rounded, size: 18),
                label: Text(toS(f['label'])),
                onPressed: () => setState(() => dest = Place(toS(f['address']), LatLng(toD(f['lat']), toD(f['lng'])))),
              ),
          ]),
        ],
        const SizedBox(height: 24),
        ElevatedButton(onPressed: (pickup != null && dest != null) ? _go : null, child: const Text('Voir les conducteurs disponibles')),
      ]),
    );
  }
}

/// Recherche d'adresse, favoris, position actuelle ou point sur la carte.
class PlacePickerScreen extends StatefulWidget {
  final String title;
  final bool showCurrent;
  final LatLng center;
  const PlacePickerScreen({super.key, required this.title, required this.showCurrent, required this.center});
  @override
  State<PlacePickerScreen> createState() => _PlacePickerScreenState();
}

class _PlacePickerScreenState extends State<PlacePickerScreen> {
  final ctrl = TextEditingController();
  Timer? debounce;
  List<Place> results = [];
  List<Map<String, dynamic>> favorites = [];
  bool searching = false;
  String? error;

  @override
  void initState() {
    super.initState();
    Api.favorites().then((f) {
      if (mounted) setState(() => favorites = f);
    }).catchError((_) {});
  }

  @override
  void dispose() {
    debounce?.cancel();
    ctrl.dispose();
    super.dispose();
  }

  void _onChanged(String v) {
    debounce?.cancel();
    if (v.trim().length < 3) {
      setState(() { results = []; error = null; });
      return;
    }
    debounce = Timer(const Duration(milliseconds: 700), () async {
      setState(() { searching = true; error = null; });
      try {
        final r = await GeoService.search('${v.trim()}, Odienné');
        final r2 = r.isEmpty ? await GeoService.search(v) : r;
        if (mounted) setState(() => results = r2);
      } catch (_) {
        if (mounted) setState(() => error = 'Recherche impossible. Vérifiez votre Internet ou choisissez sur la carte.');
      } finally {
        if (mounted) setState(() => searching = false);
      }
    });
  }

  Future<void> _current() async {
    final p = await LocationService.current();
    if (!mounted) return;
    if (p == null) {
      snack(context, 'Localisation indisponible. Activez le GPS.');
      return;
    }
    final label = await GeoService.reverse(p);
    if (mounted) Navigator.of(context).pop(Place(label, p));
  }

  Future<void> _onMap() async {
    final p = await Navigator.of(context).push<Place>(MaterialPageRoute(builder: (_) => MapPickScreen(center: widget.center)));
    if (p != null && mounted) Navigator.of(context).pop(p);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 4, 16, 8),
          child: TextField(
            controller: ctrl,
            autofocus: true,
            onChanged: _onChanged,
            decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Rechercher un quartier, une rue, un lieu'),
          ),
        ),
        if (searching) const LinearProgressIndicator(minHeight: 2),
        Expanded(
          child: ListView(children: [
            if (widget.showCurrent) ListTile(leading: const Icon(Icons.my_location), title: const Text('Ma position actuelle'), onTap: _current),
            ListTile(leading: const Icon(Icons.map_outlined), title: const Text('Choisir sur la carte'), onTap: _onMap),
            if (error != null) Padding(padding: const EdgeInsets.all(16), child: Text(error!, style: const TextStyle(color: Color(0xFFB91C1C)))),
            for (final r in results)
              ListTile(leading: const Icon(Icons.place_outlined), title: Text(r.label, maxLines: 2, overflow: TextOverflow.ellipsis), onTap: () => Navigator.of(context).pop(r)),
            if (results.isEmpty && ctrl.text.trim().length < 3)
              for (final f in favorites)
                ListTile(
                  leading: const Icon(Icons.star_rounded),
                  title: Text(toS(f['label'])),
                  subtitle: Text(toS(f['address']), maxLines: 1, overflow: TextOverflow.ellipsis),
                  onTap: () => Navigator.of(context).pop(Place(toS(f['address']), LatLng(toD(f['lat']), toD(f['lng'])))),
                ),
          ]),
        ),
      ]),
    );
  }
}
