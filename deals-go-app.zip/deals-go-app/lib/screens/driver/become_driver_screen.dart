import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/utils/errors.dart';
import '../../providers/auth_provider.dart';
import '../../providers/driver_provider.dart';
import '../../widgets/common.dart';
import '../../services/api.dart';

class BecomeDriverScreen extends StatefulWidget {
  const BecomeDriverScreen({super.key});
  @override
  State<BecomeDriverScreen> createState() => _BecomeDriverScreenState();
}

class _BecomeDriverScreenState extends State<BecomeDriverScreen> {
  String type = 'car';
  final name = TextEditingController();
  final brand = TextEditingController();
  final model = TextEditingController();
  final color = TextEditingController();
  final plate = TextEditingController();
  final year = TextEditingController();
  bool busy = false;

  @override
  void initState() {
    super.initState();
    name.text = context.read<AuthProvider>().name;
  }

  @override
  void dispose() {
    for (final c in [name, brand, model, color, plate, year]) {
      c.dispose();
    }
    super.dispose();
  }

  Future<void> _submit() async {
    if ([name, brand, model, color, plate].any((c) => c.text.trim().isEmpty)) {
      snack(context, 'Renseignez votre nom et toutes les informations du véhicule.');
      return;
    }
    setState(() => busy = true);
    final auth = context.read<AuthProvider>();
    final driver = context.read<DriverProvider>();
    try {
      await Api.registerAsDriver(
        fullName: name.text,
        vehicleType: type,
        brand: brand.text,
        model: model.text,
        color: color.text,
        plate: plate.text,
        year: int.tryParse(year.text.trim()),
      );
      await auth.refresh();
      await driver.start(false);
      await auth.setMode('driver');
      if (mounted) {
        snack(context, 'Espace conducteur créé. Souscrivez à un abonnement pour recevoir des courses.');
        Navigator.of(context).pop();
      }
    } catch (e) {
      if (mounted) snack(context, errorMessage(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Devenir conducteur')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        const Text("Renseignez votre véhicule. Pour recevoir des courses, vous devrez ensuite souscrire à un abonnement conducteur (les clients ne paient aucun abonnement).", style: TextStyle(height: 1.4)),
        const SizedBox(height: 14),
        Row(children: [
          Expanded(child: ChoiceChip(label: const Center(child: Text('Taxi auto')), selected: type == 'car', onSelected: (_) => setState(() => type = 'car'))),
          const SizedBox(width: 8),
          Expanded(child: ChoiceChip(label: const Center(child: Text('Taxi moto')), selected: type == 'moto', onSelected: (_) => setState(() => type = 'moto'))),
        ]),
        const SizedBox(height: 12),
        TextField(controller: name, textCapitalization: TextCapitalization.words, decoration: const InputDecoration(labelText: 'Nom et prénom')),
        const SizedBox(height: 10),
        TextField(controller: brand, decoration: const InputDecoration(labelText: 'Marque (ex. Toyota)')),
        const SizedBox(height: 10),
        TextField(controller: model, decoration: const InputDecoration(labelText: 'Modèle (ex. Corolla)')),
        const SizedBox(height: 10),
        TextField(controller: color, decoration: const InputDecoration(labelText: 'Couleur')),
        const SizedBox(height: 10),
        TextField(controller: plate, textCapitalization: TextCapitalization.characters, decoration: const InputDecoration(labelText: "Plaque d'immatriculation")),
        const SizedBox(height: 10),
        TextField(controller: year, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Année (optionnel)')),
        const SizedBox(height: 20),
        ElevatedButton(onPressed: busy ? null : _submit, child: busy ? const SizedBox(height: 22, width: 22, child: CircularProgressIndicator(strokeWidth: 3, color: Colors.white)) : const Text('Créer mon espace conducteur')),
      ]),
    );
  }
}
