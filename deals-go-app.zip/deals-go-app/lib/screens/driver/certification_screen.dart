import 'package:flutter/material.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/errors.dart';
import '../../core/utils/format.dart';
import '../../core/utils/json.dart';
import '../../services/api.dart';
import '../../services/media.dart';
import '../../widgets/common.dart';

const _certLabels = {'none': 'Non certifié', 'pending': 'Dossier en cours d\'examen', 'certified': 'Conducteur certifié', 'rejected': 'Certification refusée', 'revoked': 'Certification retirée'};
const _docStatus = {'submitted': 'En cours d\'examen', 'approved': 'Accepté', 'rejected': 'Refusé', 'replacement_requested': 'Nouveau document demandé'};

class CertificationScreen extends StatefulWidget {
  const CertificationScreen({super.key});
  @override
  State<CertificationScreen> createState() => _CertificationScreenState();
}

class _CertificationScreenState extends State<CertificationScreen> {
  Map<String, dynamic>? cert;
  List<Map<String, dynamic>> docs = [];
  String? error;
  String? uploading;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final c = await Api.myCertification();
      final d = await Api.myDocuments();
      if (mounted) setState(() { cert = c; docs = d; error = null; });
    } catch (e) {
      if (mounted) setState(() => error = errorMessage(e));
    }
  }

  Map<String, dynamic>? _latest(String type) {
    for (final d in docs) {
      if (d['doc_type'] == type) return d;
    }
    return null;
  }

  Future<void> _upload(String type) async {
    final img = await pickImage();
    if (img == null) return;
    setState(() => uploading = type);
    try {
      final path = await Api.uploadImage('private-docs', img.bytes, img.nameWith(type), contentType: img.contentType);
      await Api.submitDocument(type, path);
      if (mounted) snack(context, 'Document envoyé. Il sera examiné par l\'administration.');
      await _load();
    } catch (e) {
      if (mounted) snack(context, errorMessage(e));
    } finally {
      if (mounted) setState(() => uploading = null);
    }
  }

  @override
  Widget build(BuildContext context) {
    final status = toS(cert?['status'], 'none');
    return Scaffold(
      appBar: AppBar(title: const Text('Certification')),
      body: error != null
          ? ErrorView(message: error!, onRetry: _load)
          : ListView(padding: const EdgeInsets.all(16), children: [
              AppCard(
                color: status == 'certified' ? const Color(0xFFDCFCE7) : AppColors.grey,
                child: Row(children: [
                  Icon(status == 'certified' ? Icons.verified_rounded : Icons.shield_outlined, color: status == 'certified' ? AppColors.green : AppColors.black),
                  const SizedBox(width: 12),
                  Expanded(child: Text(_certLabels[status] ?? status, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16))),
                ]),
              ),
              if (toS(cert?['note']).isNotEmpty) Padding(padding: const EdgeInsets.only(top: 8), child: Text('Note de l\'administration : ${toS(cert?['note'])}')),
              const SizedBox(height: 8),
              const Text("Le badge « Conducteur certifié » est attribué par l'administration après examen de votre CNI, de votre permis de conduire et de votre photo. Il n'est jamais automatique. Vos documents restent privés.", style: TextStyle(color: AppColors.greyText, height: 1.4)),
              const SectionTitle('Mes documents'),
              for (final e in AppConstants.docTypes.entries)
                Builder(builder: (_) {
                  final d = _latest(e.key);
                  final st = toS(d?['status']);
                  return Padding(
                    padding: const EdgeInsets.only(bottom: 8),
                    child: AppCard(
                      child: Row(children: [
                        Expanded(
                          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                            Text(e.value, style: const TextStyle(fontWeight: FontWeight.w800)),
                            if (d == null) const Text('Non envoyé', style: TextStyle(color: AppColors.greyText, fontSize: 12))
                            else Text('${_docStatus[st] ?? st} · ${dayText(toDate(d['created_at']))}', style: const TextStyle(fontSize: 12)),
                            if (toS(d?['review_note']).isNotEmpty) Text('Motif : ${toS(d?['review_note'])}', style: const TextStyle(fontSize: 12, color: Color(0xFFB91C1C))),
                          ]),
                        ),
                        if (st == 'approved') Pill.ok('Accepté')
                        else if (uploading == e.key) const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 3))
                        else OutlinedButton(onPressed: () => _upload(e.key), style: OutlinedButton.styleFrom(minimumSize: const Size(100, 40)), child: Text(d == null ? 'Envoyer' : 'Remplacer')),
                      ]),
                    ),
                  );
                }),
            ]),
    );
  }
}
