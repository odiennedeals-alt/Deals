import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/format.dart';
import '../../core/utils/json.dart';
import '../../models/ride.dart';
import '../../providers/auth_provider.dart';
import '../../providers/driver_provider.dart';
import '../../providers/notifications_provider.dart';
import '../../services/launcher.dart';
import '../../widgets/common.dart';
import '../notifications/notifications_screen.dart';
import '../subscription/subscription_screen.dart';
import 'become_driver_screen.dart';
import 'driver_ride_screen.dart';

class DriverDashboard extends StatefulWidget {
  const DriverDashboard({super.key});
  @override
  State<DriverDashboard> createState() => _DriverDashboardState();
}

class _DriverDashboardState extends State<DriverDashboard> {
  Timer? tick;

  @override
  void initState() {
    super.initState();
    tick = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted) setState(() {});
    });
  }

  @override
  void dispose() {
    tick?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final dp = context.watch<DriverProvider>();
    final unread = context.watch<NotificationsProvider>().unread;

    if (!auth.isDriver) {
      return Scaffold(
        appBar: AppBar(title: const Text('Espace conducteur')),
        body: Padding(
          padding: const EdgeInsets.all(20),
          child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
            const Icon(Icons.local_taxi, size: 64, color: AppColors.red),
            const SizedBox(height: 12),
            const Text('Travaillez avec DEALS GO', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            const Text('Recevez des demandes de courses de clients à Odienné avec votre voiture ou votre moto.', textAlign: TextAlign.center),
            const SizedBox(height: 20),
            ElevatedButton(onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const BecomeDriverScreen())), child: const Text('Devenir conducteur')),
          ]),
        ),
      );
    }

    final d = auth.driver ?? {};
    final expires = toDate(d['subscription_expires_at']);
    final subActive = expires != null && expires.isAfter(DateTime.now());
    final status = toS(d['driver_status'], 'active');
    final requests = dp.requests.where((r) => r.expiresAt == null || r.expiresAt!.isAfter(DateTime.now())).toList();

    return Scaffold(
      appBar: AppBar(title: const Text('Espace conducteur'), actions: [
        IconButton(onPressed: () => auth.setMode('client'), icon: const Icon(Icons.swap_horiz_rounded), tooltip: 'Mode client'),
        Stack(children: [
          IconButton(onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const NotificationsScreen())), icon: const Icon(Icons.notifications_none_rounded)),
          if (unread > 0) Positioned(right: 8, top: 8, child: CircleAvatar(radius: 8, backgroundColor: AppColors.red, child: Text('$unread', style: const TextStyle(fontSize: 9, color: Colors.white)))),
        ]),
      ]),
      body: RefreshIndicator(
        onRefresh: () async {
          await auth.refresh();
          await dp.refresh();
        },
        child: ListView(padding: const EdgeInsets.all(16), children: [
          if (status != 'active')
            AppCard(color: const Color(0xFFFEE2E2), child: Text('Votre compte conducteur est ${status == 'suspended' ? 'suspendu' : 'bloqué'}. ${toS(d['status_reason'])}\nContactez l\'assistance.')),
          AppCard(
            color: subActive ? const Color(0xFFF0FDF4) : const Color(0xFFFFF7ED),
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SubscriptionScreen(standalone: true))),
            child: Row(children: [
              Icon(subActive ? Icons.verified_outlined : Icons.warning_amber_rounded, color: subActive ? AppColors.green : AppColors.amber),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(subActive ? 'Abonnement actif' : 'Abonnement requis', style: const TextStyle(fontWeight: FontWeight.w800)),
                  Text(subActive ? "Jusqu'au ${dayText(expires)}" : 'Souscrivez à une offre pour passer en ligne.', style: const TextStyle(fontSize: 13)),
                ]),
              ),
              const Icon(Icons.chevron_right),
            ]),
          ),
          const SizedBox(height: 12),
          AppCard(
            child: Column(children: [
              Row(children: [
                Expanded(
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(dp.online ? 'Vous êtes en ligne' : 'Vous êtes hors ligne', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
                    Text(dp.online ? 'Les clients proches peuvent vous choisir.' : 'Passez en ligne pour recevoir des demandes.', style: const TextStyle(color: AppColors.greyText, fontSize: 13)),
                  ]),
                ),
                Switch(value: dp.online, onChanged: dp.busy ? null : (v) => dp.setOnline(v)),
              ]),
              if (dp.message != null)
                Padding(
                  padding: const EdgeInsets.only(top: 8),
                  child: Align(alignment: Alignment.centerLeft, child: Text(dp.message!, style: const TextStyle(color: Color(0xFFB91C1C)))),
                ),
              if (dp.online)
                const Padding(
                  padding: EdgeInsets.only(top: 8),
                  child: Text("Gardez l'application ouverte : votre position n'est transmise que lorsque l'application est active.", style: TextStyle(fontSize: 12, color: AppColors.greyText)),
                ),
            ]),
          ),
          const SizedBox(height: 12),
          Row(children: [
            Expanded(child: _Stat(label: "Gains aujourd'hui", value: money(toI(dp.earnings['today'])))),
            const SizedBox(width: 10),
            Expanded(child: _Stat(label: "Courses aujourd'hui", value: '${toI(dp.earnings['rides_today'])}')),
          ]),
          if (dp.active != null) ...[
            const SectionTitle('Course en cours'),
            AppCard(
              color: const Color(0xFFFFF1F0),
              onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const DriverRideScreen())),
              child: Row(children: [
                const Icon(Icons.local_taxi, color: AppColors.red),
                const SizedBox(width: 10),
                Expanded(child: Text('${dp.active!.clientName ?? 'Client'} · ${dp.active!.destLabel}', maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w700))),
                const Icon(Icons.chevron_right),
              ]),
            ),
          ],
          SectionTitle('Demandes de course (${requests.length})'),
          if (requests.isEmpty)
            const AppCard(child: Text('Aucune demande pour le moment. Les demandes des clients qui vous choisissent apparaîtront ici.')),
          for (final r in requests) _RequestCard(ride: r),
        ]),
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  final String label;
  final String value;
  const _Stat({required this.label, required this.value});
  @override
  Widget build(BuildContext context) => AppCard(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(value, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
          Text(label, style: const TextStyle(color: AppColors.greyText, fontSize: 12)),
        ]),
      );
}

class _RequestCard extends StatelessWidget {
  final Ride ride;
  const _RequestCard({required this.ride});

  @override
  Widget build(BuildContext context) {
    final dp = context.read<DriverProvider>();
    final left = ride.expiresAt == null ? 0 : ride.expiresAt!.difference(DateTime.now()).inSeconds;
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: AppCard(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Row(children: [
            Expanded(child: Text(ride.clientName ?? 'Client', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16))),
            Pill.warn('${left < 0 ? 0 : left}s'),
          ]),
          const SizedBox(height: 6),
          Row(children: [const Icon(Icons.my_location, size: 16, color: Color(0xFF2563EB)), const SizedBox(width: 6), Expanded(child: Text(ride.pickupLabel, maxLines: 1, overflow: TextOverflow.ellipsis))]),
          Row(children: [const Icon(Icons.flag_rounded, size: 16, color: AppColors.red), const SizedBox(width: 6), Expanded(child: Text(ride.destLabel, maxLines: 1, overflow: TextOverflow.ellipsis))]),
          const SizedBox(height: 6),
          Text('${kmText(ride.distanceKm)} · ${money(ride.total)} · ${ride.paymentMethod == 'wave' ? 'Wave' : 'Espèces'}', style: const TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 10),
          Row(children: [
            Expanded(
              child: OutlinedButton(
                onPressed: () async {
                  final msg = await dp.respond(ride, false);
                  if (msg != null && context.mounted) snack(context, msg);
                },
                child: const Text('Refuser'),
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: ElevatedButton(
                onPressed: () async {
                  final msg = await dp.respond(ride, true);
                  if (!context.mounted) return;
                  if (msg != null) {
                    snack(context, msg);
                  } else {
                    Navigator.of(context).push(MaterialPageRoute(builder: (_) => const DriverRideScreen()));
                  }
                },
                child: const Text('Accepter'),
              ),
            ),
          ]),
        ]),
      ),
    );
  }
}

const _keepLauncher = callPhone;
