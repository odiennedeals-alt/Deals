import 'package:flutter/material.dart';
import '../../core/utils/errors.dart';
import '../../core/utils/format.dart';
import '../../core/utils/json.dart';
import '../../services/api.dart';
import '../../widgets/common.dart';

/// Trajets interurbains proposés par le conducteur et gestion des réservations.
class DriverInterurbanScreen extends StatefulWidget {
  const DriverInterurbanScreen({super.key});
  @override
  State<DriverInterurbanScreen> createState() => _DriverInterurbanScreenState();
}

class _DriverInterurbanScreenState extends State<DriverInterurbanScreen> {
  List<Map<String, dynamic>>? trips;
  List<Map<String, dynamic>> cities = [];
  String? error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final t = await Api.myTrips();
      final c = await Api.cities();
      if (mounted) setState(() { trips = t; cities = c; error = null; });
    } catch (e) {
      if (mounted) setState(() => error = errorMessage(e));
    }
  }

  Future<void> _create() async {
    String? from = cities.isNotEmpty ? toS(cities.first['id']) : null;
    String? to;
    DateTime? when;
    final seats = TextEditingController(text: '4');
    final price = TextEditingController();
    final notes = TextEditingController();
    final items = [for (final c in cities) DropdownMenuItem<String>(value: toS(c['id']), child: Text(toS(c['name'])))];
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          title: const Text('Nouveau trajet interurbain'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              DropdownButtonFormField<String>(value: from, items: items, onChanged: (v) => setS(() => from = v), decoration: const InputDecoration(labelText: 'Départ')),
              const SizedBox(height: 8),
              DropdownButtonFormField<String>(value: to, items: items, onChanged: (v) => setS(() => to = v), decoration: const InputDecoration(labelText: 'Arrivée')),
              const SizedBox(height: 8),
              OutlinedButton(
                onPressed: () async {
                  final d = await showDatePicker(context: ctx, initialDate: DateTime.now().add(const Duration(days: 1)), firstDate: DateTime.now(), lastDate: DateTime.now().add(const Duration(days: 180)));
                  if (d == null || !ctx.mounted) return;
                  final t = await showTimePicker(context: ctx, initialTime: const TimeOfDay(hour: 8, minute: 0));
                  if (t != null) setS(() => when = DateTime(d.year, d.month, d.day, t.hour, t.minute));
                },
                child: Text(when == null ? 'Date et heure de départ' : dateTimeText(when)),
              ),
              const SizedBox(height: 8),
              TextField(controller: seats, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Places (1 à 8)')),
              const SizedBox(height: 8),
              TextField(controller: price, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Prix par place (FCFA)')),
              const SizedBox(height: 8),
              TextField(controller: notes, decoration: const InputDecoration(labelText: 'Informations (optionnel)')),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
            TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Publier')),
          ],
        ),
      ),
    );
    if (ok != true) return;
    if (from == null || to == null || when == null || int.tryParse(seats.text) == null || int.tryParse(price.text) == null) {
      if (mounted) snack(context, 'Remplissez tous les champs.');
      return;
    }
    try {
      await Api.createTrip(fromCity: from!, toCity: to!, departure: when!, seats: int.parse(seats.text), price: int.parse(price.text), notes: notes.text.trim().isEmpty ? null : notes.text.trim());
      if (mounted) snack(context, 'Trajet publié.');
      _load();
    } catch (e) {
      if (mounted) snack(context, errorMessage(e));
    }
  }

  Future<void> _bookings(Map<String, dynamic> trip) async {
    await showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => _BookingsSheet(tripId: toS(trip['id'])),
    );
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Mes trajets interurbains')),
      floatingActionButton: FloatingActionButton.extended(onPressed: _create, icon: const Icon(Icons.add), label: const Text('Nouveau trajet')),
      body: error != null
          ? ErrorView(message: error!, onRetry: _load)
          : trips == null
              ? const LoadingView()
              : trips!.isEmpty
                  ? const EmptyState(icon: Icons.luggage_outlined, title: 'Aucun trajet', subtitle: 'Publiez un trajet entre deux villes. Un abonnement actif est nécessaire.')
                  : ListView(padding: const EdgeInsets.all(16), children: [
                      for (final t in trips!)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 10),
                          child: AppCard(
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Text('${toS(toMap(t['from'])?['name'])} → ${toS(toMap(t['to'])?['name'])}', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                              Text('${dateTimeText(toDate(t['departure_at']))} · ${money(toI(t['price_fcfa']))} · ${toI(t['seats_available'])}/${toI(t['seats_total'])} place(s)'),
                              const SizedBox(height: 6),
                              Row(children: [
                                Pill(toS(t['status']) == 'open' ? 'Ouvert' : toS(t['status']) == 'full' ? 'Complet' : toS(t['status']) == 'cancelled' ? 'Annulé' : 'Terminé'),
                                const Spacer(),
                                TextButton(onPressed: () => _bookings(t), child: const Text('Réservations')),
                                if (toS(t['status']) == 'open' || toS(t['status']) == 'full')
                                  TextButton(
                                    onPressed: () async {
                                      if (!await confirmDialog(context, 'Annuler ce trajet ?', 'Les passagers seront prévenus.', danger: true)) return;
                                      try { await Api.cancelTrip(toS(t['id'])); _load(); } catch (e) { if (mounted) snack(context, errorMessage(e)); }
                                    },
                                    child: const Text('Annuler', style: TextStyle(color: Color(0xFFB91C1C))),
                                  ),
                              ]),
                            ]),
                          ),
                        ),
                    ]),
    );
  }
}

class _BookingsSheet extends StatefulWidget {
  final String tripId;
  const _BookingsSheet({required this.tripId});
  @override
  State<_BookingsSheet> createState() => _BookingsSheetState();
}

class _BookingsSheetState extends State<_BookingsSheet> {
  List<Map<String, dynamic>>? items;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final l = await Api.tripBookings(widget.tripId);
      if (mounted) setState(() => items = l);
    } catch (e) {
      if (mounted) { setState(() => items = []); snack(context, errorMessage(e)); }
    }
  }

  Future<void> _respond(Map<String, dynamic> b, bool accept) async {
    try {
      await Api.respondBooking(toS(b['id']), accept);
      _load();
    } catch (e) {
      if (mounted) snack(context, errorMessage(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const Text('Réservations', style: TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
          const SizedBox(height: 10),
          if (items == null) const LoadingView()
          else if (items!.isEmpty) const Padding(padding: EdgeInsets.all(16), child: Text('Aucune réservation pour ce trajet.'))
          else
            for (final b in items!)
              ListTile(
                contentPadding: EdgeInsets.zero,
                title: Text('Passager · ${toI(b['seats'])} place(s)', style: const TextStyle(fontWeight: FontWeight.w700)),
                subtitle: Text(dateTimeText(toDate(b['created_at']))),
                trailing: toS(b['status']) == 'requested'
                    ? Row(mainAxisSize: MainAxisSize.min, children: [
                        IconButton(onPressed: () => _respond(b, false), icon: const Icon(Icons.close, color: Color(0xFFB91C1C))),
                        IconButton(onPressed: () => _respond(b, true), icon: const Icon(Icons.check, color: Color(0xFF15803D))),
                      ])
                    : Pill(toS(b['status']) == 'accepted' ? 'Acceptée' : toS(b['status']) == 'declined' ? 'Refusée' : 'Annulée'),
              ),
          const Padding(padding: EdgeInsets.only(top: 6), child: Text("Le passager vous appellera depuis la fiche du trajet. Son numéro n'est pas affiché ici.", style: TextStyle(fontSize: 12))),
        ]),
      ),
    );
  }
}
