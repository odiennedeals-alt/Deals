import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/errors.dart';
import '../../core/utils/format.dart';
import '../../models/place.dart';
import '../../models/ride.dart';
import '../../providers/driver_provider.dart';
import '../../services/api.dart';
import '../../services/geo_service.dart';
import '../../services/launcher.dart';
import '../../widgets/common.dart';
import '../../widgets/deals_map.dart';
import '../../widgets/logo.dart';
import '../safety/sos_sheet.dart';
import '../tracking/chat_screen.dart';

/// Course en cours côté conducteur : navigation GPS, appel du client, étapes de la course.
class DriverRideScreen extends StatefulWidget {
  const DriverRideScreen({super.key});
  @override
  State<DriverRideScreen> createState() => _DriverRideScreenState();
}

class _DriverRideScreenState extends State<DriverRideScreen> {
  RouteInfo? route;
  String? routeFor;
  bool busy = false;

  Future<void> _ensureRoute(Ride r) async {
    if (routeFor == r.id) return;
    routeFor = r.id;
    final info = await GeoService.route(LatLng(r.pickupLat, r.pickupLng), LatLng(r.destLat, r.destLng));
    if (mounted) setState(() => route = info);
  }

  Future<void> _advance(Ride r, String status, String okMessage) async {
    setState(() => busy = true);
    final msg = await context.read<DriverProvider>().advance(r, status);
    if (!mounted) return;
    setState(() => busy = false);
    if (msg != null) {
      snack(context, msg);
      return;
    }
    if (status == 'completed') {
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Course terminée'),
          content: Text('Montant à encaisser : ${money(r.total)}\nPaiement : ${r.paymentMethod == 'wave' ? 'Wave' : 'Espèces'}'),
          actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('OK'))],
        ),
      );
      if (mounted) Navigator.of(context).pop();
    } else {
      snack(context, okMessage);
    }
  }

  Future<void> _cancel(Ride r) async {
    if (!await confirmDialog(context, 'Annuler la course ?', 'Le client sera prévenu et pourra choisir un autre conducteur.', okLabel: 'Annuler la course', danger: true)) return;
    try {
      await Api.cancelRide(r.id, 'Annulée par le conducteur');
      if (!mounted) return;
      await context.read<DriverProvider>().refresh();
      if (mounted) Navigator.of(context).pop();
    } catch (e) {
      if (mounted) snack(context, errorMessage(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    final r = context.watch<DriverProvider>().active;
    if (r == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Course')),
        body: const EmptyState(icon: Icons.check_circle_outline, title: 'Aucune course en cours'),
      );
    }
    _ensureRoute(r);
    final pickup = LatLng(r.pickupLat, r.pickupLng);
    final dest = LatLng(r.destLat, r.destLng);
    final toClient = r.status == 'accepted' || r.status == 'arrived';

    return Scaffold(
      appBar: AppBar(title: Text(AppConstants.rideStatusLabels[r.status] ?? 'Course')),
      body: Column(children: [
        Expanded(
          flex: 4,
          child: DealsMap(center: pickup, route: route?.points ?? const [], markers: [dotMarker(pickup, const Color(0xFF2563EB)), pinMarker(dest, Icons.flag_rounded, AppColors.red, size: 34)]),
        ),
        Expanded(
          flex: 6,
          child: ListView(padding: const EdgeInsets.all(16), children: [
            Row(children: [
              UserAvatar(path: r.clientAvatarPath, label: r.clientName, radius: 26),
              const SizedBox(width: 12),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(r.clientName ?? 'Client', style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
                  Text(prettyPhone(r.clientPhone), style: const TextStyle(color: AppColors.greyText)),
                ]),
              ),
              Text(money(r.total), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 18)),
            ]),
            const SizedBox(height: 8),
            InfoRow('Départ', r.pickupLabel),
            InfoRow('Destination', r.destLabel),
            InfoRow('Paiement', r.paymentMethod == 'wave' ? 'Wave' : 'Espèces'),
            const SizedBox(height: 8),
            Row(children: [
              Expanded(child: OutlinedButton.icon(onPressed: () => callPhone(r.clientPhone ?? ''), icon: const Icon(Icons.call), label: const Text('Appeler'))),
              const SizedBox(width: 8),
              Expanded(child: OutlinedButton.icon(onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ChatScreen(rideId: r.id, title: r.clientName ?? 'Client'))), icon: const Icon(Icons.chat_bubble_outline), label: const Text('Message'))),
              const SizedBox(width: 8),
              IconButton.filled(style: IconButton.styleFrom(backgroundColor: const Color(0xFFDC2626)), onPressed: () => showSosSheet(context, rideId: r.id), icon: const Icon(Icons.sos_rounded)),
            ]),
            const SizedBox(height: 10),
            OutlinedButton.icon(
              onPressed: () => openNavigation(toClient ? r.pickupLat : r.destLat, toClient ? r.pickupLng : r.destLng),
              icon: const Icon(Icons.navigation_outlined),
              label: Text(toClient ? 'Naviguer vers le client' : 'Naviguer vers la destination'),
            ),
            const SizedBox(height: 12),
            if (r.status == 'accepted') ...[
              ElevatedButton(onPressed: busy ? null : () => _advance(r, 'arrived', 'Le client est prévenu de votre arrivée.'), child: const Text("Je suis arrivé")),
              const SizedBox(height: 8),
              OutlinedButton(onPressed: busy ? null : () => _advance(r, 'in_progress', 'Course démarrée.'), child: const Text('Démarrer la course')),
            ],
            if (r.status == 'arrived') ElevatedButton(onPressed: busy ? null : () => _advance(r, 'in_progress', 'Course démarrée.'), child: const Text('Démarrer la course')),
            if (r.status == 'in_progress')
              ElevatedButton(
                onPressed: busy
                    ? null
                    : () async {
                        if (await confirmDialog(context, 'Terminer la course ?', 'Confirmez que le client est arrivé à destination.', okLabel: 'Terminer')) {
                          await _advance(r, 'completed', '');
                        }
                      },
                child: const Text('Terminer la course'),
              ),
            if (r.status != 'in_progress') ...[
              const SizedBox(height: 8),
              TextButton(onPressed: () => _cancel(r), child: const Text('Annuler la course', style: TextStyle(color: Color(0xFFB91C1C)))),
            ],
          ]),
        ),
      ]),
    );
  }
}

const _k = DealsLogo;
