import 'package:flutter/material.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/errors.dart';
import '../../core/utils/format.dart';
import '../../core/utils/json.dart';
import '../../models/ride.dart';
import '../../services/api.dart';
import '../../widgets/common.dart';
import '../history/receipt_screen.dart';

class EarningsScreen extends StatefulWidget {
  const EarningsScreen({super.key});
  @override
  State<EarningsScreen> createState() => _EarningsScreenState();
}

class _EarningsScreenState extends State<EarningsScreen> {
  Map<String, dynamic>? e;
  List<Ride> rides = [];
  String? error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final a = await Api.earnings();
      final b = await Api.driverHistory();
      if (mounted) setState(() { e = a; rides = b; error = null; });
    } catch (x) {
      if (mounted) setState(() => error = errorMessage(x));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Mes gains')),
      body: error != null
          ? ErrorView(message: error!, onRetry: _load)
          : e == null
              ? const LoadingView()
              : RefreshIndicator(
                  onRefresh: _load,
                  child: ListView(padding: const EdgeInsets.all(16), children: [
                    Row(children: [
                      Expanded(child: _Box('Aujourd\'hui', money(toI(e!['today'])), '${toI(e!['rides_today'])} course(s)')),
                      const SizedBox(width: 10),
                      Expanded(child: _Box('Cette semaine', money(toI(e!['week'])), '${toI(e!['rides_week'])} course(s)')),
                    ]),
                    const SizedBox(height: 10),
                    Row(children: [
                      Expanded(child: _Box('Ce mois', money(toI(e!['month'])), '${toI(e!['rides_month'])} course(s)')),
                      const SizedBox(width: 10),
                      Expanded(child: _Box('Note moyenne', toD(e!['rating_avg']) == 0 ? 'Nouveau' : '★ ${toD(e!['rating_avg']).toStringAsFixed(2)}', '${toI(e!['ratings_count'])} avis')),
                    ]),
                    const SectionTitle('Historique des courses'),
                    if (rides.isEmpty) const AppCard(child: Text('Aucune course pour le moment.')),
                    for (final r in rides)
                      Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: AppCard(
                          onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ReceiptScreen(ride: r, asDriver: true))),
                          child: Row(children: [
                            Expanded(
                              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Text(r.destLabel, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800)),
                                Text('${dateTimeText(r.createdAt)} · ${r.clientName ?? 'Client'}', style: const TextStyle(fontSize: 12, color: AppColors.greyText)),
                              ]),
                            ),
                            Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                              Text(money(r.total), style: const TextStyle(fontWeight: FontWeight.w800)),
                              r.status == 'completed' ? Pill.ok('Terminée') : Pill(AppConstants.rideStatusLabels[r.status] ?? r.status),
                            ]),
                          ]),
                        ),
                      ),
                  ]),
                ),
    );
  }
}

class _Box extends StatelessWidget {
  final String title;
  final String value;
  final String sub;
  const _Box(this.title, this.value, this.sub);
  @override
  Widget build(BuildContext context) => AppCard(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: const TextStyle(color: AppColors.greyText, fontSize: 12)),
          const SizedBox(height: 4),
          Text(value, style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900)),
          Text(sub, style: const TextStyle(fontSize: 12)),
        ]),
      );
}
