import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/errors.dart';
import '../../core/utils/format.dart';
import '../../core/utils/json.dart';
import '../../providers/auth_provider.dart';
import '../../services/api.dart';
import '../../services/media.dart';
import '../../services/supa.dart';
import '../../widgets/common.dart';
import 'certification_screen.dart';

const _statusLabels = {'in_service': 'En service', 'in_repair': 'En réparation', 'out_of_service': 'Hors service'};

class VehicleScreen extends StatefulWidget {
  const VehicleScreen({super.key});
  @override
  State<VehicleScreen> createState() => _VehicleScreenState();
}

class _VehicleScreenState extends State<VehicleScreen> {
  List<Map<String, dynamic>>? vehicles;
  List<Map<String, dynamic>> alerts = [];
  String? error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final v = await Api.myVehicles();
      final a = await Api.maintenance();
      if (mounted) setState(() { vehicles = v; alerts = a; error = null; });
    } catch (e) {
      if (mounted) setState(() => error = errorMessage(e));
    }
  }

  Future<void> _setStatus(Map<String, dynamic> v, String status) async {
    try {
      await Api.updateVehicle(toS(v['id']), {'status': status});
      if (mounted) await context.read<AuthProvider>().refresh();
      _load();
    } catch (e) {
      if (mounted) snack(context, errorMessage(e));
    }
  }

  Future<void> _photo(Map<String, dynamic> v, {required bool plate}) async {
    final img = await pickImage();
    if (img == null) return;
    if (!mounted) return;
    try {
      if (plate) {
        final path = await Api.uploadImage('private-docs', img.bytes, img.nameWith('plate'), contentType: img.contentType);
        await Api.updateVehicle(toS(v['id']), {'plate_photo_path': path});
        await Api.submitDocument('plate_photo', path);
      } else {
        final path = await Api.uploadImage('public-media', img.bytes, img.nameWith('vehicle'), contentType: img.contentType);
        await Api.updateVehicle(toS(v['id']), {'photo_path': path});
      }
      if (mounted) snack(context, 'Photo enregistrée.');
      _load();
    } catch (e) {
      if (mounted) snack(context, errorMessage(e));
    }
  }

  Future<void> _addAlert() async {
    String kind = 'oil_change';
    DateTime? due;
    final note = TextEditingController();
    final days = TextEditingController(text: '7');
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          title: const Text("Nouvelle alerte d'entretien"),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              DropdownButtonFormField<String>(
                value: kind,
                items: [for (final e in AppConstants.maintenanceKinds.entries) DropdownMenuItem(value: e.key, child: Text(e.value))],
                onChanged: (v) => setS(() => kind = v ?? kind),
                decoration: const InputDecoration(labelText: 'Type'),
              ),
              const SizedBox(height: 10),
              OutlinedButton(
                onPressed: () async {
                  final d = await showDatePicker(context: ctx, initialDate: DateTime.now().add(const Duration(days: 30)), firstDate: DateTime.now(), lastDate: DateTime.now().add(const Duration(days: 1500)));
                  if (d != null) setS(() => due = d);
                },
                child: Text(due == null ? "Choisir la date d'échéance" : dayText(due)),
              ),
              const SizedBox(height: 10),
              TextField(controller: days, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Me prévenir X jours avant')),
              const SizedBox(height: 10),
              TextField(controller: note, decoration: const InputDecoration(labelText: 'Note (optionnel)')),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
            TextButton(onPressed: () => Navigator.pop(ctx, due != null), child: const Text('Ajouter')),
          ],
        ),
      ),
    );
    if (ok != true || due == null) return;
    final vehicleId = vehicles != null && vehicles!.isNotEmpty ? toS(vehicles!.first['id']) : null;
    try {
      await Api.addMaintenance({
        'kind': kind,
        'due_date': '${due!.year}-${two(due!.month)}-${two(due!.day)}',
        'remind_before_days': int.tryParse(days.text) ?? 7,
        'note': note.text.trim().isEmpty ? null : note.text.trim(),
        'vehicle_id': vehicleId,
      });
      _load();
    } catch (e) {
      if (mounted) snack(context, errorMessage(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    return Scaffold(
      appBar: AppBar(title: const Text('Mon véhicule')),
      body: !auth.isDriver
          ? const EmptyState(icon: Icons.directions_car_outlined, title: "Vous n'êtes pas encore conducteur")
          : error != null
              ? ErrorView(message: error!, onRetry: _load)
              : vehicles == null
                  ? const LoadingView()
                  : ListView(padding: const EdgeInsets.all(16), children: [
                      for (final v in vehicles!) _vehicleCard(v),
                      AppCard(
                        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const CertificationScreen())),
                        child: Row(children: const [
                          Icon(Icons.verified_outlined),
                          SizedBox(width: 12),
                          Expanded(child: Text('Certification et documents', style: TextStyle(fontWeight: FontWeight.w800))),
                          Icon(Icons.chevron_right),
                        ]),
                      ),
                      SectionTitle("Alertes d'entretien"),
                      if (alerts.isEmpty) const AppCard(child: Text('Aucune alerte. Ajoutez vidange, pneus, freins, assurance ou visite technique.')),
                      for (final a in alerts)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: AppCard(
                            child: Row(children: [
                              Icon(a['is_done'] == true ? Icons.check_circle : Icons.build_circle_outlined, color: a['is_done'] == true ? AppColors.green : AppColors.amber),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                  Text(AppConstants.maintenanceKinds[toS(a['kind'])] ?? toS(a['kind']), style: const TextStyle(fontWeight: FontWeight.w800)),
                                  Text('Échéance : ${dayText(DateTime.tryParse(toS(a['due_date'])))}', style: const TextStyle(fontSize: 12)),
                                ]),
                              ),
                              if (a['is_done'] != true) IconButton(onPressed: () async { await Api.updateMaintenance(toS(a['id']), {'is_done': true, 'done_at': DateTime.now().toUtc().toIso8601String()}); _load(); }, icon: const Icon(Icons.check)),
                              IconButton(onPressed: () async { await Api.deleteMaintenance(toS(a['id'])); _load(); }, icon: const Icon(Icons.delete_outline)),
                            ]),
                          ),
                        ),
                      const SizedBox(height: 8),
                      OutlinedButton.icon(onPressed: _addAlert, icon: const Icon(Icons.add), label: const Text('Ajouter une alerte')),
                    ]),
    );
  }

  Widget _vehicleCard(Map<String, dynamic> v) {
    final photo = publicUrl(v['photo_path'] as String?);
    return Padding(
      padding: const EdgeInsets.only(bottom: 12),
      child: AppCard(
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          if (photo != null) ClipRRect(borderRadius: BorderRadius.circular(12), child: Image.network(photo, height: 150, width: double.infinity, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const SizedBox())),
          const SizedBox(height: 8),
          Text('${toS(v['brand'])} ${toS(v['model'])}', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
          Text('${AppConstants.vehicleLabels[toS(v['vehicle_type'])]} · ${toS(v['color'])} · ${toS(v['plate_number'])}'),
          const SizedBox(height: 10),
          DropdownButtonFormField<String>(
            value: toS(v['status']),
            items: [for (final e in _statusLabels.entries) DropdownMenuItem(value: e.key, child: Text(e.value))],
            onChanged: (s) { if (s != null) _setStatus(v, s); },
            decoration: const InputDecoration(labelText: 'État du véhicule'),
          ),
          const SizedBox(height: 8),
          Row(children: [
            Expanded(child: OutlinedButton(onPressed: () => _photo(v, plate: false), child: const Text('Photo du véhicule'))),
            const SizedBox(width: 8),
            Expanded(child: OutlinedButton(onPressed: () => _photo(v, plate: true), child: const Text('Photo de la plaque'))),
          ]),
          const Padding(
            padding: EdgeInsets.only(top: 6),
            child: Text('Seul un véhicule « En service » vous permet de passer en ligne.', style: TextStyle(fontSize: 12, color: AppColors.greyText)),
          ),
        ]),
      ),
    );
  }
}
