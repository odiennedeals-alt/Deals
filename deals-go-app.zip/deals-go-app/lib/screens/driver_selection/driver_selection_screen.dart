import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/errors.dart';
import '../../core/utils/format.dart';
import '../../models/driver_card.dart';
import '../../models/place.dart';
import '../../providers/ride_provider.dart';
import '../../services/api.dart';
import '../../services/geo_service.dart';
import '../../services/local_store.dart';
import '../../services/supa.dart';
import '../../widgets/common.dart';
import '../../widgets/deals_map.dart';
import '../../widgets/logo.dart';
import '../tracking/tracking_screen.dart';

/// Le client voit les conducteurs disponibles et choisit lui-même le sien.
class DriverSelectionScreen extends StatefulWidget {
  final String vehicleType;
  final Place pickup;
  final Place dest;
  const DriverSelectionScreen({super.key, required this.vehicleType, required this.pickup, required this.dest});
  @override
  State<DriverSelectionScreen> createState() => _DriverSelectionScreenState();
}

class _DriverSelectionScreenState extends State<DriverSelectionScreen> {
  RouteInfo? route;
  List<DriverCard> drivers = [];
  bool loading = true;
  String? error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    setState(() { loading = true; error = null; });
    try {
      route ??= await GeoService.route(widget.pickup.point, widget.dest.point);
      drivers = await Api.listDrivers(
        vehicleType: widget.vehicleType,
        lat: widget.pickup.point.latitude,
        lng: widget.pickup.point.longitude,
        destLat: widget.dest.point.latitude,
        destLng: widget.dest.point.longitude,
        tripKm: route!.distanceKm,
      );
    } catch (e) {
      error = errorMessage(e);
    }
    if (mounted) setState(() => loading = false);
  }

  Future<void> _open(DriverCard d) async {
    final ride = await showModalBottomSheet<String>(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (_) => _DriverSheet(driver: d, vehicleType: widget.vehicleType, pickup: widget.pickup, dest: widget.dest, route: route!),
    );
    if (ride == 'refresh') {
      _load();
    } else if (ride != null && mounted) {
      Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => TrackingScreen(rideId: ride)), (r) => r.isFirst);
    }
  }

  @override
  Widget build(BuildContext context) {
    final r = route;
    return Scaffold(
      appBar: AppBar(title: const Text('Choisissez votre conducteur'), actions: [IconButton(onPressed: _load, icon: const Icon(Icons.refresh))]),
      body: loading
          ? const LoadingView()
          : error != null
              ? ErrorView(message: error!, onRetry: _load)
              : ListView(padding: const EdgeInsets.all(16), children: [
                  if (r != null)
                    ClipRRect(
                      borderRadius: BorderRadius.circular(18),
                      child: SizedBox(
                        height: 180,
                        child: DealsMap(
                          center: LatLng((widget.pickup.point.latitude + widget.dest.point.latitude) / 2, (widget.pickup.point.longitude + widget.dest.point.longitude) / 2),
                          zoom: 13,
                          route: r.points,
                          markers: [
                            dotMarker(widget.pickup.point, const Color(0xFF2563EB)),
                            pinMarker(widget.dest.point, Icons.flag_rounded, AppColors.red, size: 34),
                            for (final d in drivers) pinMarker(LatLng(d.lat, d.lng), widget.vehicleType == 'moto' ? Icons.two_wheeler : Icons.local_taxi, AppColors.green, size: 28),
                          ],
                        ),
                      ),
                    ),
                  const SizedBox(height: 12),
                  if (r != null)
                    AppCard(
                      child: Column(children: [
                        Row(children: [const Icon(Icons.my_location, size: 18, color: Color(0xFF2563EB)), const SizedBox(width: 8), Expanded(child: Text(widget.pickup.label, maxLines: 1, overflow: TextOverflow.ellipsis))]),
                        const SizedBox(height: 6),
                        Row(children: [const Icon(Icons.flag_rounded, size: 18, color: AppColors.red), const SizedBox(width: 8), Expanded(child: Text(widget.dest.label, maxLines: 1, overflow: TextOverflow.ellipsis))]),
                        const Divider(height: 20),
                        Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
                          Text('${kmText(r.distanceKm)}${r.estimated ? ' (estimée)' : ''}', style: const TextStyle(fontWeight: FontWeight.w700)),
                          Text('${r.durationMin} min', style: const TextStyle(fontWeight: FontWeight.w700)),
                          Text(AppConstants.vehicleLabels[widget.vehicleType] ?? '', style: const TextStyle(fontWeight: FontWeight.w700)),
                        ]),
                      ]),
                    ),
                  const SectionTitle('Conducteurs disponibles'),
                  if (drivers.isEmpty)
                    const AppCard(child: Text("Aucun conducteur disponible pour ce trajet pour le moment. Réessayez dans quelques instants.")),
                  for (final d in drivers)
                    Padding(
                      padding: const EdgeInsets.only(bottom: 10),
                      child: AppCard(
                        onTap: () => _open(d),
                        child: Row(children: [
                          UserAvatar(path: d.avatarPath, label: d.name, radius: 28),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Row(children: [
                                Flexible(child: Text(d.name, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16))),
                                if (d.certified) ...[const SizedBox(width: 6), const Icon(Icons.verified_rounded, color: Color(0xFF1D4ED8), size: 18)],
                              ]),
                              Text('★ ${d.rating == 0 ? 'Nouveau' : d.rating.toStringAsFixed(1)} · ${d.rides} course${d.rides > 1 ? 's' : ''}', style: const TextStyle(color: AppColors.greyText, fontSize: 13)),
                              Text('${d.vehicleLabel}', maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontSize: 13)),
                              Text('${kmText(d.distanceKm)} · arrive dans ~${d.etaMin} min', style: const TextStyle(color: AppColors.greyText, fontSize: 12)),
                            ]),
                          ),
                          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                            Text(d.price == null ? '—' : money(d.price), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                            if (d.premium) Pill.info('Premium'),
                          ]),
                        ]),
                      ),
                    ),
                ]),
    );
  }
}

class _DriverSheet extends StatefulWidget {
  final DriverCard driver;
  final String vehicleType;
  final Place pickup;
  final Place dest;
  final RouteInfo route;
  const _DriverSheet({required this.driver, required this.vehicleType, required this.pickup, required this.dest, required this.route});
  @override
  State<_DriverSheet> createState() => _DriverSheetState();
}

class _DriverSheetState extends State<_DriverSheet> {
  String payment = 'cash';
  final promo = TextEditingController();
  bool busy = false;

  @override
  void initState() {
    super.initState();
    LocalStore.promo().then((p) {
      if (p != null && mounted) promo.text = p;
    });
  }

  @override
  void dispose() {
    promo.dispose();
    super.dispose();
  }

  Future<void> _choose() async {
    setState(() => busy = true);
    final d = widget.driver;
    try {
      final ride = await Api.requestRide(
        driverId: d.id,
        vehicleType: widget.vehicleType,
        pickupLabel: widget.pickup.label,
        pickupLat: widget.pickup.point.latitude,
        pickupLng: widget.pickup.point.longitude,
        destLabel: widget.dest.label,
        destLat: widget.dest.point.latitude,
        destLng: widget.dest.point.longitude,
        distanceKm: widget.route.distanceKm,
        durationMin: widget.route.durationMin,
        paymentMethod: payment,
        promo: promo.text,
      );
      if (!mounted) return;
      context.read<RideProvider>().setActive(ride);
      Navigator.of(context).pop(ride.id);
    } catch (e) {
      if (!mounted) return;
      final msg = errorMessage(e);
      snack(context, msg);
      setState(() => busy = false);
      final code = e.toString();
      if (code.contains('driver_unavailable') || code.contains('driver_busy')) Navigator.of(context).pop('refresh');
    }
  }

  @override
  Widget build(BuildContext context) {
    final d = widget.driver;
    final photo = publicUrl(d.vehiclePhotoPath);
    return Padding(
      padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom),
      child: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
            Row(children: [
              UserAvatar(path: d.avatarPath, label: d.name, radius: 34),
              const SizedBox(width: 14),
              Expanded(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(d.name, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900)),
                  Text('★ ${d.rating == 0 ? 'Nouveau' : d.rating.toStringAsFixed(1)} · ${d.rides} course${d.rides > 1 ? 's' : ''}', style: const TextStyle(color: AppColors.greyText)),
                  const SizedBox(height: 4),
                  Wrap(spacing: 6, children: [if (d.certified) Pill.info('Conducteur certifié'), if (d.premium) Pill.warn('Premium')]),
                ]),
              ),
            ]),
            if (photo != null) ...[
              const SizedBox(height: 12),
              ClipRRect(borderRadius: BorderRadius.circular(14), child: Image.network(photo, height: 150, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const SizedBox())),
            ],
            const SizedBox(height: 12),
            InfoRow('Véhicule', '${d.brand} ${d.model}'),
            InfoRow('Couleur', d.color),
            InfoRow('Plaque', d.plate),
            InfoRow('Distance', '${kmText(d.distanceKm)} · ~${d.etaMin} min'),
            InfoRow('Téléphone', prettyPhone(d.phone)),
            InfoRow('Prix estimé', money(d.price)),
            const SizedBox(height: 10),
            const Text('Paiement', style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 6),
            Row(children: [
              Expanded(child: ChoiceChip(label: const Center(child: Text('Espèces')), selected: payment == 'cash', onSelected: (_) => setState(() => payment = 'cash'))),
              const SizedBox(width: 8),
              Expanded(child: ChoiceChip(label: const Center(child: Text('Wave (au conducteur)')), selected: payment == 'wave', onSelected: (_) => setState(() => payment = 'wave'))),
            ]),
            const SizedBox(height: 10),
            TextField(controller: promo, textCapitalization: TextCapitalization.characters, decoration: const InputDecoration(labelText: 'Code promotionnel (optionnel)')),
            const SizedBox(height: 14),
            ElevatedButton(
              onPressed: busy ? null : _choose,
              child: busy ? const SizedBox(height: 22, width: 22, child: CircularProgressIndicator(strokeWidth: 3, color: Colors.white)) : const Text('Choisir ce conducteur'),
            ),
            const SizedBox(height: 6),
            const Text("Le conducteur doit accepter votre demande. Le prix final peut varier légèrement selon l'itinéraire.", textAlign: TextAlign.center, style: TextStyle(color: AppColors.greyText, fontSize: 12)),
          ]),
        ),
      ),
    );
  }
}
