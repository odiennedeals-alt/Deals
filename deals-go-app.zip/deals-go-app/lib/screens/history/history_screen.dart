import 'package:flutter/material.dart';
import '../../core/constants/app_constants.dart';
import '../../core/utils/errors.dart';
import '../../core/utils/format.dart';
import '../../models/ride.dart';
import '../../services/api.dart';
import '../../widgets/common.dart';
import 'receipt_screen.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});
  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  List<Ride>? rides;
  String? error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final l = await Api.clientHistory();
      if (mounted) setState(() { rides = l; error = null; });
    } catch (e) {
      if (mounted) setState(() => error = errorMessage(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Historique')),
      body: error != null
          ? ErrorView(message: error!, onRetry: _load)
          : rides == null
              ? const LoadingView()
              : rides!.isEmpty
                  ? const EmptyState(icon: Icons.history, title: 'Aucune course', subtitle: 'Vos courses apparaîtront ici.')
                  : RefreshIndicator(
                      onRefresh: _load,
                      child: ListView.separated(
                        padding: const EdgeInsets.all(16),
                        itemCount: rides!.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 10),
                        itemBuilder: (_, i) {
                          final r = rides![i];
                          return AppCard(
                            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ReceiptScreen(ride: r))),
                            child: Row(children: [
                              Icon(r.vehicleType == 'moto' ? Icons.two_wheeler : Icons.local_taxi),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                  Text(r.destLabel, maxLines: 1, overflow: TextOverflow.ellipsis, style: const TextStyle(fontWeight: FontWeight.w800)),
                                  Text(dateTimeText(r.createdAt), style: const TextStyle(fontSize: 12)),
                                ]),
                              ),
                              Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
                                Text(money(r.total), style: const TextStyle(fontWeight: FontWeight.w800)),
                                r.status == 'completed' ? Pill.ok('Terminée') : Pill(AppConstants.rideStatusLabels[r.status] ?? r.status),
                              ]),
                            ]),
                          );
                        },
                      ),
                    ),
    );
  }
}
