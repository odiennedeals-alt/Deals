import 'package:flutter/material.dart';
import '../../core/constants/app_constants.dart';
import '../../core/utils/errors.dart';
import '../../core/utils/format.dart';
import '../../models/ride.dart';
import '../../services/api.dart';
import '../../widgets/common.dart';

class ReceiptScreen extends StatelessWidget {
  final Ride ride;
  final bool asDriver;
  const ReceiptScreen({super.key, required this.ride, this.asDriver = false});

  Future<void> _report(BuildContext context) async {
    final text = await promptDialog(context, 'Signaler un problème', hint: 'Décrivez ce qui s\'est passé (5 caractères minimum)', required: true, lines: 4);
    if (text == null || text.length < 5) return;
    try {
      await Api.submitReport('behavior', text, rideId: ride.id);
      if (context.mounted) snack(context, 'Signalement envoyé à l\'administration.');
    } catch (e) {
      if (context.mounted) snack(context, errorMessage(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    final r = ride;
    return Scaffold(
      appBar: AppBar(title: const Text('Reçu de course')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        AppCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(money(r.total), style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w900)),
            Text(AppConstants.rideStatusLabels[r.status] ?? r.status, style: const TextStyle(fontWeight: FontWeight.w700)),
            const Divider(height: 24),
            InfoRow('Date', dateTimeText(r.createdAt)),
            InfoRow('Départ', r.pickupLabel),
            InfoRow('Destination', r.destLabel),
            InfoRow('Distance', kmText(r.distanceKm)),
            InfoRow('Catégorie', AppConstants.vehicleLabels[r.vehicleType] ?? r.vehicleType),
            InfoRow(asDriver ? 'Client' : 'Conducteur', (asDriver ? r.clientName : r.driverName) ?? '—'),
            if (!asDriver) InfoRow('Véhicule', r.vehicleText),
            InfoRow('Prix estimé', money(r.price)),
            if (r.discount > 0) InfoRow('Réduction', '- ${money(r.discount)}'),
            InfoRow('Paiement', r.paymentMethod == 'wave' ? 'Wave (au conducteur)' : 'Espèces'),
          ]),
        ),
        const SizedBox(height: 14),
        OutlinedButton.icon(onPressed: () => _report(context), icon: const Icon(Icons.flag_outlined), label: const Text('Signaler un problème')),
      ]),
    );
  }
}
