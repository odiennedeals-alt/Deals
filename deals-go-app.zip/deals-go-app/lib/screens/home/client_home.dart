import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/errors.dart';
import '../../core/utils/format.dart';
import '../../models/driver_card.dart';
import '../../models/place.dart';
import '../../providers/auth_provider.dart';
import '../../providers/content_provider.dart';
import '../../providers/notifications_provider.dart';
import '../../providers/ride_provider.dart';
import '../../services/api.dart';
import '../../services/supa.dart';
import '../../services/geo_service.dart';
import '../../services/local_store.dart';
import '../../services/launcher.dart';
import '../../services/location_service.dart';
import '../../widgets/common.dart';
import '../../widgets/deals_map.dart';
import '../../widgets/logo.dart';
import '../destination/destination_screen.dart';
import '../interurban/interurban_screen.dart';
import '../notifications/notifications_screen.dart';
import '../tracking/tracking_screen.dart';

class ClientHome extends StatefulWidget {
  const ClientHome({super.key});
  @override
  State<ClientHome> createState() => _ClientHomeState();
}

class _ClientHomeState extends State<ClientHome> {
  final MapController map = MapController();
  LatLng? me;
  String vehicleType = 'car';
  List<DriverCard> drivers = [];
  Timer? timer;
  String? note;
  Map<String, dynamic>? storedContact;

  @override
  void initState() {
    super.initState();
    _init();
    timer = Timer.periodic(const Duration(seconds: 20), (_) => _loadDrivers());
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  Future<void> _init() async {
    storedContact = await LocalStore.rideContact();
    final p = await LocationService.current();
    if (!mounted) return;
    setState(() {
      me = p;
      if (p == null) note = "Localisation indisponible : activez le GPS pour voir les conducteurs proches.";
    });
    if (p != null) {
      try {
        map.move(p, AppConstants.defaultZoom);
      } catch (_) {}
    }
    await _loadDrivers();
  }

  Future<void> _loadDrivers() async {
    final p = me;
    if (p == null) return;
    try {
      final l = await Api.listDrivers(vehicleType: vehicleType, lat: p.latitude, lng: p.longitude);
      if (mounted) setState(() { drivers = l; note = null; });
    } catch (e) {
      if (mounted) setState(() => note = errorMessage(e));
    }
  }

  Future<void> _plan() async {
    final start = me == null ? null : Place('Ma position actuelle', me!);
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => DestinationScreen(vehicleType: vehicleType, initialPickup: start)));
  }

  @override
  Widget build(BuildContext context) {
    final ride = context.watch<RideProvider>().active;
    final unread = context.watch<NotificationsProvider>().unread;
    final auth = context.watch<AuthProvider>();
    final content = context.watch<ContentProvider>();
    final markers = <Marker>[
      for (final d in drivers)
        pinMarker(LatLng(d.lat, d.lng), vehicleType == 'moto' ? Icons.two_wheeler : Icons.local_taxi, d.premium ? AppColors.violet : AppColors.green, size: 34),
      if (me != null) dotMarker(me!, const Color(0xFF2563EB)),
    ];
    final banners = content.banners.where((b) => b['value'] != null).toList();

    return Stack(children: [
      Positioned.fill(child: DealsMap(center: me ?? AppConstants.odienneCenter, controller: map, markers: markers)),
      SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
              decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16), boxShadow: const [BoxShadow(color: Color(0x22000000), blurRadius: 8)]),
              child: const DealsLogo(size: 26),
            ),
            const Spacer(),
            if (auth.isDriver)
              _RoundButton(icon: Icons.swap_horiz_rounded, onTap: () => auth.setMode('driver')),
            const SizedBox(width: 8),
            Stack(children: [
              _RoundButton(icon: Icons.notifications_none_rounded, onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const NotificationsScreen()))),
              if (unread > 0)
                Positioned(right: 4, top: 4, child: CircleAvatar(radius: 9, backgroundColor: AppColors.red, child: Text('$unread', style: const TextStyle(fontSize: 10, color: Colors.white)))),
            ]),
          ]),
        ),
      ),
      Positioned(
        right: 12,
        bottom: 300,
        child: _RoundButton(icon: Icons.my_location_rounded, onTap: () async {
          final p = await LocationService.current();
          if (p != null) {
            setState(() => me = p);
            try { map.move(p, 15); } catch (_) {}
            _loadDrivers();
          }
        }),
      ),
      Align(
        alignment: Alignment.bottomCenter,
        child: Container(
          padding: const EdgeInsets.fromLTRB(16, 14, 16, 12),
          decoration: const BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.vertical(top: Radius.circular(26)),
            boxShadow: [BoxShadow(color: Color(0x33000000), blurRadius: 16)],
          ),
          child: SafeArea(
            top: false,
            child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
              if (ride != null)
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: AppCard(
                    color: const Color(0xFFFFF1F0),
                    onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => TrackingScreen(rideId: ride.id))),
                    child: Row(children: [
                      const Icon(Icons.local_taxi, color: AppColors.red),
                      const SizedBox(width: 10),
                      Expanded(child: Text('Course en cours : ${AppConstants.rideStatusLabels[ride.status] ?? ride.status}', style: const TextStyle(fontWeight: FontWeight.w700))),
                      const Icon(Icons.chevron_right),
                    ]),
                  ),
                )
              else if (storedContact != null)
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: AppCard(
                    child: Row(children: [
                      const Icon(Icons.phone_in_talk_outlined),
                      const SizedBox(width: 10),
                      Expanded(child: Text('Dernier contact : ${storedContact!['name'] ?? 'Conducteur'}', style: const TextStyle(fontWeight: FontWeight.w600))),
                      TextButton(onPressed: () => callPhone('${storedContact!['phone']}'), child: const Text('Appeler')),
                    ]),
                  ),
                ),
              Row(children: [
                Expanded(child: _TypeButton(label: 'Taxi auto', icon: Icons.local_taxi, selected: vehicleType == 'car', onTap: () { setState(() => vehicleType = 'car'); _loadDrivers(); })),
                const SizedBox(width: 10),
                Expanded(child: _TypeButton(label: 'Taxi moto', icon: Icons.two_wheeler, selected: vehicleType == 'moto', onTap: () { setState(() => vehicleType = 'moto'); _loadDrivers(); })),
                const SizedBox(width: 10),
                Expanded(child: _TypeButton(label: 'Interurbain', icon: Icons.luggage_outlined, selected: false, onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const InterurbanScreen())))),
              ]),
              const SizedBox(height: 12),
              InkWell(
                borderRadius: BorderRadius.circular(16),
                onTap: ride != null ? null : _plan,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                  decoration: BoxDecoration(color: AppColors.grey, borderRadius: BorderRadius.circular(16)),
                  child: Row(children: [
                    const Icon(Icons.search_rounded),
                    const SizedBox(width: 10),
                    Text(content.text('home.search_placeholder', 'Où allons-nous ?'), style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
                  ]),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                note ?? (drivers.isEmpty ? 'Aucun conducteur disponible autour de vous pour le moment.' : '${drivers.length} conducteur${drivers.length > 1 ? 's' : ''} disponible${drivers.length > 1 ? 's' : ''} autour de vous'),
                style: TextStyle(color: note != null ? const Color(0xFFB91C1C) : AppColors.greyText, fontSize: 13),
              ),
              if (banners.isNotEmpty && ride == null) ...[
                const SizedBox(height: 8),
                SizedBox(
                  height: 70,
                  child: ListView(scrollDirection: Axis.horizontal, children: [
                    for (final b in banners)
                      Padding(
                        padding: const EdgeInsets.only(right: 8),
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(12),
                          child: Builder(builder: (_) {
                            final path = (b['value'] as Map)['path'] as String?;
                            final url = publicUrlOrNull(path);
                            return url == null ? const SizedBox() : Image.network(url, height: 70, fit: BoxFit.cover, errorBuilder: (_, __, ___) => const SizedBox());
                          }),
                        ),
                      ),
                  ]),
                ),
              ],
            ]),
          ),
        ),
      ),
    ]);
  }
}

String? publicUrlOrNull(String? path) => path == null ? null : _pub(path);
String? _pub(String path) {
  try {
    return publicUrlFor(path);
  } catch (_) {
    return null;
  }
}

class _RoundButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _RoundButton({required this.icon, required this.onTap});
  @override
  Widget build(BuildContext context) => Material(
        color: Colors.white,
        shape: const CircleBorder(),
        elevation: 3,
        child: InkWell(customBorder: const CircleBorder(), onTap: onTap, child: Padding(padding: const EdgeInsets.all(11), child: Icon(icon))),
      );
}

class _TypeButton extends StatelessWidget {
  final String label;
  final IconData icon;
  final bool selected;
  final VoidCallback onTap;
  const _TypeButton({required this.label, required this.icon, required this.selected, required this.onTap});
  @override
  Widget build(BuildContext context) => InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(vertical: 12),
          decoration: BoxDecoration(
            color: selected ? AppColors.black : AppColors.grey,
            borderRadius: BorderRadius.circular(16),
          ),
          child: Column(children: [
            Icon(icon, color: selected ? Colors.white : AppColors.black),
            const SizedBox(height: 4),
            Text(label, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: selected ? Colors.white : AppColors.black)),
          ]),
        ),
      );
}
