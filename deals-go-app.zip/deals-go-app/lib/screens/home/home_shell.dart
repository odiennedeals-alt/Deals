import 'dart:async';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../providers/driver_provider.dart';
import '../../providers/notifications_provider.dart';
import '../../providers/ride_provider.dart';
import '../../providers/content_provider.dart';
import '../../widgets/common.dart';
import '../assistant/assistant_screen.dart';
import '../driver/driver_dashboard.dart';
import '../driver/earnings_screen.dart';
import '../driver/vehicle_screen.dart';
import '../history/history_screen.dart';
import '../profile/profile_screen.dart';
import '../subscription/subscription_screen.dart';
import 'client_home.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});
  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> with WidgetsBindingObserver {
  int index = 0;
  String? lastMode;
  StreamSubscription<Map<String, dynamic>>? _notifSub;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      if (!mounted) return;
      final auth = context.read<AuthProvider>();
      final notifs = context.read<NotificationsProvider>();
      await notifs.start();
      _notifSub = notifs.incoming.listen((n) {
        if (!mounted) return;
        final title = (n['title'] ?? '').toString();
        final body = (n['body'] ?? '').toString();
        snack(context, body.isEmpty ? title : '$title : $body');
      });
      if (!mounted) return;
      await context.read<RideProvider>().start();
      if (!mounted) return;
      if (auth.isDriver) {
        await context.read<DriverProvider>().start(auth.driver?['is_online'] == true);
      }
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed && mounted) {
      // Resynchronisation automatique au retour dans l'application (après une coupure réseau, par exemple).
      context.read<AuthProvider>().refresh();
      context.read<RideProvider>().refresh();
      context.read<NotificationsProvider>().load();
      context.read<ContentProvider>().load();
      final auth = context.read<AuthProvider>();
      if (auth.isDriver) context.read<DriverProvider>().refresh();
    }
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    _notifSub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final driverMode = auth.mode == 'driver' && auth.isDriver;
    final mode = driverMode ? 'driver' : 'client';
    if (lastMode != mode) {
      lastMode = mode;
      index = 0;
    }

    final pages = driverMode
        ? const <Widget>[DriverDashboard(), EarningsScreen(), VehicleScreen(), SubscriptionScreen(), ProfileScreen()]
        : const <Widget>[ClientHome(), HistoryScreen(), AssistantScreen(), ProfileScreen()];

    final items = driverMode
        ? const [
            NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'Accueil'),
            NavigationDestination(icon: Icon(Icons.payments_outlined), selectedIcon: Icon(Icons.payments), label: 'Gains'),
            NavigationDestination(icon: Icon(Icons.directions_car_outlined), selectedIcon: Icon(Icons.directions_car), label: 'Véhicule'),
            NavigationDestination(icon: Icon(Icons.workspace_premium_outlined), selectedIcon: Icon(Icons.workspace_premium), label: 'Abonnement'),
            NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profil'),
          ]
        : const [
            NavigationDestination(icon: Icon(Icons.map_outlined), selectedIcon: Icon(Icons.map), label: 'Accueil'),
            NavigationDestination(icon: Icon(Icons.history), selectedIcon: Icon(Icons.history), label: 'Historique'),
            NavigationDestination(icon: Icon(Icons.support_agent_outlined), selectedIcon: Icon(Icons.support_agent), label: 'Aide'),
            NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Profil'),
          ];

    return Scaffold(
      body: IndexedStack(index: index, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: index,
        onDestinationSelected: (i) => setState(() => index = i),
        destinations: items,
      ),
    );
  }
}
