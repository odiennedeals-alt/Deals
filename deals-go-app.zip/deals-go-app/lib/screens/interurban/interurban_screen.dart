import 'package:flutter/material.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/errors.dart';
import '../../core/utils/format.dart';
import '../../core/utils/json.dart';
import '../../services/api.dart';
import '../../services/launcher.dart';
import '../../widgets/common.dart';
import '../../widgets/logo.dart';

const _bookingLabels = {'requested': 'En attente', 'accepted': 'Acceptée', 'declined': 'Refusée', 'cancelled': 'Annulée'};

/// Trajets entre villes proposés par de vrais conducteurs. Aucun trajet fictif n'est affiché.
class InterurbanScreen extends StatefulWidget {
  const InterurbanScreen({super.key});
  @override
  State<InterurbanScreen> createState() => _InterurbanScreenState();
}

class _InterurbanScreenState extends State<InterurbanScreen> {
  List<Map<String, dynamic>> cities = [];
  List<Map<String, dynamic>> bookings = [];
  List<Map<String, dynamic>>? trips;
  String? from;
  String? to;
  DateTime? date;
  int seats = 1;
  String? vehicleType;
  bool busy = false;
  String? error;

  @override
  void initState() {
    super.initState();
    _init();
  }

  Future<void> _init() async {
    try {
      final c = await Api.cities();
      final b = await Api.myBookings();
      if (mounted) setState(() { cities = c; bookings = b; if (c.isNotEmpty) from = toS(c.first['id']); });
    } catch (e) {
      if (mounted) setState(() => error = errorMessage(e));
    }
  }

  Future<void> _search() async {
    if (from == null || to == null || from == to) {
      snack(context, 'Choisissez deux villes différentes.');
      return;
    }
    setState(() { busy = true; error = null; });
    try {
      final l = await Api.interurbanTrips(fromCity: from!, toCity: to!, date: date, vehicleType: vehicleType, seats: seats);
      if (mounted) setState(() => trips = l);
    } catch (e) {
      if (mounted) setState(() => error = errorMessage(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> _book(Map<String, dynamic> t) async {
    try {
      await Api.bookTrip(toS(t['trip_id']), seats);
      if (!mounted) return;
      snack(context, 'Réservation envoyée au conducteur. Vous serez notifié de sa réponse.');
      final b = await Api.myBookings();
      if (mounted) setState(() => bookings = b);
      _search();
    } catch (e) {
      if (mounted) snack(context, errorMessage(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    final items = [for (final c in cities) DropdownMenuItem<String>(value: toS(c['id']), child: Text(toS(c['name'])))];
    return Scaffold(
      appBar: AppBar(title: const Text('Interurbain')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        if (cities.length < 2)
          const AppCard(child: Text("Les villes disponibles sont en cours de configuration par l'administration. Revenez bientôt.")),
        DropdownButtonFormField<String>(value: from, items: items, onChanged: (v) => setState(() => from = v), decoration: const InputDecoration(labelText: 'Ville de départ')),
        const SizedBox(height: 10),
        DropdownButtonFormField<String>(value: to, items: items, onChanged: (v) => setState(() => to = v), decoration: const InputDecoration(labelText: "Ville d'arrivée")),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(
            child: OutlinedButton(
              onPressed: () async {
                final d = await showDatePicker(context: context, initialDate: DateTime.now(), firstDate: DateTime.now(), lastDate: DateTime.now().add(const Duration(days: 180)));
                if (d != null) setState(() => date = d);
              },
              child: Text(date == null ? 'Toutes les dates' : dayText(date)),
            ),
          ),
          const SizedBox(width: 10),
          IconButton(onPressed: seats > 1 ? () => setState(() => seats--) : null, icon: const Icon(Icons.remove_circle_outline)),
          Text('$seats passager${seats > 1 ? 's' : ''}', style: const TextStyle(fontWeight: FontWeight.w700)),
          IconButton(onPressed: seats < 8 ? () => setState(() => seats++) : null, icon: const Icon(Icons.add_circle_outline)),
        ]),
        const SizedBox(height: 6),
        Wrap(spacing: 8, children: [
          ChoiceChip(label: const Text('Tous'), selected: vehicleType == null, onSelected: (_) => setState(() => vehicleType = null)),
          ChoiceChip(label: const Text('Voiture'), selected: vehicleType == 'car', onSelected: (_) => setState(() => vehicleType = 'car')),
          ChoiceChip(label: const Text('Moto'), selected: vehicleType == 'moto', onSelected: (_) => setState(() => vehicleType = 'moto')),
        ]),
        const SizedBox(height: 12),
        ElevatedButton(onPressed: busy ? null : _search, child: busy ? const SizedBox(height: 22, width: 22, child: CircularProgressIndicator(strokeWidth: 3, color: Colors.white)) : const Text('Rechercher des trajets')),
        if (error != null) Padding(padding: const EdgeInsets.only(top: 10), child: Text(error!, style: const TextStyle(color: Color(0xFFB91C1C)))),
        if (trips != null) ...[
          const SectionTitle('Trajets proposés'),
          if (trips!.isEmpty) const AppCard(child: Text("Aucun conducteur ne propose ce trajet pour le moment.")),
          for (final t in trips!)
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: AppCard(
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Row(children: [
                    UserAvatar(path: t['avatar_path'] as String?, label: toS(t['full_name']), radius: 24),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Row(children: [
                          Flexible(child: Text(toS(t['full_name'], 'Conducteur'), style: const TextStyle(fontWeight: FontWeight.w800), overflow: TextOverflow.ellipsis)),
                          if (t['is_certified'] == true) const Padding(padding: EdgeInsets.only(left: 6), child: Icon(Icons.verified_rounded, size: 18, color: Color(0xFF1D4ED8))),
                        ]),
                        Text('${toS(t['brand'])} ${toS(t['model'])} · ${toS(t['plate_number'])}', style: const TextStyle(fontSize: 12)),
                      ]),
                    ),
                    Text(money(toI(t['price_fcfa'])), style: const TextStyle(fontWeight: FontWeight.w900)),
                  ]),
                  const SizedBox(height: 8),
                  Text('${toS(t['from_city'])} → ${toS(t['to_city'])}', style: const TextStyle(fontWeight: FontWeight.w700)),
                  Text('Départ : ${dateTimeText(toDate(t['departure_at']))} · ${toI(t['seats_available'])} place(s)', style: const TextStyle(color: AppColors.greyText, fontSize: 13)),
                  if (toS(t['notes']).isNotEmpty) Text(toS(t['notes']), style: const TextStyle(fontSize: 13)),
                  const SizedBox(height: 8),
                  Row(children: [
                    Expanded(child: OutlinedButton.icon(onPressed: () => callPhone(toS(t['phone'])), icon: const Icon(Icons.call), label: const Text('Appeler'))),
                    const SizedBox(width: 8),
                    Expanded(child: ElevatedButton(onPressed: () => _book(t), style: ElevatedButton.styleFrom(minimumSize: const Size.fromHeight(48)), child: const Text('Réserver'))),
                  ]),
                ]),
              ),
            ),
        ],
        const SectionTitle('Mes réservations'),
        if (bookings.isEmpty) const AppCard(child: Text('Aucune réservation.')),
        for (final b in bookings)
          Builder(builder: (_) {
            final t = toMap(b['interurban_trips']) ?? {};
            final f = toMap(t['from']);
            final to2 = toMap(t['to']);
            final st = toS(b['status']);
            return Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: AppCard(
                child: Row(children: [
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text('${toS(f?['name'])} → ${toS(to2?['name'])}', style: const TextStyle(fontWeight: FontWeight.w800)),
                      Text('${dateTimeText(toDate(t['departure_at']))} · ${toI(b['seats'])} place(s)', style: const TextStyle(fontSize: 12)),
                    ]),
                  ),
                  st == 'accepted' ? Pill.ok(_bookingLabels[st]!) : (st == 'requested' ? Pill.warn(_bookingLabels[st]!) : Pill(_bookingLabels[st] ?? st)),
                  if (st == 'requested' || st == 'accepted')
                    IconButton(
                      onPressed: () async {
                        try {
                          await Api.cancelBooking(toS(b['id']));
                          final nb = await Api.myBookings();
                          if (mounted) setState(() => bookings = nb);
                        } catch (e) {
                          if (mounted) snack(context, errorMessage(e));
                        }
                      },
                      icon: const Icon(Icons.close),
                    ),
                ]),
              ),
            );
          }),
      ]),
    );
  }
}
