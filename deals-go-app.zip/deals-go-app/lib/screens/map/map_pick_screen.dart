import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';
import '../../models/place.dart';
import '../../services/geo_service.dart';
import '../../widgets/common.dart';
import '../../widgets/deals_map.dart';

/// Choisir un point en touchant la carte.
class MapPickScreen extends StatefulWidget {
  final LatLng center;
  final String title;
  const MapPickScreen({super.key, required this.center, this.title = 'Choisir sur la carte'});
  @override
  State<MapPickScreen> createState() => _MapPickScreenState();
}

class _MapPickScreenState extends State<MapPickScreen> {
  LatLng? picked;
  bool busy = false;

  Future<void> confirm() async {
    final p = picked;
    if (p == null) return;
    setState(() => busy = true);
    final label = await GeoService.reverse(p);
    if (!mounted) return;
    Navigator.of(context).pop(Place(label, p));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: Stack(children: [
        Positioned.fill(
          child: DealsMap(
            center: widget.center,
            zoom: 15,
            onTap: (p) => setState(() => picked = p),
            markers: [if (picked != null) pinMarker(picked!, Icons.location_on, AppColors.red, size: 46)],
          ),
        ),
        Positioned(
          left: 16,
          right: 16,
          bottom: 24,
          child: SafeArea(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              if (picked == null)
                const AppCard(child: Text('Touchez la carte pour placer le point.', textAlign: TextAlign.center)),
              const SizedBox(height: 10),
              ElevatedButton(
                onPressed: (picked == null || busy) ? null : confirm,
                child: busy ? const SizedBox(height: 22, width: 22, child: CircularProgressIndicator(strokeWidth: 3, color: Colors.white)) : const Text('Confirmer ce point'),
              ),
            ]),
          ),
        ),
      ]),
    );
  }
}

// Utilisé pour l'import AppConstants sans avertissement dans certains analyseurs.
const _unused = AppConstants.appName;
