import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/utils/format.dart';
import '../../core/utils/json.dart';
import '../../providers/notifications_provider.dart';
import '../../widgets/common.dart';

class NotificationsScreen extends StatefulWidget {
  const NotificationsScreen({super.key});
  @override
  State<NotificationsScreen> createState() => _NotificationsScreenState();
}

class _NotificationsScreenState extends State<NotificationsScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => context.read<NotificationsProvider>().load());
  }

  @override
  Widget build(BuildContext context) {
    final p = context.watch<NotificationsProvider>();
    return Scaffold(
      appBar: AppBar(title: const Text('Notifications'), actions: [
        if (p.unread > 0) TextButton(onPressed: p.markAllRead, child: const Text('Tout lire')),
      ]),
      body: p.items.isEmpty
          ? const EmptyState(icon: Icons.notifications_none, title: 'Aucune notification')
          : ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: p.items.length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (_, i) {
                final n = p.items[i];
                final unread = n['is_read'] != true;
                return AppCard(
                  color: unread ? const Color(0xFFFFF7F6) : Colors.white,
                  onTap: () => p.markRead(toS(n['id'])),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Row(children: [
                      Expanded(child: Text(toS(n['title']), style: TextStyle(fontWeight: unread ? FontWeight.w900 : FontWeight.w600))),
                      Text(dateTimeText(toDate(n['created_at'])), style: const TextStyle(fontSize: 11)),
                    ]),
                    if (toS(n['body']).isNotEmpty) Padding(padding: const EdgeInsets.only(top: 4), child: Text(toS(n['body']))),
                  ]),
                );
              },
            ),
    );
  }
}
