import 'package:flutter/material.dart';
import '../../core/theme/app_theme.dart';
import '../../widgets/logo.dart';
import '../authentication/auth_screen.dart';

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 24, 24, 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Center(child: DealsLogo(size: 54)),
              const Spacer(),
              const Text(
                'FIABLES ET\nABORDABLES',
                style: TextStyle(fontSize: 40, fontWeight: FontWeight.w900, height: 1.0, color: AppColors.black),
              ),
              const Text(
                'COURSES',
                style: TextStyle(fontSize: 40, fontWeight: FontWeight.w900, height: 1.1, color: AppColors.red),
              ),
              const SizedBox(height: 14),
              const Text(
                'Taxis auto et taxis moto à Odienné et dans le Denguélé.',
                style: TextStyle(fontSize: 16, color: AppColors.greyText),
              ),
              const Spacer(),
              ElevatedButton(
                onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const AuthScreen())),
                child: const Text('Se connecter avec un numéro de téléphone'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
