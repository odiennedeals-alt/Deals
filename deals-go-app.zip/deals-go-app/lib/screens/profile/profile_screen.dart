import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/errors.dart';
import '../../core/utils/format.dart';
import '../../core/utils/json.dart';
import '../../providers/auth_provider.dart';
import '../../providers/content_provider.dart';
import '../../providers/driver_provider.dart';
import '../../providers/notifications_provider.dart';
import '../../services/api.dart';
import '../../services/launcher.dart';
import '../../services/local_store.dart';
import '../../services/media.dart';
import '../../widgets/common.dart';
import '../../widgets/logo.dart';
import '../assistant/assistant_screen.dart';
import '../destination/destination_screen.dart';
import '../driver/become_driver_screen.dart';
import '../driver/certification_screen.dart';
import '../driver/driver_interurban_screen.dart';
import '../history/history_screen.dart';
import '../notifications/notifications_screen.dart';
import '../safety/emergency_contacts_screen.dart';
import '../settings/settings_screen.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  Future<void> _changePhoto(BuildContext context) async {
    final img = await pickImage();
    if (img == null || !context.mounted) return;
    try {
      final path = await Api.uploadImage('public-media', img.bytes, img.nameWith('avatar'), contentType: img.contentType);
      await Api.updateProfile({'avatar_path': path});
      if (context.mounted) await context.read<AuthProvider>().refresh();
    } catch (e) {
      if (context.mounted) snack(context, errorMessage(e));
    }
  }

  Future<void> _editName(BuildContext context) async {
    final auth = context.read<AuthProvider>();
    final ctrl = TextEditingController(text: auth.name);
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Mon nom'),
        content: TextField(controller: ctrl, textCapitalization: TextCapitalization.words, decoration: const InputDecoration(labelText: 'Nom et prénom')),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')), TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Enregistrer'))],
      ),
    );
    if (ok == true && ctrl.text.trim().length >= 2) {
      try {
        await Api.updateProfile({'full_name': ctrl.text.trim()});
        await auth.refresh();
      } catch (e) {
        if (context.mounted) snack(context, errorMessage(e));
      }
    }
  }

  Future<void> _promo(BuildContext context) async {
    final current = await LocalStore.promo();
    if (!context.mounted) return;
    final ctrl = TextEditingController(text: current ?? '');
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Réductions'),
        content: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text("Saisissez un code promotionnel. Il sera appliqué à votre prochaine course s'il est valide."),
          const SizedBox(height: 10),
          TextField(controller: ctrl, textCapitalization: TextCapitalization.characters, decoration: const InputDecoration(labelText: 'Code promotionnel')),
        ]),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')), TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Enregistrer'))],
      ),
    );
    if (ok == true) {
      await LocalStore.setPromo(ctrl.text.trim().toUpperCase());
      if (context.mounted) snack(context, ctrl.text.trim().isEmpty ? 'Code supprimé.' : 'Code enregistré pour votre prochaine course.');
    }
  }

  Future<void> _payment(BuildContext context) async {
    final auth = context.read<AuthProvider>();
    final current = toS(auth.profile?['preferred_payment'], 'cash');
    final v = await showModalBottomSheet<String>(
      context: context,
      builder: (ctx) => SafeArea(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Padding(padding: EdgeInsets.all(16), child: Text('Moyen de paiement préféré', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w900))),
          ListTile(leading: const Icon(Icons.payments_outlined), title: const Text('Espèces'), trailing: current == 'cash' ? const Icon(Icons.check) : null, onTap: () => Navigator.pop(ctx, 'cash')),
          ListTile(leading: const Icon(Icons.phone_android), title: const Text('Wave (envoyé au conducteur)'), trailing: current == 'wave' ? const Icon(Icons.check) : null, onTap: () => Navigator.pop(ctx, 'wave')),
          const Padding(padding: EdgeInsets.all(16), child: Text("Vous réglez toujours votre conducteur directement. DEALS GO ne prélève rien dans l'application.", style: TextStyle(fontSize: 12, color: AppColors.greyText))),
        ]),
      ),
    );
    if (v != null) {
      try {
        await Api.updateProfile({'preferred_payment': v});
        await auth.refresh();
      } catch (e) {
        if (context.mounted) snack(context, errorMessage(e));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final unread = context.watch<NotificationsProvider>().unread;
    Widget tile(IconData icon, String title, VoidCallback onTap, {String? subtitle, Widget? trailing}) => ListTile(
          leading: Icon(icon),
          title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
          subtitle: subtitle == null ? null : Text(subtitle),
          trailing: trailing ?? const Icon(Icons.chevron_right),
          onTap: onTap,
        );

    return Scaffold(
      appBar: AppBar(title: const Text('Profil')),
      body: ListView(children: [
        Padding(
          padding: const EdgeInsets.all(20),
          child: Column(children: [
            GestureDetector(onTap: () => _changePhoto(context), child: Stack(children: [
              UserAvatar(path: auth.avatarPath, label: auth.name.isEmpty ? auth.phone : auth.name, radius: 46),
              Positioned(right: 0, bottom: 0, child: CircleAvatar(radius: 14, backgroundColor: AppColors.red, child: const Icon(Icons.camera_alt, size: 15, color: Colors.white))),
            ])),
            const SizedBox(height: 10),
            Text(auth.name.isEmpty ? 'Ajouter votre nom' : auth.name, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
            Text(prettyPhone(auth.phone), style: const TextStyle(color: AppColors.greyText)),
            TextButton(onPressed: () => _editName(context), child: const Text('Modifier mon nom')),
          ]),
        ),
        const Divider(height: 1),
        tile(Icons.history, 'Historique', () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const HistoryScreen()))),
        tile(Icons.star_border_rounded, 'Adresses favorites', () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const FavoritesScreen()))),
        tile(Icons.card_giftcard_outlined, 'Réductions', () => _promo(context), subtitle: 'Saisir un code promotionnel'),
        tile(Icons.payments_outlined, 'Moyens de paiement', () => _payment(context), subtitle: toS(auth.profile?['preferred_payment'], 'cash') == 'wave' ? 'Wave' : 'Espèces'),
        tile(Icons.shield_outlined, 'Sécurité', () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const EmergencyContactsScreen())), subtitle: "Contacts d'urgence"),
        tile(Icons.notifications_none, 'Notifications', () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const NotificationsScreen())),
            trailing: unread > 0 ? CircleAvatar(radius: 11, backgroundColor: AppColors.red, child: Text('$unread', style: const TextStyle(color: Colors.white, fontSize: 11))) : const Icon(Icons.chevron_right)),
        tile(Icons.support_agent_outlined, 'Assistance', () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const AssistantScreen()))),
        const SectionTitle('  Conducteur'),
        if (auth.isDriver) ...[
          tile(Icons.swap_horiz_rounded, auth.mode == 'driver' ? 'Passer en mode client' : 'Passer en mode conducteur', () => auth.setMode(auth.mode == 'driver' ? 'client' : 'driver')),
          tile(Icons.verified_outlined, 'Certification', () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const CertificationScreen()))),
          tile(Icons.luggage_outlined, 'Trajets interurbains', () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const DriverInterurbanScreen()))),
        ] else
          tile(Icons.local_taxi_outlined, 'Travailler comme conducteur', () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const BecomeDriverScreen()))),
        const Divider(height: 24),
        tile(Icons.info_outline, 'Informations', () => showAboutDialog(
              context: context,
              applicationName: 'DEALS GO',
              applicationVersion: '1.0.0',
              children: const [Text('Taxis auto et taxis moto à Odienné et dans le Denguélé.')],
            )),
        tile(Icons.settings_outlined, 'Paramètres', () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SettingsScreen()))),
        const SizedBox(height: 20),
      ]),
    );
  }
}

class FavoritesScreen extends StatefulWidget {
  const FavoritesScreen({super.key});
  @override
  State<FavoritesScreen> createState() => _FavoritesScreenState();
}

class _FavoritesScreenState extends State<FavoritesScreen> {
  List<Map<String, dynamic>>? items;
  String? error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final l = await Api.favorites();
      if (mounted) setState(() { items = l; error = null; });
    } catch (e) {
      if (mounted) setState(() => error = errorMessage(e));
    }
  }

  Future<void> _add() async {
    final place = await Navigator.of(context).push<dynamic>(MaterialPageRoute(
      builder: (_) => const PlacePickerScreen(title: 'Nouvelle adresse favorite', showCurrent: true, center: AppConstants.odienneCenter),
    ));
    if (place == null || !mounted) return;
    final label = await promptDialog(context, 'Nom de cette adresse', hint: 'Maison, Travail...', required: true);
    if (label == null) return;
    try {
      await Api.addFavorite(label, place.label as String, place.point.latitude as double, place.point.longitude as double);
      _load();
    } catch (e) {
      if (mounted) snack(context, errorMessage(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Adresses favorites')),
      floatingActionButton: FloatingActionButton.extended(onPressed: _add, icon: const Icon(Icons.add), label: const Text('Ajouter')),
      body: error != null
          ? ErrorView(message: error!, onRetry: _load)
          : items == null
              ? const LoadingView()
              : items!.isEmpty
                  ? const EmptyState(icon: Icons.star_border_rounded, title: 'Aucune adresse favorite')
                  : ListView(padding: const EdgeInsets.all(16), children: [
                      for (final f in items!)
                        ListTile(
                          leading: const Icon(Icons.star_rounded),
                          title: Text(toS(f['label']), style: const TextStyle(fontWeight: FontWeight.w700)),
                          subtitle: Text(toS(f['address']), maxLines: 2, overflow: TextOverflow.ellipsis),
                          trailing: IconButton(onPressed: () async { await Api.deleteFavorite(toS(f['id'])); _load(); }, icon: const Icon(Icons.delete_outline)),
                        ),
                    ]),
    );
  }
}

