import 'package:flutter/material.dart';
import '../../core/utils/errors.dart';
import '../../core/utils/format.dart';
import '../../core/utils/json.dart';
import '../../services/api.dart';
import '../../widgets/common.dart';

class EmergencyContactsScreen extends StatefulWidget {
  const EmergencyContactsScreen({super.key});
  @override
  State<EmergencyContactsScreen> createState() => _EmergencyContactsScreenState();
}

class _EmergencyContactsScreenState extends State<EmergencyContactsScreen> {
  List<Map<String, dynamic>>? items;
  String? error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final l = await Api.emergencyContacts();
      if (mounted) setState(() { items = l; error = null; });
    } catch (e) {
      if (mounted) setState(() => error = errorMessage(e));
    }
  }

  Future<void> _edit([Map<String, dynamic>? c]) async {
    final name = TextEditingController(text: toS(c?['name']));
    final phone = TextEditingController(text: toS(c?['phone']));
    final relation = TextEditingController(text: toS(c?['relation']));
    bool primary = c?['is_primary'] == true || (items?.isEmpty ?? true);
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          title: Text(c == null ? "Nouveau contact d'urgence" : 'Modifier le contact'),
          content: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextField(controller: name, decoration: const InputDecoration(labelText: 'Nom')),
              const SizedBox(height: 8),
              TextField(controller: phone, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Téléphone')),
              const SizedBox(height: 8),
              TextField(controller: relation, decoration: const InputDecoration(labelText: 'Lien (parent, ami...)')),
              CheckboxListTile(value: primary, onChanged: (v) => setS(() => primary = v == true), title: const Text('Contact principal'), contentPadding: EdgeInsets.zero),
            ]),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Annuler')),
            TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Enregistrer')),
          ],
        ),
      ),
    );
    if (ok != true) return;
    final digits = phone.text.replaceAll(RegExp(r'[^0-9+]'), '');
    final normalized = normalizePhone(digits) ?? digits;
    if (name.text.trim().isEmpty || normalized.replaceAll('+', '').length < 8) {
      if (mounted) snack(context, 'Nom et numéro valides requis.');
      return;
    }
    try {
      await Api.saveEmergencyContact({
        'name': name.text.trim(),
        'phone': normalized,
        'relation': relation.text.trim().isEmpty ? null : relation.text.trim(),
        'is_primary': primary,
      }, id: c == null ? null : toS(c['id']));
      _load();
    } catch (e) {
      if (mounted) snack(context, errorMessage(e));
    }
  }

  Future<void> _delete(Map<String, dynamic> c) async {
    if (!await confirmDialog(context, 'Supprimer ce contact ?', toS(c['name']), danger: true, okLabel: 'Supprimer')) return;
    try {
      await Api.deleteEmergencyContact(toS(c['id']));
      _load();
    } catch (e) {
      if (mounted) snack(context, errorMessage(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Contacts d'urgence")),
      floatingActionButton: FloatingActionButton.extended(onPressed: () => _edit(), icon: const Icon(Icons.add), label: const Text('Ajouter')),
      body: error != null
          ? ErrorView(message: error!, onRetry: _load)
          : items == null
              ? const LoadingView()
              : items!.isEmpty
                  ? const EmptyState(icon: Icons.contact_phone_outlined, title: "Aucun contact d'urgence", subtitle: "Cette personne sera prévenue si vous appuyez sur « Je ne me sens pas en sécurité ».")
                  : ListView(padding: const EdgeInsets.all(16), children: [
                      for (final c in items!)
                        Padding(
                          padding: const EdgeInsets.only(bottom: 10),
                          child: AppCard(
                            onTap: () => _edit(c),
                            child: Row(children: [
                              const Icon(Icons.person_outline),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                  Text(toS(c['name']), style: const TextStyle(fontWeight: FontWeight.w800)),
                                  Text('${prettyPhone(toS(c['phone']))}${toS(c['relation']).isEmpty ? '' : ' · ${toS(c['relation'])}'}'),
                                  if (c['is_primary'] == true) Pill.ok('Principal'),
                                ]),
                              ),
                              IconButton(onPressed: () => _delete(c), icon: const Icon(Icons.delete_outline)),
                            ]),
                          ),
                        ),
                    ]),
    );
  }
}
