import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/errors.dart';
import '../../core/utils/format.dart';
import '../../core/utils/json.dart';
import '../../providers/content_provider.dart';
import '../../services/api.dart';
import '../../services/launcher.dart';
import '../../services/location_service.dart';
import '../../widgets/common.dart';
import 'emergency_contacts_screen.dart';

Future<void> showSosSheet(BuildContext context, {String? rideId}) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
    builder: (_) => _SosSheet(rideId: rideId),
  );
}

class _SosSheet extends StatefulWidget {
  final String? rideId;
  const _SosSheet({this.rideId});
  @override
  State<_SosSheet> createState() => _SosSheetState();
}

class _SosSheetState extends State<_SosSheet> {
  bool sent = false;
  bool busy = false;
  double? lat;
  double? lng;
  Map<String, dynamic>? contact;

  @override
  void initState() {
    super.initState();
    Api.emergencyContacts().then((l) {
      if (mounted && l.isNotEmpty) {
        final primary = l.firstWhere((c) => c['is_primary'] == true, orElse: () => l.first);
        setState(() => contact = primary);
      }
    }).catchError((_) {});
  }

  Future<void> _alert() async {
    setState(() => busy = true);
    try {
      final pos = await LocationService.current();
      lat = pos?.latitude;
      lng = pos?.longitude;
      final res = await Api.safetyAlert(rideId: widget.rideId, lat: lat, lng: lng);
      final c = toMap(res['emergency_contact']);
      if (c != null && mounted) contact = c;
      if (mounted) setState(() => sent = true);
    } catch (e) {
      if (mounted) snack(context, errorMessage(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  void _warnContact() {
    final c = contact;
    if (c == null) return;
    final pos = lat == null ? '' : ' Ma position : https://www.openstreetmap.org/?mlat=$lat&mlon=$lng#map=17/$lat/$lng';
    sendSms(toS(c['phone']), "Je ne me sens pas en sécurité pendant une course DEALS GO.$pos");
  }

  @override
  Widget build(BuildContext context) {
    final content = context.watch<ContentProvider>();
    final numbers = content.sos.where((n) => n['is_published'] == true && toS(n['phone']).isNotEmpty).toList();
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          const Text('Besoin d\'aide ?', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
          const SizedBox(height: 12),
          if (!sent)
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFFDC2626), minimumSize: const Size.fromHeight(58)),
              onPressed: busy ? null : _alert,
              icon: busy ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 3, color: Colors.white)) : const Icon(Icons.warning_amber_rounded),
              label: const Text('Je ne me sens pas en sécurité'),
            )
          else
            AppCard(
              color: const Color(0xFFDCFCE7),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                const Text('Alerte envoyée au support DEALS GO', style: TextStyle(fontWeight: FontWeight.w800, color: AppColors.green)),
                const SizedBox(height: 4),
                Text(lat == null ? 'Votre course a été enregistrée (position indisponible).' : 'Votre position et votre course ont été enregistrées.'),
                const SizedBox(height: 8),
                if (contact != null)
                  OutlinedButton(onPressed: _warnContact, child: Text('Prévenir ${toS(contact!['name'], 'mon contact')} par SMS'))
                else
                  OutlinedButton(
                    onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const EmergencyContactsScreen())),
                    child: const Text("Ajouter un contact d'urgence"),
                  ),
              ]),
            ),
          const SectionTitle("Numéros d'urgence"),
          if (numbers.isEmpty)
            const AppCard(child: Text("Les numéros d'urgence locaux sont en cours de vérification par l'administration. En cas de danger immédiat, appelez les secours que vous connaissez.")),
          for (final n in numbers)
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const CircleAvatar(backgroundColor: Color(0xFFFEE2E2), child: Icon(Icons.call, color: Color(0xFFB91C1C))),
              title: Text(toS(n['label']), style: const TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text(toS(n['phone'])),
              onTap: () => callPhone(toS(n['phone'])),
            ),
          if (contact != null)
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const CircleAvatar(backgroundColor: Color(0xFFFEE2E2), child: Icon(Icons.person, color: Color(0xFFB91C1C))),
              title: Text("Mon contact d'urgence : ${toS(contact!['name'])}", style: const TextStyle(fontWeight: FontWeight.w700)),
              subtitle: Text(prettyPhone(toS(contact!['phone']))),
              onTap: () => callPhone(toS(contact!['phone'])),
            ),
          ListTile(
            contentPadding: EdgeInsets.zero,
            leading: const CircleAvatar(backgroundColor: Color(0xFFDBEAFE), child: Icon(Icons.support_agent, color: Color(0xFF1D4ED8))),
            title: const Text('Support DEALS GO (WhatsApp)', style: TextStyle(fontWeight: FontWeight.w700)),
            onTap: () => openWhatsApp(content.whatsapp, "URGENT - J'ai besoin d'aide pendant une course DEALS GO."),
          ),
        ]),
      ),
    );
  }
}
