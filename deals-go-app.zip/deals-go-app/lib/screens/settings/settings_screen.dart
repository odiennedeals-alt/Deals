import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../providers/auth_provider.dart';
import '../../providers/content_provider.dart';
import '../../providers/driver_provider.dart';
import '../../providers/notifications_provider.dart';
import '../../providers/ride_provider.dart';
import '../../services/launcher.dart';
import '../../widgets/common.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  Future<void> _logout(BuildContext context) async {
    if (!await confirmDialog(context, 'Se déconnecter ?', 'Vous devrez saisir à nouveau votre numéro et votre mot de passe.', okLabel: 'Se déconnecter')) return;
    if (!context.mounted) return;
    final auth = context.read<AuthProvider>();
    final driver = context.read<DriverProvider>();
    final notifs = context.read<NotificationsProvider>();
    final rides = context.read<RideProvider>();
    Navigator.of(context).popUntil((r) => r.isFirst);
    await driver.stop();
    await notifs.stop();
    await rides.stop();
    await auth.signOut();
  }

  @override
  Widget build(BuildContext context) {
    final content = context.watch<ContentProvider>();
    return Scaffold(
      appBar: AppBar(title: const Text('Paramètres')),
      body: ListView(children: [
        const ListTile(leading: Icon(Icons.language), title: Text('Langue'), subtitle: Text('Français')),
        ListTile(
          leading: const Icon(Icons.support_agent),
          title: const Text("Contacter l'assistance"),
          subtitle: Text(content.whatsapp),
          onTap: () => openWhatsApp(content.whatsapp, "Bonjour DEALS GO, j'ai besoin d'aide."),
        ),
        ListTile(
          leading: const Icon(Icons.phonelink_erase_outlined),
          title: const Text('Modifier mon numéro ou supprimer mon compte'),
          subtitle: const Text("Pour votre sécurité, ces demandes passent par l'assistance."),
          onTap: () => openWhatsApp(content.whatsapp, "Bonjour DEALS GO, je souhaite modifier mon numéro ou supprimer mon compte."),
        ),
        const Divider(),
        ListTile(
          leading: const Icon(Icons.logout, color: Color(0xFFB91C1C)),
          title: const Text('Se déconnecter', style: TextStyle(color: Color(0xFFB91C1C), fontWeight: FontWeight.w700)),
          onTap: () => _logout(context),
        ),
        const Padding(padding: EdgeInsets.all(16), child: Text('DEALS GO 1.0.0', textAlign: TextAlign.center, style: TextStyle(color: Colors.grey))),
      ]),
    );
  }
}
