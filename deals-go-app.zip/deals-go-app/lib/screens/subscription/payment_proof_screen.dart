import 'package:flutter/material.dart';
import '../../core/utils/errors.dart';
import '../../core/utils/format.dart';
import '../../core/utils/json.dart';
import '../../services/api.dart';
import '../../services/media.dart';
import '../../widgets/common.dart';

class PaymentProofScreen extends StatefulWidget {
  final Map<String, dynamic> payment;
  const PaymentProofScreen({super.key, required this.payment});
  @override
  State<PaymentProofScreen> createState() => _PaymentProofScreenState();
}

class _PaymentProofScreenState extends State<PaymentProofScreen> {
  PickedImage? image;
  final ref = TextEditingController();
  bool busy = false;

  @override
  void dispose() {
    ref.dispose();
    super.dispose();
  }

  Future<void> _pick(bool camera) async {
    final i = await pickImage(camera: camera);
    if (i != null && mounted) setState(() => image = i);
  }

  Future<void> _submit() async {
    final img = image;
    if (img == null) return;
    setState(() => busy = true);
    try {
      final path = await Api.uploadImage('payment-proofs', img.bytes, img.nameWith('proof'), contentType: img.contentType);
      await Api.submitPaymentProof(toS(widget.payment['id']), path, ref.text.trim().isEmpty ? null : ref.text.trim());
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Preuve envoyée'),
          content: const Text("L'administration va vérifier votre paiement manuellement. Votre abonnement sera activé après validation et vous recevrez une notification."),
          actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('OK'))],
        ),
      );
      if (mounted) Navigator.of(context).pop();
    } catch (e) {
      if (mounted) snack(context, errorMessage(e));
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final p = widget.payment;
    return Scaffold(
      appBar: AppBar(title: const Text('Preuve de paiement')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        AppCard(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(toS(p['plan_name']), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
            Text('Montant attendu : ${money(toI(p['amount_fcfa']))}'),
            Text('Numéro Wave : ${toS(p['wave_number'])}'),
            if (toS(p['reject_reason']).isNotEmpty) Padding(padding: const EdgeInsets.only(top: 6), child: Text('Motif précédent : ${toS(p['reject_reason'])}', style: const TextStyle(color: Color(0xFFB91C1C)))),
          ]),
        ),
        const SizedBox(height: 14),
        const Text("Ajoutez la capture d'écran de votre transaction Wave (montant, numéro et référence bien lisibles).", style: TextStyle(height: 1.4)),
        const SizedBox(height: 10),
        if (image != null) ClipRRect(borderRadius: BorderRadius.circular(14), child: Image.memory(image!.bytes, height: 280, fit: BoxFit.contain)),
        const SizedBox(height: 10),
        Row(children: [
          Expanded(child: OutlinedButton.icon(onPressed: () => _pick(false), icon: const Icon(Icons.photo_library_outlined), label: const Text('Galerie'))),
          const SizedBox(width: 8),
          Expanded(child: OutlinedButton.icon(onPressed: () => _pick(true), icon: const Icon(Icons.photo_camera_outlined), label: const Text('Photo'))),
        ]),
        const SizedBox(height: 12),
        TextField(controller: ref, decoration: const InputDecoration(labelText: 'Référence de la transaction (optionnel)')),
        const SizedBox(height: 18),
        ElevatedButton(
          onPressed: (image == null || busy) ? null : _submit,
          child: busy ? const SizedBox(height: 22, width: 22, child: CircularProgressIndicator(strokeWidth: 3, color: Colors.white)) : const Text('Envoyer ma preuve'),
        ),
      ]),
    );
  }
}
