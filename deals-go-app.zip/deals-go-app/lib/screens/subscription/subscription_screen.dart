import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/errors.dart';
import '../../core/utils/format.dart';
import '../../core/utils/json.dart';
import '../../providers/auth_provider.dart';
import '../../providers/content_provider.dart';
import '../../services/api.dart';
import '../../services/launcher.dart';
import '../../widgets/common.dart';
import 'payment_proof_screen.dart';

/// Abonnement conducteur. Le paiement Wave est MANUEL : le conducteur envoie une preuve,
/// l'administration la vérifie et active l'abonnement. Rien n'est jamais validé automatiquement.
class SubscriptionScreen extends StatefulWidget {
  final bool standalone;
  const SubscriptionScreen({super.key, this.standalone = false});
  @override
  State<SubscriptionScreen> createState() => _SubscriptionScreenState();
}

class _SubscriptionScreenState extends State<SubscriptionScreen> {
  List<Map<String, dynamic>> plans = [];
  List<Map<String, dynamic>> payments = [];
  List<Map<String, dynamic>> subs = [];
  bool loading = true;
  String? error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final p = await Api.plans();
      final pay = await Api.myPayments();
      final s = await Api.mySubscriptions();
      if (mounted) setState(() { plans = p; payments = pay; subs = s; loading = false; error = null; });
      if (mounted) context.read<AuthProvider>().refresh();
    } catch (e) {
      if (mounted) setState(() { loading = false; error = errorMessage(e); });
    }
  }

  Future<void> _openProof(Map<String, dynamic> payment) async {
    await Navigator.of(context).push(MaterialPageRoute(builder: (_) => PaymentProofScreen(payment: payment)));
    _load();
  }

  void _showPlan(Map<String, dynamic> plan) {
    showModalBottomSheet<void>(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(24))),
      builder: (ctx) => _PlanSheet(
        plan: plan,
        onPaid: () async {
          Navigator.of(ctx).pop();
          try {
            final pay = await Api.createPaymentRequest(toS(plan['id']));
            if (mounted) await _openProof(pay);
          } catch (e) {
            if (mounted) snack(context, errorMessage(e));
          }
        },
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final d = auth.driver ?? {};
    final expires = toDate(d['subscription_expires_at']);
    final active = expires != null && expires.isAfter(DateTime.now());
    final latest = payments.isNotEmpty ? payments.first : null;
    final latestStatus = toS(latest?['status']);
    final needsAction = ['awaiting_proof', 'proof_requested', 'rejected'].contains(latestStatus);

    return Scaffold(
      appBar: AppBar(title: const Text('Abonnement conducteur')),
      body: !auth.isDriver
          ? const EmptyState(icon: Icons.workspace_premium_outlined, title: "Réservé aux conducteurs", subtitle: "Créez votre espace conducteur depuis l'onglet Profil.")
          : loading
              ? const LoadingView()
              : error != null
                  ? ErrorView(message: error!, onRetry: _load)
                  : RefreshIndicator(
                      onRefresh: _load,
                      child: ListView(padding: const EdgeInsets.all(16), children: [
                        AppCard(
                          color: active ? const Color(0xFFF0FDF4) : const Color(0xFFFFF7ED),
                          child: Row(children: [
                            Icon(active ? Icons.verified_outlined : Icons.warning_amber_rounded, color: active ? AppColors.green : AppColors.amber, size: 30),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Text(active ? 'Abonnement actif' : (expires == null ? 'Aucun abonnement' : 'Abonnement expiré'), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17)),
                                Text(active ? "Valable jusqu'au ${dateTimeText(expires)}" : 'Souscrivez à une offre pour recevoir des courses.', style: const TextStyle(fontSize: 13)),
                              ]),
                            ),
                          ]),
                        ),
                        if (latest != null && (needsAction || latestStatus == 'pending_review')) ...[
                          const SizedBox(height: 12),
                          AppCard(
                            color: latestStatus == 'pending_review' ? const Color(0xFFEFF6FF) : const Color(0xFFFFF1F0),
                            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                              Text(
                                latestStatus == 'pending_review' ? 'Paiement en cours de vérification'
                                    : latestStatus == 'rejected' ? 'Paiement refusé'
                                    : latestStatus == 'proof_requested' ? 'Nouvelle preuve demandée'
                                    : 'Preuve de paiement attendue',
                                style: const TextStyle(fontWeight: FontWeight.w900),
                              ),
                              const SizedBox(height: 4),
                              Text('${toS(latest['plan_name'])} · ${money(toI(latest['amount_fcfa']))}'),
                              if (latestStatus == 'pending_review')
                                const Text("L'administration vérifie manuellement votre capture Wave. Votre abonnement sera activé après validation.", style: TextStyle(fontSize: 13)),
                              if (toS(latest['reject_reason']).isNotEmpty && (latestStatus == 'rejected' || latestStatus == 'proof_requested'))
                                Text('Motif : ${toS(latest['reject_reason'])}', style: const TextStyle(color: Color(0xFFB91C1C))),
                              if (needsAction) ...[
                                const SizedBox(height: 8),
                                ElevatedButton(onPressed: () => _openProof(latest), child: Text(latestStatus == 'awaiting_proof' ? 'Envoyer ma preuve' : 'Envoyer une nouvelle preuve')),
                              ],
                            ]),
                          ),
                        ],
                        const SectionTitle('Choisissez une offre'),
                        for (final p in plans)
                          Padding(
                            padding: const EdgeInsets.only(bottom: 10),
                            child: AppCard(
                              onTap: () => _showPlan(p),
                              color: p['is_recommended'] == true ? const Color(0xFFFFF7F6) : Colors.white,
                              child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                                Row(children: [
                                  Expanded(child: Text(toS(p['name']), style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w900))),
                                  if (p['is_recommended'] == true) Pill.warn('Recommandée'),
                                ]),
                                const SizedBox(height: 4),
                                Text('${money(toI(p['price_fcfa']))} · ${toI(p['duration_days'])} jours', style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.red)),
                                for (final b in (p['benefits'] is List ? p['benefits'] as List : const []))
                                  Padding(padding: const EdgeInsets.only(top: 3), child: Row(children: [const Icon(Icons.check, size: 16, color: AppColors.green), const SizedBox(width: 6), Expanded(child: Text('$b', style: const TextStyle(fontSize: 13)))])),
                              ]),
                            ),
                          ),
                        if (plans.isEmpty) const AppCard(child: Text('Aucune offre disponible pour le moment.')),
                        if (subs.isNotEmpty) ...[
                          const SectionTitle('Historique des abonnements'),
                          for (final s in subs)
                            ListTile(
                              contentPadding: EdgeInsets.zero,
                              title: Text(toS(s['plan_name']), style: const TextStyle(fontWeight: FontWeight.w700)),
                              subtitle: Text('${dayText(toDate(s['starts_at']))} → ${dayText(toDate(s['expires_at']))}'),
                              trailing: toS(s['status']) == 'active' ? Pill.ok('Actif') : Pill('Expiré'),
                            ),
                        ],
                      ]),
                    ),
    );
  }
}

class _PlanSheet extends StatelessWidget {
  final Map<String, dynamic> plan;
  final Future<void> Function() onPaid;
  const _PlanSheet({required this.plan, required this.onPaid});

  @override
  Widget build(BuildContext context) {
    final content = context.watch<ContentProvider>();
    final price = money(toI(plan['price_fcfa']));
    return SafeArea(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Text(toS(plan['name']), style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900)),
          const SizedBox(height: 4),
          Text('$price · ${toI(plan['duration_days'])} jours', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: AppColors.red)),
          const SizedBox(height: 10),
          for (final b in (plan['benefits'] is List ? plan['benefits'] as List : const []))
            Padding(padding: const EdgeInsets.only(bottom: 4), child: Row(children: [const Icon(Icons.check, size: 18, color: AppColors.green), const SizedBox(width: 8), Expanded(child: Text('$b'))])),
          const Divider(height: 28),
          const Text('Paiement par Wave', style: TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 6),
          Row(children: [
            Expanded(child: Text(content.waveNumber, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, letterSpacing: 1))),
            IconButton(
              onPressed: () {
                Clipboard.setData(ClipboardData(text: content.waveNumber.replaceAll(' ', '')));
                snack(context, 'Numéro copié');
              },
              icon: const Icon(Icons.copy),
            ),
          ]),
          const SizedBox(height: 8),
          OutlinedButton(
            onPressed: () {
              final link = content.waveLink;
              if (link != null) {
                openUrl(link);
              } else {
                showDialog<void>(
                  context: context,
                  builder: (ctx) => AlertDialog(
                    title: const Text('Payer avec Wave'),
                    content: Text("1. Ouvrez l'application Wave.\n2. Envoyez $price au ${content.waveNumber}.\n3. Revenez ici et appuyez sur « J'ai effectué le paiement » pour envoyer la capture d'écran de la transaction."),
                    actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Compris'))],
                  ),
                );
              }
            },
            child: const Text('Payer avec Wave'),
          ),
          const SizedBox(height: 10),
          ElevatedButton(onPressed: onPaid, child: const Text("J'ai effectué le paiement")),
          const SizedBox(height: 8),
          const Text("Après le paiement, vous enverrez la capture de la transaction. L'administration la vérifie manuellement avant d'activer votre abonnement.", textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: AppColors.greyText)),
        ]),
      ),
    );
  }
}
