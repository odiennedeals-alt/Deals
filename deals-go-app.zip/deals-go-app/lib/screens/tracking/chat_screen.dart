import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/errors.dart';
import '../../core/utils/format.dart';
import '../../core/utils/json.dart';
import '../../services/api.dart';
import '../../services/supa.dart';
import '../../widgets/common.dart';

class ChatScreen extends StatefulWidget {
  final String rideId;
  final String title;
  const ChatScreen({super.key, required this.rideId, required this.title});
  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  List<Map<String, dynamic>> messages = [];
  final input = TextEditingController();
  final scroll = ScrollController();
  RealtimeChannel? ch;
  String? error;

  @override
  void initState() {
    super.initState();
    _load();
    ch = Api.watch('messages', _load, column: 'ride_id', value: widget.rideId);
  }

  @override
  void dispose() {
    Api.unwatch(ch);
    input.dispose();
    scroll.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final l = await Api.messages(widget.rideId);
      if (!mounted) return;
      setState(() { messages = l; error = null; });
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (scroll.hasClients) scroll.jumpTo(scroll.position.maxScrollExtent);
      });
    } catch (e) {
      if (mounted) setState(() => error = errorMessage(e));
    }
  }

  Future<void> _send() async {
    final t = input.text.trim();
    if (t.isEmpty) return;
    input.clear();
    try {
      await Api.sendMessage(widget.rideId, t);
      _load();
    } catch (e) {
      if (mounted) snack(context, errorMessage(e));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: Column(children: [
        if (error != null) Padding(padding: const EdgeInsets.all(8), child: Text(error!, style: const TextStyle(color: Color(0xFFB91C1C)))),
        Expanded(
          child: messages.isEmpty
              ? const EmptyState(icon: Icons.chat_bubble_outline, title: 'Aucun message', subtitle: 'Écrivez au conducteur ou au client de cette course.')
              : ListView.builder(
                  controller: scroll,
                  padding: const EdgeInsets.all(12),
                  itemCount: messages.length,
                  itemBuilder: (_, i) {
                    final m = messages[i];
                    final mine = m['sender_id'] == myId;
                    return Align(
                      alignment: mine ? Alignment.centerRight : Alignment.centerLeft,
                      child: Container(
                        margin: const EdgeInsets.symmetric(vertical: 3),
                        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
                        constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * 0.75),
                        decoration: BoxDecoration(color: mine ? AppColors.red : AppColors.grey, borderRadius: BorderRadius.circular(16)),
                        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                          Text(toS(m['body']), style: TextStyle(color: mine ? Colors.white : AppColors.black)),
                          Text(timeText(toDate(m['created_at'])), style: TextStyle(fontSize: 10, color: mine ? Colors.white70 : AppColors.greyText)),
                        ]),
                      ),
                    );
                  },
                ),
        ),
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.fromLTRB(12, 6, 12, 10),
            child: Row(children: [
              Expanded(child: TextField(controller: input, minLines: 1, maxLines: 3, maxLength: 1000, decoration: const InputDecoration(hintText: 'Votre message', counterText: ''))),
              const SizedBox(width: 8),
              IconButton.filled(onPressed: _send, icon: const Icon(Icons.send_rounded)),
            ]),
          ),
        ),
      ]),
    );
  }
}
