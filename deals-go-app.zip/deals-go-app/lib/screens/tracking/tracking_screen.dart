import 'dart:async';
import 'package:flutter/material.dart';
import 'package:latlong2/latlong.dart';
import 'package:provider/provider.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../../core/config/env.dart';
import '../../core/constants/app_constants.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/errors.dart';
import '../../core/utils/format.dart';
import '../../core/utils/json.dart';
import '../../models/place.dart';
import '../../models/ride.dart';
import '../../providers/ride_provider.dart';
import '../../services/api.dart';
import '../../services/geo_service.dart';
import '../../services/launcher.dart';
import '../../services/local_store.dart';
import '../../widgets/common.dart';
import '../../widgets/deals_map.dart';
import '../../widgets/logo.dart';
import '../history/receipt_screen.dart';
import '../safety/sos_sheet.dart';
import 'chat_screen.dart';

/// Suivi de course en direct (client). Synchronisation temps réel + relève automatique toutes les 8 s.
class TrackingScreen extends StatefulWidget {
  final String rideId;
  const TrackingScreen({super.key, required this.rideId});
  @override
  State<TrackingScreen> createState() => _TrackingScreenState();
}

class _TrackingScreenState extends State<TrackingScreen> {
  Ride? ride;
  LatLng? driverPos;
  RouteInfo? route;
  String? error;
  bool offline = false;
  Map<String, dynamic>? stored;
  RealtimeChannel? chRide;
  RealtimeChannel? chLoc;
  Timer? timer;
  Timer? tick;
  bool ratingShown = false;
  bool routeLoading = false;

  @override
  void initState() {
    super.initState();
    LocalStore.rideContact().then((c) {
      if (mounted) setState(() => stored = c);
    });
    _load();
    chRide = Api.watch('rides', _load, column: 'id', value: widget.rideId);
    chLoc = Api.watch('ride_locations', _loadPos, column: 'ride_id', value: widget.rideId);
    timer = Timer.periodic(const Duration(seconds: 8), (_) => _load());
    tick = Timer.periodic(const Duration(seconds: 1), (_) {
      if (mounted && ride?.status == 'requested') setState(() {});
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    tick?.cancel();
    Api.unwatch(chRide);
    Api.unwatch(chLoc);
    super.dispose();
  }

  Future<void> _load() async {
    try {
      final r = await Api.rideById(widget.rideId);
      if (!mounted || r == null) return;
      final changed = ride?.status != r.status;
      setState(() { ride = r; error = null; offline = false; });
      if (r.status == 'accepted' || r.status == 'arrived' || r.status == 'in_progress') {
        final contact = {'name': r.driverName ?? 'Conducteur', 'phone': r.driverPhone ?? '', 'ride_id': r.id, 'vehicle': r.vehicleText};
        LocalStore.saveRideContact(contact);
        if (mounted) setState(() => stored = contact);
        await _loadPos();
      }
      if (route == null && !routeLoading) _loadRoute(r);
      if (changed) context.read<RideProvider>().refresh();
      if (r.status == 'completed') {
        LocalStore.clearRideContact();
        if (!ratingShown) {
          ratingShown = true;
          _askRating(r);
        }
      }
      if (r.isFinished && r.status != 'completed') LocalStore.clearRideContact();
    } catch (e) {
      if (mounted) setState(() { offline = true; error = errorMessage(e); });
    }
  }

  Future<void> _loadRoute(Ride r) async {
    routeLoading = true;
    final info = await GeoService.route(LatLng(r.pickupLat, r.pickupLng), LatLng(r.destLat, r.destLng));
    routeLoading = false;
    if (mounted) setState(() => route = info);
  }

  Future<void> _loadPos() async {
    try {
      final p = await Api.lastDriverPosition(widget.rideId);
      if (p != null && mounted) setState(() => driverPos = LatLng(toD(p['lat']), toD(p['lng'])));
    } catch (_) {}
  }

  int? get etaMin {
    final r = ride;
    final p = driverPos;
    if (r == null || p == null) return null;
    final target = r.status == 'in_progress' ? LatLng(r.destLat, r.destLng) : LatLng(r.pickupLat, r.pickupLng);
    final mins = (GeoService.km(p, target) * 1.3 / 25 * 60).ceil();
    return mins < 1 ? 1 : mins;
  }

  Future<void> _cancel() async {
    final r = ride;
    if (r == null) return;
    if (!await confirmDialog(context, 'Annuler la course ?', 'Le conducteur sera prévenu.', okLabel: "Oui, annuler", danger: true)) return;
    try {
      await Api.cancelRide(r.id, 'Annulée par le client');
      await LocalStore.clearRideContact();
      if (!mounted) return;
      context.read<RideProvider>().setActive(null);
      Navigator.of(context).popUntil((x) => x.isFirst);
    } catch (e) {
      if (mounted) snack(context, errorMessage(e));
    }
  }

  Future<void> _share() async {
    final r = ride;
    if (r == null) return;
    if (!await confirmDialog(context, 'Partager mon trajet', "Un lien sécurisé permettra à la personne de votre choix de voir votre course en direct, le conducteur et la plaque du véhicule. Il expire dans 4 heures et s'arrête à la fin de la course. Vous restez libre de l'arrêter à tout moment.", okLabel: 'Créer le lien')) return;
    try {
      final res = await Api.startShare(r.id);
      final link = '${Env.shareBaseUrl}${toS(res['token'])}';
      final msg = "Je suis en course DEALS GO avec ${r.driverName ?? 'un conducteur'} (${r.vehicleText}). Suivez mon trajet en direct : $link";
      if (!mounted) return;
      await showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('Lien de partage créé'),
          content: SelectableText(link),
          actions: [
            TextButton(onPressed: () async { await Api.stopShare(r.id); if (ctx.mounted) Navigator.pop(ctx); }, child: const Text('Arrêter le partage')),
            TextButton(onPressed: () { openUrl('https://wa.me/?text=${Uri.encodeComponent(msg)}'); }, child: const Text('Envoyer par WhatsApp')),
            TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Fermer')),
          ],
        ),
      );
    } catch (e) {
      if (mounted) snack(context, errorMessage(e));
    }
  }

  Future<void> _askRating(Ride r) async {
    int stars = 5;
    final comment = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setS) => AlertDialog(
          title: const Text('Course terminée'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            Text('Prix : ${money(r.total)}', style: const TextStyle(fontWeight: FontWeight.w800)),
            const SizedBox(height: 8),
            const Text('Notez votre conducteur'),
            Row(mainAxisAlignment: MainAxisAlignment.center, children: [
              for (var i = 1; i <= 5; i++)
                IconButton(onPressed: () => setS(() => stars = i), icon: Icon(i <= stars ? Icons.star_rounded : Icons.star_border_rounded, color: AppColors.red, size: 34)),
            ]),
            TextField(controller: comment, maxLines: 2, decoration: const InputDecoration(hintText: 'Commentaire (optionnel)')),
          ]),
          actions: [
            TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Plus tard')),
            TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Envoyer')),
          ],
        ),
      ),
    );
    if (ok == true) {
      try {
        await Api.rateRide(r.id, stars, comment.text.trim().isEmpty ? null : comment.text.trim());
        if (mounted) snack(context, 'Merci pour votre avis !');
      } catch (e) {
        if (mounted) snack(context, errorMessage(e));
      }
    }
    if (mounted) {
      context.read<RideProvider>().refresh();
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => ReceiptScreen(ride: r)));
    }
  }

  @override
  Widget build(BuildContext context) {
    final r = ride;
    if (r == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Ma course')),
        body: error != null
            ? Column(children: [
                Expanded(child: ErrorView(message: error!, onRetry: _load)),
                if (stored != null) _StoredContact(stored!),
              ])
            : const LoadingView(),
      );
    }

    final pickup = LatLng(r.pickupLat, r.pickupLng);
    final dest = LatLng(r.destLat, r.destLng);
    final markers = <Marker>[
      dotMarker(pickup, const Color(0xFF2563EB)),
      pinMarker(dest, Icons.flag_rounded, AppColors.red, size: 34),
      if (driverPos != null) pinMarker(driverPos!, r.vehicleType == 'moto' ? Icons.two_wheeler : Icons.local_taxi, AppColors.green, size: 38),
    ];
    final ended = r.isFinished;
    final secondsLeft = r.expiresAt == null ? 0 : r.expiresAt!.difference(DateTime.now()).inSeconds;

    String statusText = AppConstants.rideStatusLabels[r.status] ?? r.status;
    if (r.status == 'accepted' && etaMin != null) statusText = 'Votre conducteur arrive dans ~$etaMin min';
    if (r.status == 'in_progress' && etaMin != null) statusText = 'Course en cours · arrivée dans ~$etaMin min';
    if (r.status == 'requested') statusText = secondsLeft > 0 ? 'En attente de la réponse du conducteur (${secondsLeft}s)' : 'Le conducteur n\'a pas répondu';

    return Scaffold(
      appBar: AppBar(title: const Text('Ma course')),
      body: Column(children: [
        if (offline)
          Container(width: double.infinity, color: const Color(0xFFFEF3C7), padding: const EdgeInsets.all(8), child: const Text('Hors ligne : la course se synchronisera dès que la connexion reviendra. Vous pouvez appeler votre conducteur.', style: TextStyle(fontSize: 12))),
        Expanded(flex: 5, child: DealsMap(center: driverPos ?? pickup, zoom: 14, route: route?.points ?? const [], markers: markers)),
        Expanded(
          flex: 6,
          child: Container(
            decoration: const BoxDecoration(color: Colors.white, boxShadow: [BoxShadow(color: Color(0x22000000), blurRadius: 10)]),
            child: ListView(padding: const EdgeInsets.all(16), children: [
              Text(statusText, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w900)),
              const SizedBox(height: 10),
              if (!ended || r.status == 'completed') ...[
                Row(children: [
                  UserAvatar(path: r.driverAvatarPath, label: r.driverName, radius: 26),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                      Text(r.driverName ?? 'Conducteur', style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 16)),
                      Text(r.vehicleText, style: const TextStyle(color: AppColors.greyText)),
                    ]),
                  ),
                  Text(money(r.total), style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
                ]),
                const SizedBox(height: 8),
                Text('${r.pickupLabel}  →  ${r.destLabel}', style: const TextStyle(color: AppColors.greyText, fontSize: 13)),
                Text('Paiement : ${r.paymentMethod == 'wave' ? 'Wave (au conducteur)' : 'Espèces'}', style: const TextStyle(fontSize: 13)),
              ],
              const SizedBox(height: 12),
              if (ended && r.status != 'completed') ...[
                AppCard(
                  color: const Color(0xFFFEE2E2),
                  child: Text(
                    r.status == 'declined' ? 'Le conducteur a refusé la demande${r.declineReason == null ? '' : ' : ${r.declineReason}'}.'
                        : r.status == 'expired' ? "Le conducteur n'a pas répondu à temps."
                        : 'La course a été annulée${r.cancelledBy == 'driver' ? ' par le conducteur' : r.cancelledBy == 'admin' ? " par l'administration" : ''}.',
                  ),
                ),
                const SizedBox(height: 12),
                ElevatedButton(onPressed: () => Navigator.of(context).popUntil((x) => x.isFirst), child: const Text('Choisir un autre conducteur')),
              ] else if (r.status == 'completed') ...[
                ElevatedButton(onPressed: () => Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => ReceiptScreen(ride: r))), child: const Text('Voir le reçu')),
              ] else ...[
                if (r.status != 'requested')
                  Row(children: [
                    Expanded(child: _Action(icon: Icons.call, label: 'Appeler', onTap: () => callPhone(r.driverPhone ?? toS(stored?['phone'])))),
                    Expanded(child: _Action(icon: Icons.chat_bubble_outline, label: 'Message', onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => ChatScreen(rideId: r.id, title: r.driverName ?? 'Conducteur'))))),
                    Expanded(child: _Action(icon: Icons.share_outlined, label: 'Partager', onTap: _share)),
                    Expanded(child: _Action(icon: Icons.sos_rounded, label: 'SOS', color: const Color(0xFFDC2626), onTap: () => showSosSheet(context, rideId: r.id))),
                  ]),
                if (r.status != 'in_progress') ...[
                  const SizedBox(height: 10),
                  OutlinedButton(onPressed: _cancel, child: const Text('Annuler la course')),
                ],
              ],
            ]),
          ),
        ),
      ]),
    );
  }
}

class _Action extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final Color color;
  const _Action({required this.icon, required this.label, required this.onTap, this.color = AppColors.black});
  @override
  Widget build(BuildContext context) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: Column(children: [
            CircleAvatar(backgroundColor: AppColors.grey, child: Icon(icon, color: color)),
            const SizedBox(height: 4),
            Text(label, style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: color)),
          ]),
        ),
      );
}

class _StoredContact extends StatelessWidget {
  final Map<String, dynamic> c;
  const _StoredContact(this.c);
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.all(16),
        child: AppCard(
          child: Row(children: [
            const Icon(Icons.phone_in_talk_outlined),
            const SizedBox(width: 10),
            Expanded(child: Text('${c['name'] ?? 'Conducteur'}\n${c['vehicle'] ?? ''}')),
            ElevatedButton(onPressed: () => callPhone('${c['phone']}'), style: ElevatedButton.styleFrom(minimumSize: const Size(110, 44)), child: const Text('Appeler')),
          ]),
        ),
      );
}

// Évite un avertissement d'import inutilisé si DealsLogo/Place ne sont pas utilisés selon la configuration.
const _keep = [Place, DealsLogo];
