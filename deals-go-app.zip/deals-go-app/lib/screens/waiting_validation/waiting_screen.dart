import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/format.dart';
import '../../core/utils/json.dart';
import '../../providers/auth_provider.dart';
import '../../providers/content_provider.dart';
import '../../services/launcher.dart';
import '../../widgets/common.dart';

class WaitingScreen extends StatefulWidget {
  const WaitingScreen({super.key});
  @override
  State<WaitingScreen> createState() => _WaitingScreenState();
}

class _WaitingScreenState extends State<WaitingScreen> {
  final code = TextEditingController();
  bool busy = false;
  String? error;

  @override
  void dispose() {
    code.dispose();
    super.dispose();
  }

  String _explain(Map<String, dynamic> r) {
    switch (toS(r['error'])) {
      case 'invalid_code':
        final left = toI(r['attempts_left']);
        return 'Code incorrect. Il vous reste $left essai${left > 1 ? 's' : ''}.';
      case 'code_expired':
        return 'Ce code a expiré. Demandez un nouveau code à l\'administration.';
      case 'no_active_code':
        return "L'administration n'a pas encore généré votre code. Patientez ou contactez-nous sur WhatsApp.";
      case 'too_many_attempts':
        return 'Trop d\'essais. Demandez un nouveau code à l\'administration.';
      case 'invalid_format':
        return 'Le code contient 6 chiffres.';
      default:
        return 'Vérification impossible. Réessayez.';
    }
  }

  Future<void> verify() async {
    setState(() { busy = true; error = null; });
    try {
      final r = await context.read<AuthProvider>().verifyCode(code.text.trim());
      if (r['ok'] != true && mounted) setState(() => error = _explain(r));
    } catch (e) {
      if (mounted) setState(() => error = 'Connexion impossible. Vérifiez votre Internet.');
    } finally {
      if (mounted) setState(() => busy = false);
    }
  }

  Future<void> askNew() async {
    final msg = await context.read<AuthProvider>().requestNewCode();
    if (!mounted) return;
    snack(context, msg ?? 'Demande envoyée à l\'administration.');
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final content = context.watch<ContentProvider>();
    return Scaffold(
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(24),
          children: [
            const SizedBox(height: 18),
            Center(
              child: SizedBox(
                width: 120,
                height: 120,
                child: Stack(alignment: Alignment.center, children: const [
                  SizedBox(width: 120, height: 120, child: CircularProgressIndicator(strokeWidth: 6, color: AppColors.red)),
                  Icon(Icons.hourglass_top_rounded, size: 40, color: AppColors.black),
                ]),
              ),
            ),
            const SizedBox(height: 26),
            const Text('EN ATTENTE DE CONFIRMATION',
                textAlign: TextAlign.center, style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, height: 1.1)),
            const SizedBox(height: 10),
            const Text('Votre demande est en cours de vérification par l\'administration.',
                textAlign: TextAlign.center, style: TextStyle(color: AppColors.greyText, fontSize: 15)),
            const SizedBox(height: 6),
            Text(prettyPhone(auth.phone), textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 26),
            const Text('Vous avez reçu un code ?', style: TextStyle(fontWeight: FontWeight.w700)),
            const SizedBox(height: 8),
            TextField(
              controller: code,
              keyboardType: TextInputType.number,
              maxLength: 6,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 28, letterSpacing: 8, fontWeight: FontWeight.w800),
              decoration: const InputDecoration(counterText: '', hintText: '------'),
              onChanged: (v) => setState(() {}),
            ),
            if (error != null)
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text(error!, style: const TextStyle(color: Color(0xFFB91C1C))),
              ),
            const SizedBox(height: 12),
            ElevatedButton(
              onPressed: (busy || code.text.trim().length != 6) ? null : verify,
              child: busy
                  ? const SizedBox(height: 22, width: 22, child: CircularProgressIndicator(strokeWidth: 3, color: Colors.white))
                  : const Text('Valider mon code'),
            ),
            const SizedBox(height: 10),
            OutlinedButton(onPressed: askNew, child: const Text('Prévenir l\'administration / demander un code')),
            const SizedBox(height: 10),
            OutlinedButton(
              onPressed: () => openWhatsApp(content.whatsapp, 'Bonjour DEALS GO, je viens de m\'inscrire avec le numéro ${prettyPhone(auth.phone)}. Pouvez-vous valider mon compte et m\'envoyer mon code ?'),
              child: const Text('Contacter l\'administration sur WhatsApp'),
            ),
            const SizedBox(height: 6),
            TextButton(onPressed: () => auth.signOut(), child: const Text('Se déconnecter')),
          ],
        ),
      ),
    );
  }
}
