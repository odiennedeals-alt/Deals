import 'dart:typed_data';
import 'package:supabase_flutter/supabase_flutter.dart';
import '../core/constants/app_constants.dart';
import '../core/utils/json.dart';
import '../models/driver_card.dart';
import '../models/ride.dart';
import 'supa.dart';

/// Tous les appels à Supabase. Les règles de sécurité (RLS) et les fonctions SQL côté serveur
/// font foi : l'application ne peut rien faire que la base n'autorise.
class Api {
  // ------------------------------------------------------------------ Profil
  static Future<Map<String, dynamic>?> myProfile() async {
    final r = await sb.from('profiles').select().eq('id', myId!).maybeSingle();
    return r == null ? null : Map<String, dynamic>.from(r);
  }

  static Future<void> updateProfile(Map<String, dynamic> values) async {
    await sb.from('profiles').update(values).eq('id', myId!);
  }

  static Future<List<String>> myRoles() async {
    final r = await sb.from('user_roles').select('role,is_active').eq('user_id', myId!);
    return toList(r).where((e) => e['is_active'] == true).map((e) => toS(e['role'])).toList();
  }

  static Future<void> requestVerification() async {
    await sb.rpc('request_verification');
  }

  static Future<Map<String, dynamic>> verifyCode(String code) async {
    final r = await sb.rpc('verify_my_code', params: {'p_code': code});
    return toMap(r) ?? {'ok': false};
  }

  // ----------------------------------------------------------------- Contenu
  static Future<Map<String, dynamic>> publicSettings() async {
    final r = await sb.from('app_settings').select('key,value');
    return {for (final e in toList(r)) toS(e['key']): e['value']};
  }

  static Future<Map<String, dynamic>> appContent() async {
    final r = await sb.from('app_content').select('key,content_type,value,is_active,sort_order').eq('is_active', true);
    return {for (final e in toList(r)) toS(e['key']): e};
  }

  static Future<List<Map<String, dynamic>>> sosNumbers() async =>
      toList(await sb.from('sos_numbers').select().order('sort_order'));

  static Future<List<Map<String, dynamic>>> cities() async =>
      toList(await sb.from('cities').select().eq('is_active', true).order('sort_order'));

  static Future<List<Map<String, dynamic>>> supportCategories() async =>
      toList(await sb.from('support_categories').select().eq('is_active', true).order('sort_order'));

  static Future<List<Map<String, dynamic>>> supportQuestions() async => toList(await sb
      .from('support_questions')
      .select('id,category_id,question,sort_order,support_answers(answer,locale)')
      .eq('is_active', true)
      .order('sort_order'));

  // ------------------------------------------------------------ Stockage
  static Future<String> uploadImage(String bucket, Uint8List bytes, String name, {String contentType = 'image/jpeg'}) async {
    final path = '${myId!}/$name';
    await sb.storage.from(bucket).uploadBinary(path, bytes, fileOptions: FileOptions(contentType: contentType, upsert: false));
    return path;
  }

  static Future<String?> signedUrl(String bucket, String path) async {
    try {
      return await sb.storage.from(bucket).createSignedUrl(path, 600);
    } catch (_) {
      return null;
    }
  }

  // --------------------------------------------------------- Client : courses
  static Future<List<DriverCard>> listDrivers({
    required String vehicleType,
    required double lat,
    required double lng,
    double? destLat,
    double? destLng,
    double? tripKm,
    int radiusKm = 10,
  }) async {
    final r = await sb.rpc('list_available_drivers', params: {
      'p_vehicle_type': vehicleType,
      'p_lat': lat,
      'p_lng': lng,
      'p_radius_km': radiusKm,
      'p_dest_lat': destLat,
      'p_dest_lng': destLng,
      'p_trip_km': tripKm,
      'p_limit': 30,
    });
    return toList(r).map(DriverCard.fromMap).toList();
  }

  static Future<Ride> requestRide({
    required String driverId,
    required String vehicleType,
    required String pickupLabel,
    required double pickupLat,
    required double pickupLng,
    required String destLabel,
    required double destLat,
    required double destLng,
    required double distanceKm,
    required int durationMin,
    required String paymentMethod,
    String? promo,
  }) async {
    final r = await sb.rpc('request_ride', params: {
      'p_driver_id': driverId,
      'p_vehicle_type': vehicleType,
      'p_pickup_label': pickupLabel,
      'p_pickup_lat': pickupLat,
      'p_pickup_lng': pickupLng,
      'p_dest_label': destLabel,
      'p_dest_lat': destLat,
      'p_dest_lng': destLng,
      'p_distance_km': distanceKm,
      'p_duration_min': durationMin,
      'p_payment_method': paymentMethod,
      'p_promo_code': (promo == null || promo.trim().isEmpty) ? null : promo.trim(),
    });
    return Ride.fromMap(toMap(r)!);
  }

  static Future<Ride?> activeRideAsClient() async {
    final r = await sb
        .from('rides')
        .select()
        .eq('client_id', myId!)
        .inFilter('status', AppConstants.activeRideStatuses)
        .order('created_at', ascending: false)
        .limit(1);
    final l = toList(r);
    return l.isEmpty ? null : Ride.fromMap(l.first);
  }

  static Future<Ride?> rideById(String id) async {
    final r = await sb.from('rides').select().eq('id', id).maybeSingle();
    return r == null ? null : Ride.fromMap(Map<String, dynamic>.from(r));
  }

  static Future<List<Ride>> clientHistory() async {
    final r = await sb.from('rides').select().eq('client_id', myId!).order('created_at', ascending: false).limit(100);
    return toList(r).map(Ride.fromMap).toList();
  }

  static Future<Ride> cancelRide(String id, String? reason) async {
    final r = await sb.rpc('cancel_ride', params: {'p_ride_id': id, 'p_reason': reason});
    return Ride.fromMap(toMap(r)!);
  }

  static Future<void> rateRide(String id, int rating, String? comment) async {
    await sb.rpc('rate_ride', params: {'p_ride_id': id, 'p_rating': rating, 'p_comment': comment});
  }

  static Future<Map<String, dynamic>?> lastDriverPosition(String rideId) async {
    final r = await sb.from('ride_locations').select('lat,lng,recorded_at').eq('ride_id', rideId).order('recorded_at', ascending: false).limit(1);
    final l = toList(r);
    return l.isEmpty ? null : l.first;
  }

  static Future<Map<String, dynamic>> startShare(String rideId) async =>
      toMap(await sb.rpc('start_trip_share', params: {'p_ride_id': rideId, 'p_hours': 4})) ?? {};

  static Future<void> stopShare(String rideId) async {
    await sb.rpc('stop_trip_share', params: {'p_ride_id': rideId});
  }

  static Future<Map<String, dynamic>> safetyAlert({String? rideId, double? lat, double? lng, String type = 'unsafe', String? message}) async =>
      toMap(await sb.rpc('trigger_safety_alert', params: {
        'p_ride_id': rideId,
        'p_lat': lat,
        'p_lng': lng,
        'p_alert_type': type,
        'p_message': message,
      })) ??
      {};

  static Future<void> submitReport(String category, String description, {String? rideId, String? reportedUserId}) async {
    await sb.rpc('submit_report', params: {
      'p_category': category,
      'p_description': description,
      'p_ride_id': rideId,
      'p_reported_user_id': reportedUserId,
    });
  }

  // ---------------------------------------------------------------- Messagerie
  static Future<List<Map<String, dynamic>>> messages(String rideId) async =>
      toList(await sb.from('messages').select().eq('ride_id', rideId).order('created_at'));

  static Future<void> sendMessage(String rideId, String body) async {
    await sb.from('messages').insert({'ride_id': rideId, 'sender_id': myId!, 'body': body});
  }

  // ------------------------------------------------------- Conducteur : général
  static Future<Map<String, dynamic>?> myDriver() async {
    final r = await sb.from('drivers').select().eq('id', myId!).maybeSingle();
    return r == null ? null : Map<String, dynamic>.from(r);
  }

  static Future<void> registerAsDriver({
    required String fullName,
    required String vehicleType,
    required String brand,
    required String model,
    required String color,
    required String plate,
    int? year,
  }) async {
    await sb.rpc('register_as_driver', params: {
      'p_full_name': fullName,
      'p_vehicle_type': vehicleType,
      'p_brand': brand,
      'p_model': model,
      'p_color': color,
      'p_plate': plate,
      'p_year': year,
    });
  }

  static Future<void> setOnline(bool online) async {
    await sb.rpc('set_online', params: {'p_online': online});
  }

  static Future<void> updateLocation(double lat, double lng, {double? heading, String? rideId}) async {
    await sb.rpc('update_driver_location', params: {
      'p_lat': lat,
      'p_lng': lng,
      'p_heading': heading,
      'p_ride_id': rideId,
    });
  }

  static Future<Map<String, dynamic>> earnings() async => toMap(await sb.rpc('driver_earnings')) ?? {};

  static Future<List<Ride>> driverRequests() async {
    final r = await sb
        .from('rides')
        .select()
        .eq('driver_id', myId!)
        .eq('status', 'requested')
        .gt('expires_at', DateTime.now().toUtc().toIso8601String())
        .order('created_at', ascending: false);
    return toList(r).map(Ride.fromMap).toList();
  }

  static Future<Ride?> activeRideAsDriver() async {
    final r = await sb
        .from('rides')
        .select()
        .eq('driver_id', myId!)
        .inFilter('status', ['accepted', 'arrived', 'in_progress'])
        .order('created_at', ascending: false)
        .limit(1);
    final l = toList(r);
    return l.isEmpty ? null : Ride.fromMap(l.first);
  }

  static Future<List<Ride>> driverHistory() async {
    final r = await sb.from('rides').select().eq('driver_id', myId!).order('created_at', ascending: false).limit(100);
    return toList(r).map(Ride.fromMap).toList();
  }

  static Future<Ride> respondRide(String id, bool accept, {String? reason}) async {
    final r = await sb.rpc('driver_respond_ride', params: {'p_ride_id': id, 'p_accept': accept, 'p_reason': reason});
    return Ride.fromMap(toMap(r)!);
  }

  static Future<Ride> updateRideStatus(String id, String status) async {
    final r = await sb.rpc('driver_update_ride', params: {'p_ride_id': id, 'p_status': status});
    return Ride.fromMap(toMap(r)!);
  }

  // ----------------------------------------------------------------- Véhicules
  static Future<List<Map<String, dynamic>>> myVehicles() async =>
      toList(await sb.from('vehicles').select().eq('driver_id', myId!).order('created_at'));

  static Future<void> updateVehicle(String id, Map<String, dynamic> values) async {
    await sb.from('vehicles').update(values).eq('id', id);
  }

  static Future<List<Map<String, dynamic>>> maintenance() async =>
      toList(await sb.from('maintenance_alerts').select().eq('driver_id', myId!).order('is_done').order('due_date'));

  static Future<void> addMaintenance(Map<String, dynamic> values) async {
    await sb.from('maintenance_alerts').insert({...values, 'driver_id': myId!});
  }

  static Future<void> updateMaintenance(String id, Map<String, dynamic> values) async {
    await sb.from('maintenance_alerts').update(values).eq('id', id);
  }

  static Future<void> deleteMaintenance(String id) async {
    await sb.from('maintenance_alerts').delete().eq('id', id);
  }

  // -------------------------------------------------------- Abonnement et paiement
  static Future<List<Map<String, dynamic>>> plans() async =>
      toList(await sb.from('subscription_plans').select().eq('is_active', true).order('sort_order'));

  static Future<List<Map<String, dynamic>>> mySubscriptions() async =>
      toList(await sb.from('subscriptions').select().eq('driver_id', myId!).order('created_at', ascending: false).limit(20));

  static Future<List<Map<String, dynamic>>> myPayments() async =>
      toList(await sb.from('subscription_payments').select().eq('driver_id', myId!).order('created_at', ascending: false).limit(20));

  static Future<Map<String, dynamic>> createPaymentRequest(String planId) async =>
      toMap(await sb.rpc('create_payment_request', params: {'p_plan_id': planId})) ?? {};

  static Future<void> submitPaymentProof(String paymentId, String filePath, String? ref) async {
    await sb.rpc('submit_payment_proof', params: {'p_payment_id': paymentId, 'p_file_path': filePath, 'p_transaction_ref': ref});
  }

  // ------------------------------------------------------------- Certification
  static Future<Map<String, dynamic>?> myCertification() async {
    final r = await sb.from('driver_certifications').select().eq('driver_id', myId!).maybeSingle();
    return r == null ? null : Map<String, dynamic>.from(r);
  }

  static Future<List<Map<String, dynamic>>> myDocuments() async => toList(await sb
      .from('driver_documents')
      .select()
      .eq('driver_id', myId!)
      .neq('status', 'superseded')
      .order('created_at', ascending: false));

  static Future<void> submitDocument(String type, String path) async {
    await sb.rpc('submit_driver_document', params: {'p_doc_type': type, 'p_file_path': path});
  }

  // ------------------------------------------------------------- Notifications
  static Future<List<Map<String, dynamic>>> notifications() async =>
      toList(await sb.from('notifications').select().eq('user_id', myId!).order('created_at', ascending: false).limit(80));

  static Future<void> markNotificationRead(String id) async {
    await sb.from('notifications').update({'is_read': true}).eq('id', id);
  }

  static Future<void> markAllNotificationsRead() async {
    await sb.from('notifications').update({'is_read': true}).eq('user_id', myId!).eq('is_read', false);
  }

  // --------------------------------------------- Contacts d'urgence et favoris
  static Future<List<Map<String, dynamic>>> emergencyContacts() async =>
      toList(await sb.from('emergency_contacts').select().eq('user_id', myId!).order('created_at'));

  static Future<void> saveEmergencyContact(Map<String, dynamic> values, {String? id}) async {
    if (values['is_primary'] == true) {
      await sb.from('emergency_contacts').update({'is_primary': false}).eq('user_id', myId!);
    }
    if (id == null) {
      await sb.from('emergency_contacts').insert({...values, 'user_id': myId!});
    } else {
      await sb.from('emergency_contacts').update(values).eq('id', id);
    }
  }

  static Future<void> deleteEmergencyContact(String id) async {
    await sb.from('emergency_contacts').delete().eq('id', id);
  }

  static Future<List<Map<String, dynamic>>> favorites() async =>
      toList(await sb.from('favorite_addresses').select().eq('user_id', myId!).order('created_at'));

  static Future<void> addFavorite(String label, String address, double lat, double lng) async {
    await sb.from('favorite_addresses').insert({'user_id': myId!, 'label': label, 'address': address, 'lat': lat, 'lng': lng});
  }

  static Future<void> deleteFavorite(String id) async {
    await sb.from('favorite_addresses').delete().eq('id', id);
  }

  // ---------------------------------------------------------------- Interurbain
  static Future<List<Map<String, dynamic>>> interurbanTrips({
    required String fromCity,
    required String toCity,
    DateTime? date,
    String? vehicleType,
    int seats = 1,
  }) async =>
      toList(await sb.rpc('list_interurban_trips', params: {
        'p_from_city': fromCity,
        'p_to_city': toCity,
        'p_date': date == null ? null : '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}',
        'p_vehicle_type': vehicleType,
        'p_seats': seats,
      }));

  static Future<void> bookTrip(String tripId, int seats) async {
    await sb.rpc('book_interurban_trip', params: {'p_trip_id': tripId, 'p_seats': seats});
  }

  static Future<List<Map<String, dynamic>>> myBookings() async => toList(await sb
      .from('interurban_bookings')
      .select('id,seats,status,created_at,interurban_trips(departure_at,price_fcfa,from:cities!interurban_trips_from_city_id_fkey(name),to:cities!interurban_trips_to_city_id_fkey(name))')
      .eq('client_id', myId!)
      .order('created_at', ascending: false));

  static Future<void> cancelBooking(String id) async {
    await sb.rpc('cancel_interurban_booking', params: {'p_booking_id': id});
  }

  static Future<List<Map<String, dynamic>>> myTrips() async => toList(await sb
      .from('interurban_trips')
      .select('id,departure_at,seats_total,seats_available,price_fcfa,status,notes,from:cities!interurban_trips_from_city_id_fkey(name),to:cities!interurban_trips_to_city_id_fkey(name)')
      .eq('driver_id', myId!)
      .order('departure_at', ascending: false));

  static Future<List<Map<String, dynamic>>> tripBookings(String tripId) async => toList(await sb
      .from('interurban_bookings')
      .select('id,seats,status,client_id,created_at')
      .eq('trip_id', tripId)
      .order('created_at'));

  static Future<void> respondBooking(String id, bool accept) async {
    await sb.rpc('respond_interurban_booking', params: {'p_booking_id': id, 'p_accept': accept});
  }

  static Future<void> createTrip({
    required String fromCity,
    required String toCity,
    required DateTime departure,
    required int seats,
    required int price,
    String? notes,
  }) async {
    await sb.rpc('create_interurban_trip', params: {
      'p_from_city': fromCity,
      'p_to_city': toCity,
      'p_departure': departure.toUtc().toIso8601String(),
      'p_seats': seats,
      'p_price': price,
      'p_notes': notes,
    });
  }

  static Future<void> cancelTrip(String id) async {
    await sb.rpc('cancel_interurban_trip', params: {'p_trip_id': id});
  }

  // --------------------------------------------------------------- Temps réel
  static RealtimeChannel watch(String table, void Function() onChange, {String? column, String? value}) {
    return sb
        .channel('rt-$table-${DateTime.now().microsecondsSinceEpoch}')
        .onPostgresChanges(
          event: PostgresChangeEvent.all,
          schema: 'public',
          table: table,
          filter: column == null ? null : PostgresChangeFilter(type: PostgresChangeFilterType.eq, column: column, value: value!),
          callback: (payload) => onChange(),
        )
        .subscribe();
  }

  static Future<void> unwatch(RealtimeChannel? ch) async {
    if (ch != null) await sb.removeChannel(ch);
  }
}
