import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:latlong2/latlong.dart';
import '../core/constants/app_constants.dart';
import '../core/utils/json.dart';
import '../models/place.dart';

/// Recherche d'adresses (Nominatim / OpenStreetMap) et itinéraires (OSRM).
/// Ces services publics gratuits ont des limites d'usage : pour une exploitation intensive,
/// prévoir un hébergement dédié ou un fournisseur payant (voir README).
class GeoService {
  static const _distance = Distance();

  static double km(LatLng a, LatLng b) => _distance.as(LengthUnit.Kilometer, a, b);

  static Future<List<Place>> search(String query) async {
    final q = query.trim();
    if (q.length < 3) return [];
    final uri = Uri.https('nominatim.openstreetmap.org', '/search', {
      'format': 'jsonv2',
      'q': q,
      'limit': '8',
      'countrycodes': 'ci',
      'accept-language': 'fr',
      'viewbox': '-8.6,10.4,-6.6,8.6',
      'bounded': '0',
    });
    final res = await http.get(uri, headers: {'User-Agent': AppConstants.userAgent}).timeout(const Duration(seconds: 10));
    if (res.statusCode != 200) return [];
    final list = jsonDecode(res.body) as List;
    return list
        .map((e) => Place(_shorten(toS(e['display_name'])), LatLng(toD(e['lat']), toD(e['lon']))))
        .toList();
  }

  static Future<String> reverse(LatLng p) async {
    try {
      final uri = Uri.https('nominatim.openstreetmap.org', '/reverse', {
        'format': 'jsonv2',
        'lat': p.latitude.toString(),
        'lon': p.longitude.toString(),
        'zoom': '18',
        'accept-language': 'fr',
      });
      final res = await http.get(uri, headers: {'User-Agent': AppConstants.userAgent}).timeout(const Duration(seconds: 8));
      if (res.statusCode == 200) {
        final m = jsonDecode(res.body) as Map<String, dynamic>;
        final name = toS(m['display_name']);
        if (name.isNotEmpty) return _shorten(name);
      }
    } catch (_) {}
    return 'Position sélectionnée';
  }

  static String _shorten(String full) {
    final parts = full.split(',').map((e) => e.trim()).where((e) => e.isNotEmpty).toList();
    return parts.take(3).join(', ');
  }

  /// Itinéraire routier. En cas d'échec réseau, estimation à vol d'oiseau x 1,3.
  static Future<RouteInfo> route(LatLng a, LatLng b) async {
    try {
      final uri = Uri.parse(
        'https://router.project-osrm.org/route/v1/driving/${a.longitude},${a.latitude};${b.longitude},${b.latitude}?overview=full&geometries=geojson',
      );
      final res = await http.get(uri, headers: {'User-Agent': AppConstants.userAgent}).timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final m = jsonDecode(res.body) as Map<String, dynamic>;
        final routes = m['routes'] as List?;
        if (routes != null && routes.isNotEmpty) {
          final r = routes.first as Map<String, dynamic>;
          final coords = (r['geometry']['coordinates'] as List)
              .map((c) => LatLng(toD((c as List)[1]), toD(c[0])))
              .toList();
          final distKm = toD(r['distance']) / 1000;
          final mins = (toD(r['duration']) / 60).ceil();
          return RouteInfo(double.parse(distKm.toStringAsFixed(2)), mins < 1 ? 1 : mins, coords);
        }
      }
    } catch (_) {}
    final d = km(a, b) * 1.3;
    final mins = (d / 25 * 60).ceil();
    return RouteInfo(double.parse(d.toStringAsFixed(2)), mins < 1 ? 1 : mins, [a, b], estimated: true);
  }
}
