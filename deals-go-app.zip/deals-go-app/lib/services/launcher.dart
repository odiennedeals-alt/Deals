import 'package:url_launcher/url_launcher.dart';

Future<bool> _open(Uri uri) async {
  try {
    return await launchUrl(uri, mode: LaunchMode.externalApplication);
  } catch (_) {
    return false;
  }
}

Future<bool> callPhone(String phone) => _open(Uri(scheme: 'tel', path: phone));

Future<bool> sendSms(String phone, String body) => _open(Uri(scheme: 'sms', path: phone, queryParameters: {'body': body}));

Future<bool> openWhatsApp(String phone, String message) {
  final digits = phone.replaceAll(RegExp(r'[^0-9]'), '');
  return _open(Uri.parse('https://wa.me/$digits?text=${Uri.encodeComponent(message)}'));
}

Future<bool> openNavigation(double lat, double lng) =>
    _open(Uri.parse('https://www.google.com/maps/dir/?api=1&destination=$lat,$lng&travelmode=driving'));

Future<bool> openUrl(String url) => _open(Uri.parse(url));
