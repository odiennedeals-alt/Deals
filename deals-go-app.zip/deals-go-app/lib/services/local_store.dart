import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

/// Données conservées sur le téléphone : contact de la course en cours (appel possible sans Internet),
/// code promo, mode d'utilisation.
class LocalStore {
  static const _kContact = 'active_ride_contact';
  static const _kPromo = 'promo_code';
  static const _kMode = 'mode';

  static Future<void> saveRideContact(Map<String, dynamic> data) async {
    final p = await SharedPreferences.getInstance();
    await p.setString(_kContact, jsonEncode(data));
  }

  static Future<Map<String, dynamic>?> rideContact() async {
    final p = await SharedPreferences.getInstance();
    final s = p.getString(_kContact);
    if (s == null) return null;
    try {
      return Map<String, dynamic>.from(jsonDecode(s) as Map);
    } catch (_) {
      return null;
    }
  }

  static Future<void> clearRideContact() async {
    final p = await SharedPreferences.getInstance();
    await p.remove(_kContact);
  }

  static Future<String?> promo() async => (await SharedPreferences.getInstance()).getString(_kPromo);

  static Future<void> setPromo(String? code) async {
    final p = await SharedPreferences.getInstance();
    if (code == null || code.isEmpty) {
      await p.remove(_kPromo);
    } else {
      await p.setString(_kPromo, code);
    }
  }

  static Future<String> mode() async => (await SharedPreferences.getInstance()).getString(_kMode) ?? 'client';

  static Future<void> setMode(String m) async => (await SharedPreferences.getInstance()).setString(_kMode, m);
}
