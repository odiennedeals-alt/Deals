import 'dart:typed_data';
import 'package:image_picker/image_picker.dart';

class PickedImage {
  final Uint8List bytes;
  final String ext;
  PickedImage(this.bytes, this.ext);
  String get contentType => ext == 'png' ? 'image/png' : (ext == 'webp' ? 'image/webp' : 'image/jpeg');
  String nameWith(String prefix) => '$prefix-${DateTime.now().millisecondsSinceEpoch}.$ext';
}

Future<PickedImage?> pickImage({bool camera = false}) async {
  final x = await ImagePicker().pickImage(
    source: camera ? ImageSource.camera : ImageSource.gallery,
    maxWidth: 1600,
    imageQuality: 80,
  );
  if (x == null) return null;
  final bytes = await x.readAsBytes();
  final n = x.name.toLowerCase();
  final ext = n.endsWith('.png') ? 'png' : (n.endsWith('.webp') ? 'webp' : 'jpg');
  return PickedImage(bytes, ext);
}
