import 'package:supabase_flutter/supabase_flutter.dart';

SupabaseClient get sb => Supabase.instance.client;
String? get myId => sb.auth.currentUser?.id;

String? publicUrl(String? path) {
  if (path == null || path.isEmpty) return null;
  return sb.storage.from('public-media').getPublicUrl(path);
}

String? publicUrlFor(String path) => publicUrl(path);
