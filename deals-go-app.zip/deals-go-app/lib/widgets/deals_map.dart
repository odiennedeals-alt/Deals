import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import '../core/constants/app_constants.dart';
import '../core/theme/app_theme.dart';

Marker pinMarker(LatLng p, IconData icon, Color color, {double size = 38}) => Marker(
      point: p,
      width: size,
      height: size,
      child: Icon(icon, color: color, size: size),
    );

Marker dotMarker(LatLng p, Color color) => Marker(
      point: p,
      width: 22,
      height: 22,
      child: Container(
        decoration: BoxDecoration(
          color: color,
          shape: BoxShape.circle,
          border: Border.all(color: Colors.white, width: 3),
          boxShadow: const [BoxShadow(color: Color(0x55000000), blurRadius: 6)],
        ),
      ),
    );

/// Carte OpenStreetMap. Pour une exploitation intensive, remplacez le fournisseur de tuiles (voir README).
class DealsMap extends StatelessWidget {
  final LatLng center;
  final double zoom;
  final List<Marker> markers;
  final List<LatLng> route;
  final MapController? controller;
  final void Function(LatLng)? onTap;

  const DealsMap({
    super.key,
    required this.center,
    this.zoom = AppConstants.defaultZoom,
    this.markers = const [],
    this.route = const [],
    this.controller,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return FlutterMap(
      mapController: controller,
      options: MapOptions(
        initialCenter: center,
        initialZoom: zoom,
        minZoom: 5,
        maxZoom: 18,
        interactionOptions: InteractionOptions(flags: InteractiveFlag.all & ~InteractiveFlag.rotate),
        onTap: onTap == null ? null : (tapPosition, point) => onTap!(point),
      ),
      children: [
        TileLayer(
          urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
          userAgentPackageName: 'com.dealsgo.app',
        ),
        if (route.length > 1)
          PolylineLayer(polylines: [Polyline(points: route, strokeWidth: 5, color: AppColors.red)]),
        MarkerLayer(markers: markers),
        const RichAttributionWidget(
          alignment: AttributionAlignment.bottomLeft,
          attributions: [TextSourceAttribution('© OpenStreetMap')],
        ),
      ],
    );
  }
}
