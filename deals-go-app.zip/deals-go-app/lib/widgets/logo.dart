import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/theme/app_theme.dart';
import '../providers/content_provider.dart';
import '../services/supa.dart';

/// Logo DEALS GO : symbole rouge-orange + texte noir. Si un logo est publié depuis l'administration, il est affiché.
class DealsLogo extends StatelessWidget {
  final double size;
  final bool showText;
  const DealsLogo({super.key, this.size = 56, this.showText = true});

  @override
  Widget build(BuildContext context) {
    final url = context.watch<ContentProvider>().logoUrl;
    if (url != null) {
      return Image.network(url, height: size, errorBuilder: (_, __, ___) => _fallback());
    }
    return _fallback();
  }

  Widget _fallback() {
    return Row(mainAxisSize: MainAxisSize.min, children: [
      Container(
        width: size,
        height: size,
        decoration: BoxDecoration(color: AppColors.red, borderRadius: BorderRadius.circular(size * 0.3)),
        child: Icon(Icons.navigation_rounded, color: Colors.white, size: size * 0.6),
      ),
      if (showText) ...[
        SizedBox(width: size * 0.22),
        Text('DEALS GO',
            style: TextStyle(fontSize: size * 0.52, fontWeight: FontWeight.w900, color: AppColors.black, letterSpacing: 0.5)),
      ],
    ]);
  }
}

class UserAvatar extends StatelessWidget {
  final String? path;
  final double radius;
  final String? label;
  const UserAvatar({super.key, this.path, this.radius = 24, this.label});

  @override
  Widget build(BuildContext context) {
    final url = publicUrl(path);
    final initial = (label != null && label!.trim().isNotEmpty) ? label!.trim()[0].toUpperCase() : '?';
    return CircleAvatar(
      radius: radius,
      backgroundColor: const Color(0xFFE5E7EB),
      foregroundImage: url == null ? null : NetworkImage(url),
      child: Text(initial, style: TextStyle(fontSize: radius * 0.8, fontWeight: FontWeight.w700, color: AppColors.black)),
    );
  }
}
