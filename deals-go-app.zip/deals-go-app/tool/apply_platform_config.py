#!/usr/bin/env python3
"""Ajoute les permissions Android/iOS nécessaires à DEALS GO dans les fichiers générés par `flutter create`."""
import os
import re

ANDROID = 'android/app/src/main/AndroidManifest.xml'
IOS = 'ios/Runner/Info.plist'

PERMS = [
    'android.permission.INTERNET',
    'android.permission.ACCESS_NETWORK_STATE',
    'android.permission.ACCESS_FINE_LOCATION',
    'android.permission.ACCESS_COARSE_LOCATION',
    'android.permission.CAMERA',
]
QUERIES = """    <queries>
        <intent><action android:name="android.intent.action.VIEW" /><data android:scheme="https" /></intent>
        <intent><action android:name="android.intent.action.DIAL" /><data android:scheme="tel" /></intent>
        <intent><action android:name="android.intent.action.SENDTO" /><data android:scheme="sms" /></intent>
        <intent><action android:name="android.intent.action.VIEW" /><data android:scheme="geo" /></intent>
        <intent><action android:name="android.intent.action.PROCESS_TEXT" /><data android:mimeType="text/plain" /></intent>
    </queries>
"""


def patch_android():
    if not os.path.exists(ANDROID):
        print('AndroidManifest introuvable'); return
    s = open(ANDROID, encoding='utf-8').read()
    add = ''.join(f'    <uses-permission android:name="{p}" />\n' for p in PERMS if p not in s)
    if add:
        s = s.replace('<application', add + '    <application', 1)
    if '<queries>' in s:
        s = re.sub(r'<queries>.*?</queries>\n?', QUERIES, s, count=1, flags=re.S)
    else:
        s = s.replace('<application', QUERIES + '    <application', 1)
    s = re.sub(r'android:label="[^"]*"', 'android:label="DEALS GO"', s, count=1)
    open(ANDROID, 'w', encoding='utf-8').write(s)
    print('Android OK')


def patch_ios():
    if not os.path.exists(IOS):
        print('Info.plist introuvable'); return
    s = open(IOS, encoding='utf-8').read()
    entries = {
        'NSLocationWhenInUseUsageDescription': 'DEALS GO utilise votre position pour trouver les conducteurs proches et suivre votre course.',
        'NSPhotoLibraryUsageDescription': 'DEALS GO a besoin de vos photos pour envoyer vos documents et votre photo de profil.',
        'NSCameraUsageDescription': 'DEALS GO utilise la caméra pour photographier vos documents.',
    }
    block = ''
    for k, v in entries.items():
        if k not in s:
            block += f'\t<key>{k}</key>\n\t<string>{v}</string>\n'
    if 'LSApplicationQueriesSchemes' not in s:
        block += ('\t<key>LSApplicationQueriesSchemes</key>\n\t<array>\n\t\t<string>tel</string>\n\t\t<string>sms</string>\n'
                  '\t\t<string>https</string>\n\t</array>\n')
    if block:
        s = s.replace('</dict>\n</plist>', block + '</dict>\n</plist>', 1)
    s = re.sub(r'(<key>CFBundleDisplayName</key>\s*<string>)[^<]*(</string>)', r'\1DEALS GO\2', s, count=1)
    open(IOS, 'w', encoding='utf-8').write(s)
    print('iOS OK')


patch_android()
patch_ios()
